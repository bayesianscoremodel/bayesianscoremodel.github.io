#! /bin/bash

ProgramFolder="./Programs"
CodeFolder="./Code"

BoostLibrary="-I/.....DependingOnYourEnvironment....../boost_1_63_0"

mkdir $ProgramFolder

g++ -O2 $BoostLibrary $CodeFolder/NoteMarkovModel_Learn_v170803.cpp -o $ProgramFolder/NoteMarkovModel_Learn
g++ -O2 $BoostLibrary $CodeFolder/NoteMarkovModel_PerpFromFile_v170803.cpp -o $ProgramFolder/NoteMarkovModel_PerpFromFile

g++ -O2 $BoostLibrary $CodeFolder/NoteMarkovModel_Transcr_v170804.cpp -o $ProgramFolder/NoteMarkovModel_Transcr
g++ -O2 $BoostLibrary $CodeFolder/NoteMarkovModel_BayesTranscr_v170807.cpp -o $ProgramFolder/NoteMarkovModel_BayesTranscr
g++ -O2 $BoostLibrary $CodeFolder/NoteMMMod_BayesTranscr_v190711.cpp -o $ProgramFolder/NoteMMMod_BayesTranscr


g++ -O2 $BoostLibrary $CodeFolder/MetricalMarkovModel_Learn_v170803.cpp -o $ProgramFolder/MetricalMarkovModel_Learn
g++ -O2 $BoostLibrary $CodeFolder/MetricalMarkovModel_PerpFromFile_v170803.cpp -o $ProgramFolder/MetricalMarkovModel_PerpFromFile

g++ -O2 $BoostLibrary $CodeFolder/MetricalMarkovModel_Transcr_v170804.cpp -o $ProgramFolder/MetricalMarkovModel_Transcr
g++ -O2 $BoostLibrary $CodeFolder/MetricalMarkovModel_BayesTranscr_v170807.cpp -o $ProgramFolder/MetricalMarkovModel_BayesTranscr
g++ -O2 $BoostLibrary $CodeFolder/MetMMMod_BayesTranscr_v171204.cpp -o $ProgramFolder/MetMMMod_BayesTranscr


g++ -O2 $BoostLibrary $CodeFolder/PatternMarkovModel_Learn_v170803.cpp -o $ProgramFolder/PatternMarkovModel_Learn
g++ -O2 $BoostLibrary $CodeFolder/PatternMarkovModel_PerpFromFile_v170803.cpp -o $ProgramFolder/PatternMarkovModel_PerpFromFile

g++ -O2 $BoostLibrary $CodeFolder/PatternMarkovModel_Transcr_v170806.cpp -o $ProgramFolder/PatternMarkovModel_Transcr
g++ -O2 $BoostLibrary $CodeFolder/PatternMarkovModel_BayesTranscr_v170807.cpp -o $ProgramFolder/PatternMarkovModel_BayesTranscr
g++ -O2 $BoostLibrary $CodeFolder/PatMMMod_BayesTranscr_v171204.cpp -o $ProgramFolder/PatMMMod_BayesTranscr

