#! /bin/bash

# Programs/NoteMarkovModel_Transcr 0 Param/param_noteMM0.txt Data/perfm_BPM105_veryshort.txt out_transcr.txt 0.035 0
# Programs/NoteMarkovModel_Transcr 1 Param/param_noteMM1.txt Data/perfm_BPM105_veryshort.txt out_transcr.txt 0.035 0
# Programs/NoteMarkovModel_Transcr 2 Param/param_noteMM2.txt Data/perfm_BPM105_veryshort.txt out_transcr.txt 0.035 0

# Programs/MetricalMarkovModel_Transcr 0 Param/param_metMM0.txt Data/perfm_BPM105_veryshort.txt out_transcr.txt 0.035 0
# Programs/MetricalMarkovModel_Transcr 1 Param/param_metMM1.txt Data/perfm_BPM105_veryshort.txt out_transcr.txt 0.035 0
# Programs/MetricalMarkovModel_Transcr 2 Param/param_metMM2.txt Data/perfm_BPM105_veryshort.txt out_transcr.txt 0.035 0

# Programs/PatternMarkovModel_Transcr 0 Param/param_patMM0.txt Data/perfm_BPM105_veryshort.txt out_transcr.txt 0.035 0
# Programs/PatternMarkovModel_Transcr 1 Param/param_patMM1.txt Data/perfm_BPM105_veryshort.txt out_transcr.txt 0.035 0.8


foldername='test'
seed='5'

# Programs/NoteMarkovModel_BayesTranscr 0 Param/param_noteMM0.txt Data/perfm_BPM105_veryshort.txt out_transcr.txt $foldername 0.035 10 10 0 $seed
# Programs/NoteMarkovModel_BayesTranscr 1 Param/param_noteMM1.txt Data/perfm_BPM105_veryshort.txt out_transcr.txt $foldername 0.035 10 10 0 $seed
# Programs/NoteMarkovModel_BayesTranscr 2 Param/param_noteMM2.txt Data/perfm_BPM105_veryshort.txt out_transcr.txt $foldername 0.035 10 10 0 $seed

# Programs/MetricalMarkovModel_BayesTranscr 0 Param/param_metMM0.txt Data/perfm_BPM105_veryshort.txt out_transcr.txt $foldername 0.035 10 10 0 $seed
# Programs/MetricalMarkovModel_BayesTranscr 1 Param/param_metMM1.txt Data/perfm_BPM105_veryshort.txt out_transcr.txt $foldername 0.035 10 10 0 $seed
# Programs/MetricalMarkovModel_BayesTranscr 2 Param/param_metMM2.txt Data/perfm_BPM105_veryshort.txt out_transcr.txt $foldername 0.035 10 10 0 $seed

# Programs/PatternMarkovModel_BayesTranscr 0 Param/param_patMM0.txt Data/perfm_BPM105_veryshort.txt out_transcr.txt $foldername 0.035 10 10 0 $seed
# Programs/PatternMarkovModel_BayesTranscr 1 Param/param_patMM1.txt Data/perfm_BPM105_veryshort.txt out_transcr.txt $foldername 0.035 10 10 0.8 $seed

# Programs/NoteMMMod_BayesTranscr 1S Param/param_noteMM1.txt Data/perfm_BPM105_veryshort.txt out_transcr.txt $foldername 10 0.9 0.9 0.035 10 10 10 $seed
# Programs/NoteMMMod_BayesTranscr 1D Param/param_noteMM1.txt Data/perfm_BPM105_veryshort.txt out_transcr.txt $foldername 10 0.9 0.9 0.035 10 10 10 $seed
# Programs/NoteMMMod_BayesTranscr 1DS Param/param_noteMM1.txt Data/perfm_BPM105_veryshort.txt out_transcr.txt $foldername 10 0.9 0.9 0.035 10 10 10 $seed
# 
# Programs/MetMMMod_BayesTranscr 1S Param/param_metMM1.txt Data/perfm_BPM105_veryshort.txt out_transcr.txt $foldername 10 0.9 0.9 0.035 10 10 10 $seed
# Programs/MetMMMod_BayesTranscr 1D Param/param_metMM1.txt Data/perfm_BPM105_veryshort.txt out_transcr.txt $foldername 10 0.9 0.9 0.035 10 10 10 $seed
# Programs/MetMMMod_BayesTranscr 1DS Param/param_metMM1.txt Data/perfm_BPM105_veryshort.txt out_transcr.txt $foldername 10 0.9 0.9 0.035 10 10 10 $seed
# 
# Programs/PatMMMod_BayesTranscr 1S Param/param_patMM1.txt Data/perfm_BPM105_veryshort.txt out_transcr.txt $foldername 5 0.9 0.9 0.035 10 10 10 0.8 20 $seed
# Programs/PatMMMod_BayesTranscr 1D Param/param_patMM1.txt Data/perfm_BPM105_veryshort.txt out_transcr.txt $foldername 5 0.9 0.9 0.035 10 10 10 0.8 20 $seed
# Programs/PatMMMod_BayesTranscr 1DS Param/param_patMM1.txt Data/perfm_BPM105_veryshort.txt out_transcr.txt $foldername 5 0.9 0.9 0.035 10 10 10 0.8 20 $seed

