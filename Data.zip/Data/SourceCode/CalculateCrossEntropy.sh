#! /bin/bash

echo '# 0th-order note value MM'
Programs/NoteMarkovModel_PerpFromFile 0 Param/param_noteMM0.txt Data/Pop_test_rhythm.txt 0
echo ''

echo '# 1st-order note value MM'
Programs/NoteMarkovModel_PerpFromFile 1 Param/param_noteMM1.txt Data/Pop_test_rhythm.txt 0
echo ''

echo '# 2nd-order note value MM'
Programs/NoteMarkovModel_PerpFromFile 2 Param/param_noteMM2.txt Data/Pop_test_rhythm.txt 0
echo ''


echo '# 0th-order metrical MM'
Programs/MetricalMarkovModel_PerpFromFile 0 Param/param_metMM0.txt Data/Pop_test_rhythm.txt 0
echo ''

echo '# 1st-order metrical MM'
Programs/MetricalMarkovModel_PerpFromFile 1 Param/param_metMM1.txt Data/Pop_test_rhythm.txt 0
echo ''

echo '# 2nd-order metrical MM'
Programs/MetricalMarkovModel_PerpFromFile 2 Param/param_metMM2.txt Data/Pop_test_rhythm.txt 0
echo ''

echo '# 0th-order note pattern MM'
Programs/PatternMarkovModel_PerpFromFile 0 Param/param_patMM0.txt Data/Pop_test_rhythm.txt 0
echo ''

echo '# 1st-order note pattern MM'
Programs/PatternMarkovModel_PerpFromFile 1 Param/param_patMM1.txt Data/Pop_test_rhythm.txt 0.8
echo ''


