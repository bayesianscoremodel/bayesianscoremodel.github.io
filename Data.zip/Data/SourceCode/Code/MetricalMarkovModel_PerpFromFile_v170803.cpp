#include<fstream>
#include<iostream>
#include<cmath>
#include<string>
#include<sstream>
#include<vector>
#include<algorithm>
#include"stdio.h"
#include"stdlib.h"
#include"MetricalMarkovModel_v170803.hpp"
using namespace std;

int main(int argc, char** argv){
	vector<int> v(100);
	vector<double> d(100);
	vector<string> s(100);
	stringstream ss;
	clock_t start, end;
	start = clock();

	if(argc!=5){
		cout<<"Error in usage: $./this order param.txt data.txt coeff(0;2nd)"<<endl;
		return -1;
	}//endif

	int order=atoi(argv[1]);
	string paramfile=string(argv[2]);
	string datafile=string(argv[3]);
	double coeff=atof(argv[4]);

	assert(order>=0 && order<=2);

cout<<"#Output from MetricalMarkovModel_Perp_v170803"<<endl;

	if(order==1){

		MetricalMarkovModel metMM;
		metMM.ReadFile(paramfile);
		metMM.ReadData(datafile);
		d[0]=metMM.GetLP();

cout<<"CE,Perp:\t"<<-d[0]/metMM.nNote/log(2)<<"\t"<<exp(-d[0]/metMM.nNote)<<endl;

	}else if(order==0){

		MetricalMarkovModel_0th metMM0;
		metMM0.ReadFile(paramfile);
		metMM0.ReadData(datafile);
		d[0]=metMM0.GetLP();

cout<<"CE,Perp:\t"<<-d[0]/metMM0.nNote/log(2)<<"\t"<<exp(-d[0]/metMM0.nNote)<<endl;

	}else if(order==2){

		MetricalMarkovModel_2nd metMM2;
		metMM2.ReadFile(paramfile);
		metMM2.ReadData(datafile);
		metMM2.LinearInterpolate(coeff);
		d[0]=metMM2.GetLP();

cout<<"CE,Perp:\t"<<-d[0]/metMM2.nNote/log(2)<<"\t"<<exp(-d[0]/metMM2.nNote)<<endl;

	}//endif


	return 0;
}//end main
