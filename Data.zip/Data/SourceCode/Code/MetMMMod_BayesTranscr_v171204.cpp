#include<fstream>
#include<iostream>
#include<cmath>
#include<string>
#include<sstream>
#include<vector>
#include<algorithm>
#include"stdio.h"
#include"stdlib.h"
#include"MetricalMarkovModelMod_v171012.hpp"
using namespace std;

int main(int argc, char** argv){
	vector<int> v(100);
	vector<double> d(100);
	vector<string> s(100);
	stringstream ss;
	clock_t start, end;
	start = clock();

	if(argc!=14){
		cout<<"Error in usage: $./this modelType paramBasic.txt perfmdata.txt out_transcr.txt paramFolder(/) nIter noShiftP noInsP sig_t alpha_tr alpha_shift alpha_ins seed"<<endl;
		return -1;
	}//endif

	string modelType=string(argv[1]);
	string paramBasicFile=string(argv[2]);
	string perfmfile=string(argv[3]);
	string transcrfile=string(argv[4]);
	string paramfolder=string(argv[5]);
	int nIter=atoi(argv[6]);
	double noShiftP=atof(argv[7]);
	double noInsP=atof(argv[8]);
	double sig_t=atof(argv[9]);
	double alpha_tr=atof(argv[10]);
	double alpha_shift=atof(argv[11]);
	double alpha_ins=atof(argv[12]);
	int seed=atoi(argv[13]);

	assert(modelType=="1S" || modelType=="1D" || modelType=="1DS");

cout<<"#Output from MetMMMod_Transcr_v171204"<<endl;
cout<<"#modelType: "<<modelType<<" paramBasicFile: "<<paramBasicFile<<" perfmfile: "<<perfmfile<<" transcrfile: "<<transcrfile<<" paramfolder: "<<paramfolder<<" nIter: "<<nIter<<" noShiftP: "<<noShiftP<<" noInsP: "<<noInsP<<" sig_t: "<<sig_t<<" alpha_tr: "<<alpha_tr<<" alpha_shift: "<<alpha_shift<<" alpha_ins: "<<alpha_ins<<" seed: "<<seed<<endl;

	rand();

	if(modelType=="1S"){

		MetMM1S model;

//		model.ReadFile(paramfile);
		model.ReadFileFromBasic(paramBasicFile);
		model.SetSimpleModificationModel(noShiftP);
		model.SetParamFolder(paramfolder);
		model.SetDirParam(alpha_tr,alpha_tr,alpha_shift);
		model.ReadPerfmData(perfmfile);
		if(sig_t>0){model.sig_t=sig_t;}
		model.BayesTranscribe(nIter,seed);
		model.WritePerfmData(transcrfile);

	}else if(modelType=="1D"){

		MetMM1D model;

//		model.ReadFile(paramfile);
		model.ReadFileFromBasic(paramBasicFile);
		model.SetSimpleModificationModel(noInsP);
		model.SetParamFolder(paramfolder);
		model.SetDirParam(alpha_tr,alpha_tr,alpha_ins);
		model.ReadPerfmData(perfmfile);
		if(sig_t>0){model.sig_t=sig_t;}
		model.BayesTranscribe(nIter,seed);
		model.WritePerfmData(transcrfile);

	}else if(modelType=="1DS"){

		MetMM1DS model;

//		model.ReadFile(paramfile);
		model.ReadFileFromBasic(paramBasicFile);
		model.SetSimpleModificationModel(noShiftP,noInsP);
		model.SetParamFolder(paramfolder);
		model.SetDirParam(alpha_tr,alpha_tr,alpha_shift,alpha_ins);
		model.ReadPerfmData(perfmfile);
		if(sig_t>0){model.sig_t=sig_t;}
		model.BayesTranscribe(nIter,seed);
		model.WritePerfmData(transcrfile);

	}else{

cout<<"Error: model type not defined: "<<modelType<<endl;

	}//endif


//	end = clock(); cout<<"Elapsed time : "<<((double)(end - start) / CLOCKS_PER_SEC)<<" sec"<<endl; start=end;
	return 0;
}//end main
