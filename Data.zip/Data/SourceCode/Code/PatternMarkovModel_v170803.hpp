#ifndef PatternMarkovModel_HPP
#define PatternMarkovModel_HPP

#include<iostream>
#include<iomanip>
#include<fstream>
#include<string>
#include<sstream>
#include<vector>
#include<stdio.h>
#include<stdlib.h>
#include<cfloat>
#include<cmath>
#include<cassert>
#include<algorithm>
#include<boost/math/distributions.hpp> 
#include<boost/random.hpp>
#include"BasicCalculation_v170122.hpp"
#include"Mono_v170731.hpp"

#define EPS (0.1)
#define PRINTON false

using namespace std;


class PatternMarkovModel_0th{
public:

	int nBeat;//Beat resolution
	vector<vector<int> > patterns;//Each pattern is represented with onset beat positions
	int nPat;//number of patterns
	Prob<int> uniPatProb;//nPat

	vector<double> uniPatDirParam;//nPat

	vector<vector<vector<int> > > data;//piece,bar,note (beat positions)
	vector<vector<int> > dataPat;//piece,bar (patternIDs)
//	vector<vector<int> > data;//piece,note (note values)
	int nPiece;
	int nBar;
	int nNote;

	vector<vector<int> > sepID;//[combID][0,1]=patID,internalID
	vector<vector<int> > combID;//[patID][internalID]=combID

	vector<vector<int> > stimes;//Score data: [piece,note] score times
	vector<vector<double> > ontimes;//Performance data: [piece,note] onset times (sec)
	double TPQN;
	double bpm;//[QN/min] (ref:144)
	double sig_t;//[sec] (ref=0.02)
	double secPerTick;//=secPerQN/TPQN

	string paramFolder;

	PatternMarkovModel_0th(){
		paramFolder="./param/";
	}//end PatternMarkovModel_0th
	~PatternMarkovModel_0th(){
	}//end ~PatternMarkovModel_0th

	void ReadPatterns(string filename){
		vector<int> v(100);
		vector<double> d(100);
		vector<string> s(100);
		stringstream ss;

		ifstream ifs(filename.c_str());
		ifs>>s[1]>>nBeat;
		vector<int> onsetVec,pattern;
		onsetVec.resize(nBeat);
		while(ifs>>s[1]){
			assert(s[1].size()==nBeat);
			for(int b=0;b<nBeat;b+=1){
				onsetVec[b]=s[1][b]-'0';
			}//endfor b

			pattern.clear();
			for(int b=0;b<nBeat;b+=1){
				if(onsetVec[b]==1){
					pattern.push_back(b);
				}//endif
			}//endfor b
			if(pattern.size()>0){
				patterns.push_back(pattern);
			}//endif

			getline(ifs,s[99]);
		}//endwhile
		ifs.close();
		nPat=patterns.size();
	}//end ReadPatterns

	void SetCombID(){
		int count=0;
		vector<int> vi(2);
		combID.resize(patterns.size());
		for(int k=0;k<patterns.size();k+=1){
			combID[k].resize(patterns[k].size());
			for(int i=0;i<patterns[k].size();i+=1){
				combID[k][i]=count;
				count+=1;
				vi[0]=k; vi[1]=i;
				sepID.push_back(vi);
			}//endfor i
		}//endfor k
		assert(count==sepID.size());
	}//end SetCombID

	void RandomInit(){
		/// Use after ReadPatterns
		uniPatProb.Resize(nPat);
		uniPatProb.Randomize();
		uniPatDirParam.assign(nPat,1);
	}//end RandomInit

	void WriteFile(string filename){
		ofstream ofs(filename.c_str());
		ofs<<"//BeatResolution: "<<nBeat<<"\n";
		ofs<<"//NumOfPatterns: "<<nPat<<"\n";

		ofs<<"### Patterns\n";
		for(int i=0;i<nPat;i+=1){
ofs<<i<<"\t"<<patterns[i].size()<<" : ";
			for(int j=0;j<patterns[i].size();j+=1){
ofs<<patterns[i][j]<<" ";
			}//endfor j
ofs<<"\n";
		}//endfor i

		ofs<<"### Unigram Pattern Prob\n";
		for(int i=0;i<nPat;i+=1){
ofs<<uniPatProb.P[i]<<"\t";
		}//endfor i
ofs<<"\n";

		ofs.close();
	}//end WriteFile

	void ReadFile(string filename){
		vector<int> v(100);
		vector<double> d(100);
		vector<string> s(100);
		stringstream ss;

		ifstream ifs(filename.c_str());
		ifs>>s[1]>>nBeat;
		getline(ifs,s[99]);
		ifs>>s[1]>>nPat;
		getline(ifs,s[99]);

		patterns.clear();
		patterns.resize(nPat);
		RandomInit();

		getline(ifs,s[99]);//### Patterns
		for(int i=0;i<nPat;i+=1){
			ifs>>v[1]>>v[2]>>s[3];
			for(int j=0;j<v[2];j+=1){
				ifs>>v[0];
				patterns[i].push_back(v[0]);
			}//endfor j
			getline(ifs,s[99]);
		}//endfor i

		getline(ifs,s[99]);//### Unigram Pattern Prob
		for(int i=0;i<nPat;i+=1){
			ifs>>uniPatProb.P[i];
		}//endfor i
		getline(ifs,s[99]);
		uniPatProb.Normalize();

		ifs.close();
	}//end ReadFile

	void SetParamFolder(string folder){
		paramFolder=folder+"/";
		stringstream ss;
		ss.str(""); ss<<"mkdir "<<paramFolder;
		system(ss.str().c_str());
	}//end 

	void ReadData(string filename,int pieceID=-1,double dataCutFac=-1,int mode=0){
		vector<int> v(100);
		vector<double> d(100);
		vector<string> s(100);
		stringstream ss;

		data.clear();
		dataPat.clear();

		vector<int> vi;
		vector<int> notes;
		vector<vector<int> > piece;
		vi.resize(nBeat);
		ifstream ifs(filename.c_str());
		getline(ifs,s[99]);//TPQN
		while(ifs>>s[1]){
			if(s[1][0]=='/'){
				if(piece.size()!=0){
					data.push_back(piece);
				}//endif
				piece.clear();
				getline(ifs,s[99]);
				continue;
			}//endif

			ifs>>v[1];
			if(v[1]!=nBeat){
				getline(ifs,s[99]);
				continue;
			}//endif
			for(int b=0;b<nBeat;b+=1){
				ifs>>vi[b];
			}//endfor b
			notes.clear();
			for(int b=0;b<nBeat;b+=1){
				if(vi[b]!=0){notes.push_back(b);}
			}//endfor b
			assert(notes.size()>0);
			piece.push_back(notes);
			getline(ifs,s[99]);
		}//endwhile
		if(piece.size()!=0){
			data.push_back(piece);
		}//endif
		ifs.close();

		SelectPiece(pieceID);
		CutData(dataCutFac,mode);

		nPiece=data.size();
		nBar=0;
		nNote=0;
		for(int l=0;l<nPiece;l+=1){
			nBar+=data[l].size();
			for(int m=0;m<data[l].size();m+=1){nNote+=data[l][m].size();}
		}//endfor l

		dataPat.clear();
		dataPat.resize(nPiece);
		int patternID;
		for(int l=0;l<nPiece;l+=1){
			for(int m=0;m<data[l].size();m+=1){
				patternID=find(patterns.begin(),patterns.end(),data[l][m])-patterns.begin();
				assert(patternID<patterns.size());
				dataPat[l].push_back(patternID);
			}//endfor m
		}//endfor l

cout<<"#nPiece,nBar,nNote:\t"<<nPiece<<"\t"<<nBar<<"\t"<<nNote<<endl;
	}//end ReadData

	void SelectPiece(int pieceID){
		if(pieceID<0){return;}
		assert(pieceID>=0 && pieceID<data.size());
		for(int l=data.size()-1;l>pieceID;l-=1){data.erase(data.begin()+l);}
		for(int l=pieceID-1;l>=0;l-=1){data.erase(data.begin()+l);}

		nPiece=data.size();
		nBar=0;
		nNote=0;
		for(int l=0;l<nPiece;l+=1){
			nBar+=data[l].size();
			for(int m=0;m<data[l].size();m+=1){nNote+=data[l][m].size();}
		}//endfor l
		dataPat.clear();
		dataPat.resize(nPiece);
		int patternID;
		for(int l=0;l<nPiece;l+=1){
			for(int m=0;m<data[l].size();m+=1){
				patternID=find(patterns.begin(),patterns.end(),data[l][m])-patterns.begin();
				assert(patternID<patterns.size());
				dataPat[l].push_back(patternID);
			}//endfor m
		}//endfor l
	}//end SelectPiece

	void CutData(double dataCutFactor,int mode=0){
		if(dataCutFactor<0){return;}
		//mode = 0(keep first), 1(keep the rest)
		int cutPos;
		for(int l=0;l<data.size();l+=1){
			cutPos=int(data[l].size()*dataCutFactor);
			if(mode==0){
				//Keep m=0,...,cutPos-1
				for(int m=data[l].size()-1;m>=cutPos;m-=1){
					data[l].erase(data[l].begin()+m);
				}//endfor m
			}else{
				//Keep m=cutPos,...,=data[l].size()-1
				for(int m=cutPos-1;m>=0;m-=1){
					data[l].erase(data[l].begin()+m);
				}//endfor m
			}//endif
		}//endfor l

		nPiece=data.size();
		nBar=0;
		nNote=0;
		for(int l=0;l<nPiece;l+=1){
			nBar+=data[l].size();
			for(int m=0;m<data[l].size();m+=1){nNote+=data[l][m].size();}
		}//endfor l
		dataPat.clear();
		dataPat.resize(nPiece);
		int patternID;
		for(int l=0;l<nPiece;l+=1){
			for(int m=0;m<data[l].size();m+=1){
				patternID=find(patterns.begin(),patterns.end(),data[l][m])-patterns.begin();
				assert(patternID<patterns.size());
				dataPat[l].push_back(patternID);
			}//endfor m
		}//endfor l
//cout<<"nPiece,nBar,nNote:\t"<<nPiece<<"\t"<<nBar<<"\t"<<nNote<<endl;
	}//end CutData

	void WritePerfmData(string filename){
		ofstream ofs(filename.c_str());
		ofs<<"//BeatResolution: "<<nBeat<<"\n";
		ofs<<"//TPQN: "<<TPQN<<"\n";
		ofs<<"//BPM: "<<bpm<<"\n";
		ofs<<"//sig_t: "<<sig_t<<"\n";

		for(int l=0;l<stimes.size();l+=1){
			ofs<<"### "<<l<<"\t"<<stimes[l].size()<<"\n";
			for(int n=0;n<stimes[l].size();n+=1){
ofs<<stimes[l][n]<<"\t"<<ontimes[l][n]<<"\n";
			}//endfor n
		}//endfor l

		ofs.close();
	}//end WritePerfmData

	void ReadPerfmData(string filename){
		vector<int> v(100);
		vector<double> d(100);
		vector<string> s(100);
		stringstream ss;

		ifstream ifs(filename.c_str());
		getline(ifs,s[99]);//nBeat
		ifs>>s[1]>>TPQN;
		getline(ifs,s[99]);
		ifs>>s[1]>>bpm;
		getline(ifs,s[99]);
		ifs>>s[1]>>sig_t;
		getline(ifs,s[99]);

		vector<int> vi;
		vector<double> vd;
		while(ifs>>s[0]){
			if(s[0]=="###"){
				vi.clear();
				vd.clear();
				ifs>>v[11]>>v[12];
				for(int n=0;n<v[12];n+=1){
					ifs>>v[1]>>d[2];
					vi.push_back(v[1]);
					vd.push_back(d[2]);
				}//endfor n
				stimes.push_back(vi);
				ontimes.push_back(vd);
			}//endif
			getline(ifs,s[99]);
		}//endwhile
		ifs.close();

		secPerTick=(60./bpm)/TPQN;
	}//end ReadPerfmData

	void LearnAdditiveSmoothing(double fac=0.1){
		uniPatProb.P.assign(nPat,fac);
		for(int l=0;l<dataPat.size();l+=1){
			for(int m=0;m<dataPat[l].size();m+=1){
				uniPatProb.P[dataPat[l][m]]+=1;
			}//endfor m
		}//endfor l
		uniPatProb.Normalize();
	}//end LearnAdditiveSmoothing

	void SetDirParam(double alpha){
		for(int k=0;k<nPat;k+=1){
			uniPatDirParam[k]=alpha*uniPatProb.P[k];
		}//endfor k
	}//end SetDirParam

	void MAP(double fac=0.1){
		/// MAP estimation for the parameters
		/// Should be used after setting uniDirParam
		for(int k=0;k<nPat;k+=1){
			uniPatProb.P[k]=uniPatDirParam[k]-1;
		}//endfor k
		for(int l=0;l<dataPat.size();l+=1){
			for(int m=0;m<dataPat[l].size();m+=1){
				uniPatProb.P[dataPat[l][m]]+=1;
			}//endfor m
		}//endfor l
		for(int k=0;k<nPat;k+=1){
			if(uniPatProb.P[k]<0){uniPatProb.P[k]=fac;}
		}//endfor k
		uniPatProb.Normalize();
	}//end MAP

	double GetLP(){
		double LP=0;
		for(int l=0;l<dataPat.size();l+=1){
			for(int m=0;m<dataPat[l].size();m+=1){
				LP+=uniPatProb.LP[dataPat[l][m]];
			}//endfor m
		}//endfor l
		return LP;
	}//end GetLP

	double OutLP(bool isSelf,int combIDFrom,int combIDTo,double dur){
		int nv=patterns[sepID[combIDTo][0]][sepID[combIDTo][1]]-patterns[sepID[combIDFrom][0]][sepID[combIDFrom][1]];
		if(!isSelf){
			nv+=nBeat;
		}//endif
		return -0.5*pow((dur-nv*secPerTick)/sig_t,2.);
	}//end OutLP

	void Transcribe(){
		SetCombID();
		for(int l=0;l<ontimes.size();l+=1){
//cout<<"Transcribe -- "<<(l+1)<<"/"<<ontimes.size()<<endl;

			///Viterbi
			vector<int> optPath(ontimes[l].size());//combID

			vector<double> LP;
			vector<vector<int> > amax;//ontimes[l].size() x sepID.size()
			amax.resize(ontimes[l].size());
			for(int n=0;n<ontimes[l].size();n+=1){amax[n].resize(sepID.size());}//endfor n

			/// ///Initialization
			LP.assign(sepID.size(),-DBL_MAX);
			for(int i=0;i<sepID.size();i+=1){
				if(sepID[i][1]!=0){continue;}
				LP[i]=uniPatProb.LP[sepID[i][0]];
			}//endfor i

			/// ///Update
			double logP;
			double dur;
			for(int n=1;n<ontimes[l].size();n+=1){
				vector<double> preLP(LP);
				dur=ontimes[l][n]-ontimes[l][n-1];
				for(int i=0;i<sepID.size();i+=1){
					//ip -> i
					if(sepID[i][1]==0){
						LP[i]=preLP[combID[0][patterns[0].size()-1]]+uniPatProb.LP[sepID[i][0]]+OutLP(false,combID[0][patterns[0].size()-1],i,dur);
						amax[n][i]=combID[0][patterns[0].size()-1];
						for(int k=0;k<patterns.size();k+=1){
							logP=preLP[combID[k][patterns[k].size()-1]]+uniPatProb.LP[sepID[i][0]]+OutLP(false,combID[k][patterns[k].size()-1],i,dur);
							if(logP>LP[i]){
								LP[i]=logP;
								amax[n][i]=combID[k][patterns[k].size()-1];
							}//endif
						}//endfor k
					}else{//sepID[i][1]>0
						//ip = i-1
						LP[i]=preLP[i-1]+OutLP(true,i-1,i,dur);
						amax[n][i]=i-1;
					}//endif
				}//endfor i
			}//endfor n

			/// ///Backtracking and set stimes
			optPath[optPath.size()-1]=0;
			for(int i=0;i<sepID.size();i+=1){
				if(LP[i]>LP[optPath[optPath.size()-1]]){
					optPath[optPath.size()-1]=i;
				}//endif
			}//endfor i
			for(int n=optPath.size()-2;n>=0;n-=1){
				optPath[n]=amax[n+1][optPath[n+1]];
			}//endfor n

			for(int n=1;n<ontimes[l].size();n+=1){
				int nv=patterns[sepID[optPath[n]][0]][sepID[optPath[n]][1]]-patterns[sepID[optPath[n-1]][0]][sepID[optPath[n-1]][1]];
				if(sepID[optPath[n]][1]==0){nv+=nBeat;}
				stimes[l][n]=stimes[l][n-1]+nv;
			}//endfor n

		}//endfor l
	}//end Transcribe

	void BayesTranscribe(int nIter=10, int seed=2){
		/// Should be used after setting Dirichlet parameters
		boost::mt19937 gen;
		gen.seed(seed);
		Prob<int> genUniPatProb(uniPatProb);
		SetCombID();

		for(int l=0;l<ontimes.size();l+=1){
if(PRINTON){cout<<"BayesTranscribe -- "<<(l+1)<<"/"<<ontimes.size()<<endl;}

			uniPatProb=genUniPatProb;
			Prob<int> maxUniPatProb(uniPatProb);
			double evidLP;
			double maxEvidLP;
			int maxIter;
			double dur;

			///Gibbs sampling
			for(int iter=0;iter<nIter;iter+=1){

				///Sample scores by forward-filtering backward sampling
				vector<int> sampledCombID(ontimes[l].size());
				vector<vector<double> > forwardVar;// ontimes[l].size() x sepID.size()
				forwardVar.resize(ontimes[l].size());
				for(int n=0;n<ontimes[l].size();n+=1){forwardVar[n].assign(sepID.size(),-DBL_MAX);}

				/// //Forward
				forwardVar[0].assign(sepID.size(),-DBL_MAX);
				for(int i=0;i<sepID.size();i+=1){
					if(sepID[i][1]!=0){continue;}
					forwardVar[0][i]=uniPatProb.LP[sepID[i][0]];
				}//endfor i

				for(int n=1;n<ontimes[l].size();n+=1){
					dur=ontimes[l][n]-ontimes[l][n-1];
					for(int i=0;i<sepID.size();i+=1){
						if(sepID[i][1]==0){
							for(int k=0;k<patterns.size();k+=1){
								forwardVar[n][i]=LogAdd(forwardVar[n][i],forwardVar[n-1][combID[k][patterns[k].size()-1]]+uniPatProb.LP[sepID[i][0]]+OutLP(false,combID[k][patterns[k].size()-1],i,dur));
							}//endfor k
						}else{//sepID[i][1]>0
							//ip = i-1
							forwardVar[n][i]=LogAdd(forwardVar[n][i],forwardVar[n-1][i-1]+OutLP(true,i-1,i,dur));
						}//endif
					}//endfor i
				}//endfor n

				evidLP=-DBL_MAX;
				for(int i=0;i<sepID.size();i+=1){
					evidLP=LogAdd(evidLP,forwardVar[ontimes[l].size()-1][i]);
				}//endfor i

				if(iter==0){
					maxEvidLP=evidLP;
					maxUniPatProb=uniPatProb;
					maxIter=iter;
				}else if(evidLP>maxEvidLP){
					maxEvidLP=evidLP;
					maxUniPatProb=uniPatProb;
					maxIter=iter;
				}//endif
if(PRINTON){cout<<"Iteration: "<<iter<<"\t-NORM(evidLP,maxEvidLP): "<<-evidLP/double(ontimes[l].size())<<"\t"<<-maxEvidLP/double(ontimes[l].size())<<"\t"<<((evidLP==maxEvidLP)? "******":"")<<endl;}

				/// //Backward sampling
				Prob<int> prob;
				prob.LP=forwardVar[ontimes[l].size()-1];
				prob.LogNormalize();
				sampledCombID[ontimes[l].size()-1]=SampleDistr(prob.P);

				for(int n=ontimes[l].size()-2;n>=0;n-=1){
					dur=ontimes[l][n+1]-ontimes[l][n];
					if(sepID[sampledCombID[n+1]][1]==0){//not-self
						prob.LP.assign(sepID.size(),-DBL_MAX);
						for(int k=0;k<patterns.size();k+=1){
							prob.LP[combID[k][patterns[k].size()-1]]=forwardVar[n][combID[k][patterns[k].size()-1]]+OutLP(false,combID[k][patterns[k].size()-1],sampledCombID[n+1],dur);
						}//endfor k
						prob.LogNormalize();
						sampledCombID[n]=SampleDistr(prob.P);
					}else{//self transition
						sampledCombID[n]=sampledCombID[n+1]-1;
					}//endif
				}//endfor n

				///Sample parameters
				uniPatProb.P=uniPatDirParam;
				for(int n=0;n<ontimes[l].size();n+=1){
					if(sepID[sampledCombID[n]][1]!=0){continue;}
					uniPatProb.P[sepID[sampledCombID[n]][0]]+=1;
				}//endfor n
				for(int k=0;k<patterns.size();k+=1){
					boost::gamma_distribution<> dst( uniPatProb.P[k], 1. );
					boost::variate_generator<boost::mt19937&, boost::gamma_distribution<> > gamma_rand( gen, dst );
					uniPatProb.P[k]=gamma_rand();
				}//endfor k
				uniPatProb.Normalize();

			}//endfor iter

			///Set optimal parameter
			uniPatProb=maxUniPatProb;

			///Viterbi
			vector<int> optPath(ontimes[l].size());//combID

			vector<double> LP;
			vector<vector<int> > amax;//ontimes[l].size() x sepID.size()
			amax.resize(ontimes[l].size());
			for(int n=0;n<ontimes[l].size();n+=1){amax[n].resize(sepID.size());}//endfor n

			/// ///Initialization
			LP.assign(sepID.size(),-DBL_MAX);
			for(int i=0;i<sepID.size();i+=1){
				if(sepID[i][1]!=0){continue;}
				LP[i]=uniPatProb.LP[sepID[i][0]];
			}//endfor i

			/// ///Update
			double logP;
			for(int n=1;n<ontimes[l].size();n+=1){
				vector<double> preLP(LP);
				dur=ontimes[l][n]-ontimes[l][n-1];
				for(int i=0;i<sepID.size();i+=1){
					//ip -> i
					if(sepID[i][1]==0){
						combID[0][patterns[0].size()-1];
						LP[i]=preLP[combID[0][patterns[0].size()-1]]+uniPatProb.LP[sepID[i][0]]+OutLP(false,combID[0][patterns[0].size()-1],i,dur);
						amax[n][i]=combID[0][patterns[0].size()-1];
						for(int k=0;k<patterns.size();k+=1){
							logP=preLP[combID[k][patterns[k].size()-1]]+uniPatProb.LP[sepID[i][0]]+OutLP(false,combID[k][patterns[k].size()-1],i,dur);
							if(logP>LP[i]){
								LP[i]=logP;
								amax[n][i]=combID[k][patterns[k].size()-1];
							}//endif
						}//endfor k
					}else{//sepID[i][1]>0
						//ip = i-1
						LP[i]=preLP[i-1]+OutLP(true,i-1,i,dur);
						amax[n][i]=i-1;
					}//endif
				}//endfor i
			}//endfor n

			/// ///Backtracking and set stimes
			optPath[optPath.size()-1]=0;
			for(int i=0;i<sepID.size();i+=1){
				if(LP[i]>LP[optPath[optPath.size()-1]]){
					optPath[optPath.size()-1]=i;
				}//endif
			}//endfor i
			for(int n=optPath.size()-2;n>=0;n-=1){
				optPath[n]=amax[n+1][optPath[n+1]];
			}//endfor n

			for(int n=1;n<ontimes[l].size();n+=1){
				int nv=patterns[sepID[optPath[n]][0]][sepID[optPath[n]][1]]-patterns[sepID[optPath[n-1]][0]][sepID[optPath[n-1]][1]];
				if(sepID[optPath[n]][1]==0){nv+=nBeat;}
				stimes[l][n]=stimes[l][n-1]+nv;
			}//endfor n

			///Write piece-specific parameter file
			stringstream ss;
			ss.str(""); ss<<paramFolder<<"param_patMM0B_"<<l<<".txt";
			WriteFile(ss.str());

		}//endfor l
	}//end BayesTranscribe



};//endclass PatternMarkovModel_0th




class PatternMarkovModel : public PatternMarkovModel_0th{
public:

//	Prob<int> uniPatProb;//nPat
	Prob<int> iniPatProb;//nPat
	vector<Prob<int> > trPatProb;//(nPat x nPat)

	vector<double> iniPatDirParam;//nPat
	vector<vector<double> > trPatDirParam;//nPat x nPat

	PatternMarkovModel(){
		paramFolder="./param/";
	}//end PatternMarkovModel
	~PatternMarkovModel(){
	}//end ~PatternMarkovModel

	void RandomInit(){
		/// Use after ReadPatterns
		uniPatProb.Resize(nPat);
		uniPatProb.Randomize();
		uniPatDirParam.assign(nPat,1);
		iniPatProb.Resize(nPat);
		iniPatProb.Randomize();
		iniPatDirParam.assign(nPat,1);
		trPatProb.resize(nPat);
		trPatDirParam.resize(nPat);
		for(int i=0;i<nPat;i+=1){
			trPatProb[i].Resize(nPat);
			trPatProb[i].Randomize();
			trPatDirParam[i].assign(nPat,1);
		}//endfor i
	}//end RandomInit

	void WriteFile(string filename){
		ofstream ofs(filename.c_str());
		ofs<<"//BeatResolution: "<<nBeat<<"\n";
		ofs<<"//NumOfPatterns: "<<nPat<<"\n";

		ofs<<"### Patterns\n";
		for(int i=0;i<nPat;i+=1){
ofs<<i<<"\t"<<patterns[i].size()<<" : ";
			for(int j=0;j<patterns[i].size();j+=1){
ofs<<patterns[i][j]<<" ";
			}//endfor j
ofs<<"\n";
		}//endfor i

		ofs<<"### Unigram Pattern Prob\n";
		for(int i=0;i<nPat;i+=1){
ofs<<uniPatProb.P[i]<<"\t";
		}//endfor i
ofs<<"\n";

		ofs<<"### Init Pattern Prob\n";
		for(int i=0;i<nPat;i+=1){
ofs<<iniPatProb.P[i]<<"\t";
		}//endfor i
ofs<<"\n";

		ofs<<"### Transition Pattern Prob\n";
		for(int i=0;i<nPat;i+=1){
			for(int ip=0;ip<nPat;ip+=1){
ofs<<trPatProb[i].P[ip]<<"\t";
			}//endfor ip
ofs<<"\n";
		}//endfor i

		ofs.close();
	}//end WriteFile

	void ReadFile(string filename){
		vector<int> v(100);
		vector<double> d(100);
		vector<string> s(100);
		stringstream ss;

		ifstream ifs(filename.c_str());
		ifs>>s[1]>>nBeat;
		getline(ifs,s[99]);
		ifs>>s[1]>>nPat;
		getline(ifs,s[99]);

		patterns.clear();
		patterns.resize(nPat);
		RandomInit();

		getline(ifs,s[99]);//### Patterns
		for(int i=0;i<nPat;i+=1){
			ifs>>v[1]>>v[2]>>s[3];
			for(int j=0;j<v[2];j+=1){
				ifs>>v[0];
				patterns[i].push_back(v[0]);
			}//endfor j
			getline(ifs,s[99]);
		}//endfor i

		getline(ifs,s[99]);//### Unigram Pattern Prob
		for(int i=0;i<nPat;i+=1){
			ifs>>uniPatProb.P[i];
		}//endfor i
		getline(ifs,s[99]);
		uniPatProb.Normalize();

		getline(ifs,s[99]);//### Init Pattern Prob
		for(int i=0;i<nPat;i+=1){
			ifs>>iniPatProb.P[i];
		}//endfor i
		getline(ifs,s[99]);
		iniPatProb.Normalize();

		getline(ifs,s[99]);//### Transition Pattern Prob
		for(int i=0;i<nPat;i+=1){
			for(int ip=0;ip<nPat;ip+=1){
				ifs>>trPatProb[i].P[ip];
			}//endfor ip
			getline(ifs,s[99]);
			trPatProb[i].Normalize();
		}//endfor i
		ifs.close();
	}//end ReadFile

	void LinearInterpolate(double coeff=0){
		vector<Prob<int> > trPatProbRaw;
		trPatProbRaw=trPatProb;
		for(int k=0;k<nPat;k+=1){
			for(int kp=0;kp<nPat;kp+=1){
				trPatProb[k].P[kp]=(1-coeff)*trPatProbRaw[k].P[kp]+coeff*uniPatProb.P[kp];
			}//endfor kp
			trPatProb[k].Normalize();
		}//endfor k
	}//end LinearInterpolate

	void LearnAdditiveSmoothing(double fac=0.1){
		uniPatProb.P.assign(nPat,fac);
		iniPatProb.P.assign(nPat,fac);
		trPatProb.resize(nPat);
		for(int i=0;i<nPat;i+=1){
			trPatProb[i].P.assign(nPat,fac);
		}//endfor i

		for(int l=0;l<dataPat.size();l+=1){
			iniPatProb.P[dataPat[l][0]]+=1;
			uniPatProb.P[dataPat[l][0]]+=1;
			for(int m=1;m<dataPat[l].size();m+=1){
				uniPatProb.P[dataPat[l][m]]+=1;
				trPatProb[dataPat[l][m-1]].P[dataPat[l][m]]+=1;
			}//endfor m
		}//endfor l

		uniPatProb.Normalize();
		iniPatProb.Normalize();
		for(int i=0;i<nPat;i+=1){
			trPatProb[i].Normalize();
		}//endfor i
	}//end LearnAdditiveSmoothing

	void SetDirParam(double alpha){
		for(int k=0;k<nPat;k+=1){
			iniPatDirParam[k]=alpha*iniPatProb.P[k];
			for(int kp=0;kp<nPat;kp+=1){
				trPatDirParam[k][kp]=alpha*trPatProb[k].P[kp];
			}//endfor kp
		}//endfor k
	}//end SetDirParam

	void MAP(double fac=0.1){
		/// MAP estimation for the parameters
		/// Should be used after setting uniDirParam
		for(int k=0;k<nPat;k+=1){
			iniPatProb.P[k]=iniPatDirParam[k]-1;
			for(int kp=0;kp<nPat;kp+=1){
				trPatProb[k].P[kp]=trPatDirParam[k][kp]-1;
			}//endfor kp
		}//endfor k

		for(int l=0;l<dataPat.size();l+=1){
			iniPatProb.P[dataPat[l][0]]+=1;
			for(int m=1;m<dataPat[l].size();m+=1){
				trPatProb[dataPat[l][m-1]].P[dataPat[l][m]]+=1;
			}//endfor m
		}//endfor l

		for(int k=0;k<nPat;k+=1){
			if(iniPatProb.P[k]<0){iniPatProb.P[k]=fac;}
			for(int kp=0;kp<nPat;kp+=1){
				if(trPatProb[k].P[kp]<0){trPatProb[k].P[kp]=fac;}
			}//endfor kp
		}//endfor k
		iniPatProb.Normalize();
		for(int i=0;i<nPat;i+=1){
			trPatProb[i].Normalize();
		}//endfor i
	}//end MAP

	double GetLP(){
		double LP=0;
		for(int l=0;l<dataPat.size();l+=1){
			LP+=iniPatProb.LP[dataPat[l][0]];
			for(int m=1;m<dataPat[l].size();m+=1){
				LP+=trPatProb[dataPat[l][m-1]].LP[dataPat[l][m]];
			}//endfor m
		}//endfor l
		return LP;
	}//end GetLP

	double OutLP(bool isSelf,int combIDFrom,int combIDTo,double dur){
		int nv=patterns[sepID[combIDTo][0]][sepID[combIDTo][1]]-patterns[sepID[combIDFrom][0]][sepID[combIDFrom][1]];
		if(!isSelf){
			nv+=nBeat;
		}//endif
		return -0.5*pow((dur-nv*secPerTick)/sig_t,2.);
	}//end OutLP

	void Transcribe(){
		SetCombID();
		for(int l=0;l<ontimes.size();l+=1){
//cout<<"Transcribe -- "<<(l+1)<<"/"<<ontimes.size()<<endl;

			///Viterbi
			vector<int> optPath(ontimes[l].size());//combID

			vector<double> LP;
			vector<vector<int> > amax;//ontimes[l].size() x sepID.size()
			amax.resize(ontimes[l].size());
			for(int n=0;n<ontimes[l].size();n+=1){amax[n].resize(sepID.size());}//endfor n

			/// ///Initialization
			LP.assign(sepID.size(),-DBL_MAX);
			for(int i=0;i<sepID.size();i+=1){
				if(sepID[i][1]!=0){continue;}
				LP[i]=iniPatProb.LP[sepID[i][0]];
//				LP[i]=uniPatProb.LP[sepID[i][0]];
			}//endfor i

			/// ///Update
			double logP;
			double dur;
			double lf1=log(0.5); double lf2=log(1-0.5);
			for(int n=1;n<ontimes[l].size();n+=1){
				vector<double> preLP(LP);
				dur=ontimes[l][n]-ontimes[l][n-1];
				for(int i=0;i<sepID.size();i+=1){
					//ip -> i
					if(sepID[i][1]==0){
						LP[i]=preLP[combID[0][patterns[0].size()-1]]+trPatProb[0].LP[sepID[i][0]]+OutLP(false,combID[0][patterns[0].size()-1],i,dur);
						amax[n][i]=combID[0][patterns[0].size()-1];
						for(int k=0;k<patterns.size();k+=1){
							logP=preLP[combID[k][patterns[k].size()-1]]+trPatProb[k].LP[sepID[i][0]]+OutLP(false,combID[k][patterns[k].size()-1],i,dur);
							if(logP>LP[i]){
								LP[i]=logP;
								amax[n][i]=combID[k][patterns[k].size()-1];
							}//endif
						}//endfor k
					}else{//sepID[i][1]>0
						//ip = i-1
						LP[i]=preLP[i-1]+OutLP(true,i-1,i,dur);
						amax[n][i]=i-1;
					}//endif
				}//endfor i
			}//endfor n

			/// ///Backtracking and set stimes
			optPath[optPath.size()-1]=0;
			for(int i=0;i<sepID.size();i+=1){
				if(LP[i]>LP[optPath[optPath.size()-1]]){
					optPath[optPath.size()-1]=i;
				}//endif
			}//endfor i
			for(int n=optPath.size()-2;n>=0;n-=1){
				optPath[n]=amax[n+1][optPath[n+1]];
			}//endfor n

			for(int n=1;n<ontimes[l].size();n+=1){
				int nv=patterns[sepID[optPath[n]][0]][sepID[optPath[n]][1]]-patterns[sepID[optPath[n-1]][0]][sepID[optPath[n-1]][1]];
				if(sepID[optPath[n]][1]==0){nv+=nBeat;}
				stimes[l][n]=stimes[l][n-1]+nv;
			}//endfor n

		}//endfor l
	}//end Transcribe


	void BayesTranscribe(int nIter=10, int seed=2){
		/// Should be used after setting Dirichlet parameters
		boost::mt19937 gen;
		gen.seed(seed);
		Prob<int> genIniPatProb(iniPatProb);//nPat
		vector<Prob<int> > genTrPatProb(trPatProb);//(nPat x nPat)
		SetCombID();

		for(int l=0;l<ontimes.size();l+=1){
if(PRINTON){cout<<"BayesTranscribe -- "<<(l+1)<<"/"<<ontimes.size()<<endl;}

			iniPatProb=genIniPatProb;
			trPatProb=genTrPatProb;
			Prob<int> maxIniPatProb(iniPatProb);//nPat
			vector<Prob<int> > maxTrPatProb(trPatProb);//(nPat x nPat)
			double evidLP;
			double maxEvidLP;
			int maxIter;
			double dur;

			///Gibbs sampling
			for(int iter=0;iter<nIter;iter+=1){

				///Sample scores by forward-filtering backward sampling
				vector<int> sampledCombID(ontimes[l].size());
				vector<vector<double> > forwardVar;// ontimes[l].size() x sepID.size()
				forwardVar.resize(ontimes[l].size());
				for(int n=0;n<ontimes[l].size();n+=1){forwardVar[n].assign(sepID.size(),-DBL_MAX);}

				/// //Forward
				forwardVar[0].assign(sepID.size(),-DBL_MAX);
				for(int i=0;i<sepID.size();i+=1){
					if(sepID[i][1]!=0){continue;}
					forwardVar[0][i]=iniPatProb.LP[sepID[i][0]];
				}//endfor i

				for(int n=1;n<ontimes[l].size();n+=1){
					dur=ontimes[l][n]-ontimes[l][n-1];
					for(int i=0;i<sepID.size();i+=1){
						if(sepID[i][1]==0){
							for(int k=0;k<patterns.size();k+=1){
								forwardVar[n][i]=LogAdd(forwardVar[n][i],forwardVar[n-1][combID[k][patterns[k].size()-1]]+trPatProb[k].LP[sepID[i][0]]+OutLP(false,combID[k][patterns[k].size()-1],i,dur));
							}//endfor k
						}else{//sepID[i][1]>0
							//ip = i-1
							forwardVar[n][i]=LogAdd(forwardVar[n][i],forwardVar[n-1][i-1]+OutLP(true,i-1,i,dur));
						}//endif
					}//endfor i
				}//endfor n

				evidLP=-DBL_MAX;
				for(int i=0;i<sepID.size();i+=1){
					evidLP=LogAdd(evidLP,forwardVar[ontimes[l].size()-1][i]);
				}//endfor i

				if(iter==0){
					maxEvidLP=evidLP;
					maxIniPatProb=iniPatProb;
					maxTrPatProb=trPatProb;
					maxIter=iter;
				}else if(evidLP>maxEvidLP){
					maxEvidLP=evidLP;
					maxIniPatProb=iniPatProb;
					maxTrPatProb=trPatProb;
					maxIter=iter;
				}//endif
if(PRINTON){cout<<"Iteration: "<<iter<<"\t-NORM(evidLP,maxEvidLP): "<<-evidLP/double(ontimes[l].size())<<"\t"<<-maxEvidLP/double(ontimes[l].size())<<"\t"<<((evidLP==maxEvidLP)? "******":"")<<endl;}

				/// //Backward sampling
				Prob<int> prob;
				prob.LP=forwardVar[ontimes[l].size()-1];
				prob.LogNormalize();
				sampledCombID[ontimes[l].size()-1]=SampleDistr(prob.P);

				for(int n=ontimes[l].size()-2;n>=0;n-=1){
					dur=ontimes[l][n+1]-ontimes[l][n];
					if(sepID[sampledCombID[n+1]][1]==0){//not-self
						prob.LP.assign(sepID.size(),-DBL_MAX);
						for(int k=0;k<patterns.size();k+=1){
							prob.LP[combID[k][patterns[k].size()-1]]=forwardVar[n][combID[k][patterns[k].size()-1]]+trPatProb[k].LP[sepID[sampledCombID[n+1]][0]]+OutLP(false,combID[k][patterns[k].size()-1],sampledCombID[n+1],dur);
						}//endfor k
						prob.LogNormalize();
						sampledCombID[n]=SampleDistr(prob.P);
					}else{//self transition
						sampledCombID[n]=sampledCombID[n+1]-1;
					}//endif
				}//endfor n

				///Sample parameters
				iniPatProb.P=iniPatDirParam;
				iniPatProb.P[sepID[sampledCombID[0]][0]]+=1;
				for(int n=0;n<ontimes[l].size();n+=1){
					if(sepID[sampledCombID[n]][1]!=0){continue;}
				}//endfor n
				for(int k=0;k<patterns.size();k+=1){
					boost::gamma_distribution<> dst( iniPatProb.P[k], 1. );
					boost::variate_generator<boost::mt19937&, boost::gamma_distribution<> > gamma_rand( gen, dst );
					iniPatProb.P[k]=gamma_rand();
				}//endfor k
				iniPatProb.Normalize();

				for(int k=0;k<patterns.size();k+=1){
					trPatProb[k].P=trPatDirParam[k];
				}//endfor k
				for(int n=1;n<ontimes[l].size();n+=1){
					if(sepID[sampledCombID[n]][1]!=0){continue;}
					trPatProb[sepID[sampledCombID[n-1]][0]].P[sepID[sampledCombID[n]][0]]+=1;
				}//endfor n
				for(int k=0;k<patterns.size();k+=1){
					for(int kp=0;kp<patterns.size();kp+=1){
						boost::gamma_distribution<> dst( trPatProb[k].P[kp], 1. );
						boost::variate_generator<boost::mt19937&, boost::gamma_distribution<> > gamma_rand( gen, dst );
						trPatProb[k].P[kp]=gamma_rand();
					}//endfor kp
					trPatProb[k].Normalize();
				}//endfor k

			}//endfor iter

			///Set optimal parameter
			iniPatProb=maxIniPatProb;
			trPatProb=maxTrPatProb;

			///Viterbi
			vector<int> optPath(ontimes[l].size());//combID

			vector<double> LP;
			vector<vector<int> > amax;//ontimes[l].size() x sepID.size()
			amax.resize(ontimes[l].size());
			for(int n=0;n<ontimes[l].size();n+=1){amax[n].resize(sepID.size());}//endfor n

			/// ///Initialization
			LP.assign(sepID.size(),-DBL_MAX);
			for(int i=0;i<sepID.size();i+=1){
				if(sepID[i][1]!=0){continue;}
				LP[i]=iniPatProb.LP[sepID[i][0]];
			}//endfor i

			/// ///Update
			double logP;
			for(int n=1;n<ontimes[l].size();n+=1){
				vector<double> preLP(LP);
				dur=ontimes[l][n]-ontimes[l][n-1];
				for(int i=0;i<sepID.size();i+=1){
					//ip -> i
					if(sepID[i][1]==0){
						combID[0][patterns[0].size()-1];
						LP[i]=preLP[combID[0][patterns[0].size()-1]]+trPatProb[0].LP[sepID[i][0]]+OutLP(false,combID[0][patterns[0].size()-1],i,dur);
						amax[n][i]=combID[0][patterns[0].size()-1];
						for(int k=0;k<patterns.size();k+=1){
							logP=preLP[combID[k][patterns[k].size()-1]]+trPatProb[k].LP[sepID[i][0]]+OutLP(false,combID[k][patterns[k].size()-1],i,dur);
							if(logP>LP[i]){
								LP[i]=logP;
								amax[n][i]=combID[k][patterns[k].size()-1];
							}//endif
						}//endfor k
					}else{//sepID[i][1]>0
						//ip = i-1
						LP[i]=preLP[i-1]+OutLP(true,i-1,i,dur);
						amax[n][i]=i-1;
					}//endif
				}//endfor i
			}//endfor n

			/// ///Backtracking and set stimes
			optPath[optPath.size()-1]=0;
			for(int i=0;i<sepID.size();i+=1){
				if(LP[i]>LP[optPath[optPath.size()-1]]){
					optPath[optPath.size()-1]=i;
				}//endif
			}//endfor i
			for(int n=optPath.size()-2;n>=0;n-=1){
				optPath[n]=amax[n+1][optPath[n+1]];
			}//endfor n

			for(int n=1;n<ontimes[l].size();n+=1){
				int nv=patterns[sepID[optPath[n]][0]][sepID[optPath[n]][1]]-patterns[sepID[optPath[n-1]][0]][sepID[optPath[n-1]][1]];
				if(sepID[optPath[n]][1]==0){nv+=nBeat;}
				stimes[l][n]=stimes[l][n-1]+nv;
			}//endfor n

			///Write piece-specific parameter file
			stringstream ss;
			ss.str(""); ss<<paramFolder<<"param_patMM1B_"<<l<<".txt";
			WriteFile(ss.str());

		}//endfor l
	}//end BayesTranscribe


};//endclass PatternMarkovModel



#endif // PatternMarkovModel_HPP
