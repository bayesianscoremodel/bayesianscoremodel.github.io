#ifndef MetricalMarkovModelMod_HPP
#define MetricalMarkovModelMod_HPP

#include<iostream>
#include<iomanip>
#include<fstream>
#include<string>
#include<sstream>
#include<vector>
#include<stdio.h>
#include<stdlib.h>
#include<cfloat>
#include<cmath>
#include<cassert>
#include<algorithm>
#include<boost/math/distributions.hpp> 
#include<boost/random.hpp>
#include"MetricalMarkovModel_v170803.hpp"

#define EPS (0.1)
//#define PRINTON_ true

using namespace std;

class MetMM1DS : public MetricalMarkovModel{
public:
	bool printOn;
// 	int nBeat;//Beat resolution
// 	Prob<int> uniProb;//nBeat
// 	vector<double> uniDirParam;//nBeat
// 	Prob<int> iniProb;
// 	vector<Prob<int> > trProb;//(nBeat x nBeat)
// 	vector<double> iniDirParam;//nBeat
// 	vector<vector<double> > trDirParam;//nBeat x nBeat

	vector<vector<vector<int> > > insPattern;//[nvID][h][g]
	vector<Prob<int> > insProb;//insertion probability r -> h
	Prob<int> shiftProb;//shift probability (2*nBeat-1) [0]<->-(nBeat-1),[nBeat-1]<->0,[2*nBeat-2]<->nBeat-1
	vector<int> shiftVal;//(2*nBeat-1)

	vector<vector<double> > insDirParam;
	vector<double> shiftDirParam;

	vector<vector<int> > insPatIndexSplitter;//[H][0,1]=nvID,h
	vector<vector<int> > insPatIndexUnifier;//[nvID][h]=H
	int nInsPat;

	vector<vector<int> > indexSplitter;//[][0,1,2,3]=b,H,g,s
	vector<vector<vector<vector<int> > > > indexUnifier;//[b][H][g][s]
//	vector<vector<int> > indexSplitter;//[][0,1,2,3,4]=b,nvID,h,g,s
//	vector<vector<vector<vector<vector<int> > > > > indexUnifier;//[b][nvID][h][g][s]
	int nEffState;//indexSplitter.size()

	MetMM1DS(){
		printOn=false;
	}//end MetMM1DS
	~MetMM1DS(){
	}//end ~MetMM1DS

	void Clear(){
		iniProb.Clear();
		iniDirParam.clear();
		trProb.clear();
		trDirParam.clear();
		insPattern.clear();
		insProb.clear();
		insDirParam.clear();
		shiftVal.clear();
		shiftProb.Clear();
		shiftDirParam.clear();
	}//end Clear

	void RandomInit(int nBeat_){
		Clear();

		nBeat=nBeat_;
		uniProb.Resize(nBeat);
		uniProb.Randomize();
		uniDirParam.assign(nBeat,1);
		iniProb.Resize(nBeat);
		iniProb.Randomize();
		iniDirParam.assign(nBeat,1);
		trProb.resize(nBeat);
		trDirParam.resize(nBeat);
		for(int b=0;b<nBeat;b+=1){
			trProb[b].Resize(nBeat);
			trProb[b].Randomize();
			trDirParam[b].assign(nBeat,1);
		}//endfor b

		insPattern.resize(nBeat);
		insProb.resize(nBeat);
		insDirParam.resize(nBeat);
		vector<int> vi;
		for(int i=0;i<nBeat;i+=1){
			vi.clear();
			vi.push_back(i+1);
			insPattern[i].push_back(vi);
			for(int j=1;j<=i;j+=1){
				vi.clear();
				vi.push_back(j);
				vi.push_back(i+1-j);
				insPattern[i].push_back(vi);
			}//endfor j
			insProb[i].Resize(insPattern[i].size());
			insProb[i].Randomize();
			insDirParam[i].assign(insPattern[i].size(),1);
		}//endfor i

		shiftVal.clear();
		for(int val=-nBeat+1;val<=nBeat-1;val+=1){
			shiftVal.push_back(val);
		}//endfor val
		shiftProb.Resize(shiftVal.size());
		shiftProb.Randomize();
		shiftDirParam.assign(shiftVal.size(),1);

		insPatIndexSplitter.clear();
		insPatIndexUnifier.clear();
		vi.clear(); vi.resize(2);
		insPatIndexUnifier.resize(nBeat);
		for(int r=0;r<nBeat;r+=1){
			insPatIndexUnifier[r].resize(insPattern[r].size());
			for(int h=0;h<insPattern[r].size();h+=1){
				insPatIndexUnifier[r][h]=insPatIndexSplitter.size();
				vi[0]=r; vi[1]=h;
				insPatIndexSplitter.push_back(vi);
			}//endfor h
		}//endfor r
		nInsPat=insPatIndexSplitter.size();
if(printOn){cout<<"nInsPat:\t"<<nInsPat<<endl;}

		indexSplitter.clear();
		indexUnifier.clear();
		bool goodIndex;
		vi.clear(); vi.resize(4);
		indexUnifier.resize(nBeat);
		for(int b=0;b<nBeat;b+=1){
			indexUnifier[b].resize(nInsPat);
			for(int H=0;H<nInsPat;H+=1){
				indexUnifier[b][H].resize(insPattern[insPatIndexSplitter[H][0]][insPatIndexSplitter[H][1]].size());
				for(int g=0;g<insPattern[insPatIndexSplitter[H][0]][insPatIndexSplitter[H][1]].size();g+=1){
					indexUnifier[b][H][g].resize(shiftVal.size());
					for(int s=0;s<shiftVal.size();s+=1){
						goodIndex=true;
						//Impose -q_{h_ng_n} < s_n <=q_{h_ng_n}
						if(shiftVal[s]>insPattern[insPatIndexSplitter[H][0]][insPatIndexSplitter[H][1]][g]){goodIndex=false;}
						if(shiftVal[s]<=-insPattern[insPatIndexSplitter[H][0]][insPatIndexSplitter[H][1]][g]){goodIndex=false;}
						if(goodIndex){
							indexUnifier[b][H][g][s]=indexSplitter.size();
							vi[0]=b; vi[1]=H; vi[2]=g; vi[3]=s;
							indexSplitter.push_back(vi);
						}else{
							indexUnifier[b][H][g][s]=-1;
						}//endif
					}//endfor s
				}//endfor g
			}//endfor H
		}//endfor b
		nEffState=indexSplitter.size();
if(printOn){cout<<"nEffState:\t"<<nEffState<<endl;}
	}//end RandomInit

	void WriteFile(string filename){
		ofstream ofs(filename.c_str());
		ofs<<"//BeatResolution: "<<nBeat<<"\n";

		ofs<<"### Unigram Prob\n";
		for(int b=0;b<nBeat;b+=1){
ofs<<uniProb.P[b]<<"\t";
		}//endfor b
ofs<<"\n";

		ofs<<"### Init Prob\n";
		for(int b=0;b<nBeat;b+=1){
ofs<<iniProb.P[b]<<"\t";
		}//endfor b
ofs<<"\n";

		ofs<<"### Transition Prob\n";
		for(int b=0;b<nBeat;b+=1){
			for(int b_=0;b_<nBeat;b_+=1){
ofs<<trProb[b].P[b_]<<"\t";
			}//endfor b_
ofs<<"\n";
		}//endfor b

		ofs<<"### Shift Prob\n";
		for(int i=0;i<shiftVal.size();i+=1){
ofs<<shiftVal[i]<<"\t"<<shiftProb.P[i]<<"\n";
		}//endfor i

		ofs<<"### Insertion Prob\n";
		for(int i=0;i<insPattern.size();i+=1){
			for(int h=0;h<insPattern[i].size();h+=1){
ofs<<i+1<<"\t"<<h<<"\t"<<insProb[i].P[h]<<"\t"<<insPattern[i][h].size()<<"\t";
				for(int g=0;g<insPattern[i][h].size();g+=1){
ofs<<insPattern[i][h][g]<<" ";
				}//endfor g
ofs<<"\n";
			}//endfor h
		}//endfor i

		ofs.close();
	}//end WriteFile

	void ReadFile(string filename){
		vector<int> v(100);
		vector<double> d(100);
		vector<string> s(100);
		stringstream ss;

		ifstream ifs(filename.c_str());
		ifs>>s[1]>>nBeat;
		getline(ifs,s[99]);

		RandomInit(nBeat);

		getline(ifs,s[99]);//### Unigram Prob
		for(int b=0;b<nBeat;b+=1){
			ifs>>uniProb.P[b];
		}//endfor b
		getline(ifs,s[99]);
		uniProb.Normalize();

		getline(ifs,s[99]);//### Init Prob
		for(int b=0;b<nBeat;b+=1){
			ifs>>iniProb.P[b];
		}//endfor b
		getline(ifs,s[99]);
		iniProb.Normalize();

		getline(ifs,s[99]);//### Transition Prob
		for(int b=0;b<nBeat;b+=1){
			for(int b_=0;b_<nBeat;b_+=1){
				ifs>>trProb[b].P[b_];
			}//endfor b_
			getline(ifs,s[99]);
			trProb[b].Normalize();
		}//endfor b

		getline(ifs,s[99]);//### Shift Prob
		for(int i=0;i<shiftVal.size();i+=1){
			ifs>>d[1]>>shiftProb.P[i];
			getline(ifs,s[99]);
		}//endfor i
		shiftProb.Normalize();

		getline(ifs,s[99]);//### Insertion Prob
		for(int i=0;i<insPattern.size();i+=1){
			for(int h=0;h<insPattern[i].size();h+=1){
				ifs>>d[1]>>d[2]>>insProb[i].P[h];
				getline(ifs,s[99]);
			}//endfor h
			insProb[i].Normalize();
		}//endfor i

		ifs.close();
	}//end ReadFile

	void ReadFileFromBasic(string filename){
		MetricalMarkovModel basicModel;
		basicModel.ReadFile(filename);
		nBeat=basicModel.nBeat;
		RandomInit(nBeat);
		uniProb=basicModel.uniProb;
		iniProb=basicModel.iniProb;
		trProb=basicModel.trProb;
	}//end ReadFileFromBasic

	void SetSimpleModificationModel(double noShiftP=0.9,double noInsP=0.9){
		for(int s=0;s<shiftVal.size();s+=1){
			if(s==nBeat-1){
				shiftProb.P[s]=noShiftP;
			}else{
				shiftProb.P[s]=(1-noShiftP)/double(shiftVal.size()-1);
			}//endif
		}//endfor s
		shiftProb.Normalize();
		for(int i=0;i<nBeat;i+=1){
			insProb[i].P[0]=noInsP;
			for(int h=1;h<insPattern[i].size();h+=1){
				insProb[i].P[h]=(1-noInsP)/double(insPattern[i].size()-1);
			}//endfor h
			insProb[i].Normalize();
		}//endfor i
	}//end SetSimpleModificationModel

	void SetDirParam(double alpha_ini,double alpha_tr,double alpha_shift,double alpha_ins){
		for(int b=0;b<nBeat;b+=1){
			iniDirParam[b]=alpha_ini*iniProb.P[b];
			for(int bp=0;bp<nBeat;bp+=1){
				trDirParam[b][bp]=alpha_tr*trProb[b].P[bp];
			}//endfor bp
		}//endfor b
		for(int i=0;i<shiftVal.size();i+=1){
			shiftDirParam[i]=alpha_shift*shiftProb.P[i];
		}//endfor i
		for(int i=0;i<nBeat;i+=1){
			for(int h=0;h<insPattern[i].size();h+=1){
				insDirParam[i][h]=alpha_ins*insProb[i].P[h];
			}//endfor h
		}//endfor i
	}//end SetDirParam

	double OutLP(int ip,int i,double dur){
		int nv=insPattern[insPatIndexSplitter[indexSplitter[i][1]][0]][insPatIndexSplitter[indexSplitter[i][1]][1]][indexSplitter[i][2]]+shiftVal[indexSplitter[i][3]]-shiftVal[indexSplitter[ip][3]];
		if(nv>0){
			return -0.5*pow((dur-nv*secPerTick)/sig_t,2.);
		}else{
			return -DBL_MAX;
		}//endif
	}//end OutLP

	double TrLP(int ip,int i){
		int nvID=indexSplitter[i][0]-indexSplitter[ip][0]+((indexSplitter[i][0]>indexSplitter[ip][0])? 0:nBeat)-1;
		if(indexSplitter[i][2]==0){
			if(indexSplitter[ip][2]==insPattern[insPatIndexSplitter[indexSplitter[ip][1]][0]][insPatIndexSplitter[indexSplitter[ip][1]][1]].size()-1){
				if(insPatIndexSplitter[indexSplitter[i][1]][0]==nvID){
					return trProb[indexSplitter[ip][0]].LP[indexSplitter[i][0]]+insProb[insPatIndexSplitter[indexSplitter[i][1]][0]].LP[insPatIndexSplitter[indexSplitter[i][1]][1]]+shiftProb.LP[indexSplitter[i][3]];
				}else{
					return -DBL_MAX;
				}//endif
			}else{
				return -DBL_MAX;
			}//endif
		}else{//indexSplitter[i][2]>0
			if(indexSplitter[i][2]==indexSplitter[ip][2]+1
			   && indexSplitter[i][0]==indexSplitter[ip][0]
			   && indexSplitter[i][1]==indexSplitter[ip][1]){
				return shiftProb.LP[indexSplitter[i][3]];
			}else{
				return -DBL_MAX;
			}//endif
		}//endif
	}//end TrLP

	double FirstTrLP(int ip,int i){
		int nvID=indexSplitter[i][0]-indexSplitter[ip][0]+((indexSplitter[i][0]>indexSplitter[ip][0])? 0:nBeat)-1;
		if(insPatIndexSplitter[indexSplitter[i][1]][0]==nvID){
			return trProb[indexSplitter[ip][0]].LP[indexSplitter[i][0]]+insProb[insPatIndexSplitter[indexSplitter[i][1]][0]].LP[insPatIndexSplitter[indexSplitter[i][1]][1]]+shiftProb.LP[indexSplitter[i][3]];
		}else{
			return -DBL_MAX;
		}//endif
	}//end FirstTrLP

	int MetPos(int i){
		int delta=0;
		for(int g=insPattern[insPatIndexSplitter[indexSplitter[i][1]][0]][insPatIndexSplitter[indexSplitter[i][1]][1]][indexSplitter[i][2]]+1;g<insPattern[insPatIndexSplitter[indexSplitter[i][1]][0]][insPatIndexSplitter[indexSplitter[i][1]][1]].size();g+=1){
			delta+=insPattern[insPatIndexSplitter[indexSplitter[i][1]][0]][insPatIndexSplitter[indexSplitter[i][1]][1]][g];
		}//endfor h
		return (indexSplitter[i][0]-delta+shiftVal[indexSplitter[i][3]]+10*nBeat)%nBeat;
	}//end MetPos

	double GetLP(){
		double LP=0;

		for(int l=0;l<data.size();l+=1){
			vector<int> metposSeq;
			for(int m=0;m<data[l].size();m+=1){
				for(int n=0;n<data[l][m].size();n+=1){
					metposSeq.push_back(data[l][m][n]);
				}//endfor n
			}//endfor m
			int len=metposSeq.size();
			vector<vector<double> > forwardVar;
			forwardVar.resize(len);
			for(int n=0;n<len;n+=1){
				forwardVar[n].assign(nEffState,-DBL_MAX);
				if(n==0){
					for(int b=0;b<nBeat;b+=1){
						for(int s=0;s<shiftVal.size();s+=1){
							if(indexUnifier[b][28][0][s]<0){continue;}
							if((b+shiftVal[s]+nBeat)%nBeat!=metposSeq[n]){continue;}
							forwardVar[n][indexUnifier[b][28][0][s]]=iniProb.LP[b]+shiftProb.LP[s];
						}//endfor s
					}//endfor b
					continue;
				}else if(n==1){
					for(int i=0;i<nEffState;i+=1){
						if(MetPos(i)!=metposSeq[n]){continue;}
						for(int ip=0;ip<nEffState;ip+=1){
							forwardVar[n][i]=LogAdd(forwardVar[n][i],forwardVar[n-1][ip]+FirstTrLP(ip,i));
						}//endfor ip
					}//endfor i
					continue;
				}//endif

				for(int i=0;i<nEffState;i+=1){
					if(MetPos(i)!=metposSeq[n]){continue;}
					for(int ip=0;ip<nEffState;ip+=1){
						forwardVar[n][i]=LogAdd(forwardVar[n][i],forwardVar[n-1][ip]+TrLP(ip,i));
					}//endfor ip
				}//endfor i
			}//endfor n

			double partLP=-DBL_MAX;
			for(int i=0;i<nEffState;i+=1){
				partLP=LogAdd(partLP,forwardVar[len-1][i]);
			}//endfor i
			LP+=partLP;
		}//endfor l

		return LP;
	}//end GetLP

	void MAP(int nIter=10){
		/// MAP estimation for the parameters
		/// Should be used after setting dirichlet parameters
		boost::mt19937 gen;
		Prob<int> genIniProb(iniProb);
		vector<Prob<int> > genTrProb(trProb);//(nBeat x nBeat)
		vector<Prob<int> > genInsProb(insProb);//insertion probability r -> h
		Prob<int> genShiftProb(shiftProb);//shift probability (2*nBeat-1) [0]<->-(nBeat-1),[nBeat-1]<->0,[2*nBeat-2]<->nBeat-1

		for(int l=0;l<data.size();l+=1){

if(printOn){cout<<"MAP -- "<<(l+1)<<"/"<<data.size()<<endl;}

			vector<int> metposSeq;
			for(int m=0;m<data[l].size();m+=1){
				for(int n=0;n<data[l][m].size();n+=1){
					metposSeq.push_back(data[l][m][n]);
				}//endfor n
			}//endfor m
			int len=metposSeq.size();

			iniProb=genIniProb;
			trProb=genTrProb;
			insProb=genInsProb;
			shiftProb=genShiftProb;
			Prob<int> maxIniProb(iniProb);
			vector<Prob<int> > maxTrProb(trProb);//(nBeat x nBeat)
			vector<Prob<int> > maxInsProb(insProb);//insertion probability r -> h
			Prob<int> maxShiftProb(shiftProb);//shift probability (2*nBeat-1) [0]<->-(nBeat-1),[nBeat-1]<->0,[2*nBeat-2]<->nBeat-1
			double evidLP;
			double maxEvidLP;
			int maxIter;

			///Gibbs sampling
			for(int iter=0;iter<nIter;iter+=1){

				///Sample scores by forward-filtering backward sampling
				vector<int> sampledStates(len);
				vector<vector<double> > forwardVar;// ontimes[l].size() x nEffState
				forwardVar.resize(len);
				for(int n=0;n<len;n+=1){
					forwardVar[n].assign(nEffState,-DBL_MAX);
					if(n==0){
						for(int b=0;b<nBeat;b+=1){
							for(int s=0;s<shiftVal.size();s+=1){
								if(indexUnifier[b][28][0][s]<0){continue;}
								if((b+shiftVal[s]+nBeat)%nBeat!=metposSeq[n]){continue;}
								forwardVar[n][indexUnifier[b][28][0][s]]=iniProb.LP[b]+shiftProb.LP[s];
							}//endfor s
						}//endfor b
						continue;
					}else if(n==1){
						for(int i=0;i<nEffState;i+=1){
							if(MetPos(i)!=metposSeq[n]){continue;}
							for(int ip=0;ip<nEffState;ip+=1){
								forwardVar[n][i]=LogAdd(forwardVar[n][i],forwardVar[n-1][ip]+FirstTrLP(ip,i));
							}//endfor ip
						}//endfor i
						continue;
					}//endif
	
					for(int i=0;i<nEffState;i+=1){
						if(MetPos(i)!=metposSeq[n]){continue;}
						for(int ip=0;ip<nEffState;ip+=1){
							forwardVar[n][i]=LogAdd(forwardVar[n][i],forwardVar[n-1][ip]+TrLP(ip,i));
						}//endfor ip
					}//endfor i
				}//endfor n

				evidLP=-DBL_MAX;
				for(int i=0;i<nEffState;i+=1){
					evidLP=LogAdd(evidLP,forwardVar[len-1][i]);
				}//endfor i

				if(iter==0 || evidLP>maxEvidLP){
					maxEvidLP=evidLP;
					maxIniProb=iniProb;
					maxTrProb=trProb;
					maxInsProb=insProb;
					maxShiftProb=shiftProb;
					maxIter=iter;
				}//endif
if(printOn){cout<<"Iteration: "<<iter<<"\t-NORM(evidLP,maxEvidLP): "<<-evidLP/double(len)<<"\t"<<-maxEvidLP/double(len)<<"\t"<<((evidLP==maxEvidLP)? "******":"")<<endl;}

				/// //Backward sampling
				Prob<int> prob;
				prob.LP=forwardVar[len-1];
				prob.LogNormalize();
				sampledStates[len-1]=SampleDistr(prob.P);

				for(int n=len-2;n>=1;n-=1){
					for(int i=0;i<nEffState;i+=1){
						prob.LP[i]=forwardVar[n][i]+TrLP(i,sampledStates[n+1]);
					}//endfor i
					prob.LogNormalize();
					sampledStates[n]=SampleDistr(prob.P);
				}//endfor n

				prob.LP.assign(nEffState,-DBL_MAX);
				for(int b=0;b<nBeat;b+=1){
					for(int s=0;s<shiftVal.size();s+=1){
						if(indexUnifier[b][28][0][s]<0){continue;}
						if((b+shiftVal[s]+nBeat)%nBeat!=metposSeq[0]){continue;}
						prob.LP[indexUnifier[b][28][0][s]]=forwardVar[0][indexUnifier[b][28][0][s]]+FirstTrLP(indexUnifier[b][28][0][s],sampledStates[1]);
					}//endfor s
				}//endfor b
				prob.LogNormalize();
				sampledStates[0]=SampleDistr(prob.P);

				///Sample parameters
				iniProb.P=iniDirParam;
				iniProb.P[indexSplitter[sampledStates[0]][0]]+=1;
				for(int b=0;b<nBeat;b+=1){
					boost::gamma_distribution<> dst( iniProb.P[b], 1. );
					boost::variate_generator<boost::mt19937&, boost::gamma_distribution<> > gamma_rand( gen, dst );
					iniProb.P[b]=gamma_rand();
				}//endfor b
				iniProb.Normalize();

				for(int b=0;b<nBeat;b+=1){
					trProb[b].P=trDirParam[b];
				}//endfor b
				for(int n=1;n<len;n+=1){
					if(indexSplitter[sampledStates[n]][2]!=0){continue;}
					trProb[indexSplitter[sampledStates[n-1]][0]].P[indexSplitter[sampledStates[n]][0]]+=1;
				}//endfor n
				for(int b=0;b<nBeat;b+=1){
					for(int bp=0;bp<nBeat;bp+=1){
						boost::gamma_distribution<> dst( trProb[b].P[bp], 1. );
						boost::variate_generator<boost::mt19937&, boost::gamma_distribution<> > gamma_rand( gen, dst );
						trProb[b].P[bp]=gamma_rand();
					}//endfor bp
					trProb[b].Normalize();
				}//endfor b

				for(int r=0;r<nBeat;r+=1){
					insProb[r].P=insDirParam[r];
				}//endfor r
				for(int n=1;n<len;n+=1){
					if(indexSplitter[sampledStates[n]][2]!=0){continue;}
					insProb[insPatIndexSplitter[indexSplitter[sampledStates[n]][1]][0]].P[insPatIndexSplitter[indexSplitter[sampledStates[n]][1]][1]]+=1;
				}//endfor n
				for(int r=0;r<nBeat;r+=1){
					for(int h=0;h<insDirParam[r].size();h+=1){
						boost::gamma_distribution<> dst( insProb[r].P[h], 1. );
						boost::variate_generator<boost::mt19937&, boost::gamma_distribution<> > gamma_rand( gen, dst );
						insProb[r].P[h]=gamma_rand();
					}//endfor h
					insProb[r].Normalize();
				}//endfor r

				shiftProb.P=shiftDirParam;
				for(int n=0;n<len;n+=1){
					shiftProb.P[indexSplitter[sampledStates[n]][3]]+=1;
				}//endfor n
				for(int s=0;s<shiftVal.size();s+=1){
					boost::gamma_distribution<> dst( shiftProb.P[s], 1. );
					boost::variate_generator<boost::mt19937&, boost::gamma_distribution<> > gamma_rand( gen, dst );
					shiftProb.P[s]=gamma_rand();
				}//endfor s
				shiftProb.Normalize();

			}//endfor iter

			///Set optimal parameter
			iniProb=maxIniProb;
			trProb=maxTrProb;
			insProb=maxInsProb;
			shiftProb=maxShiftProb;

		}//endfor l

	}//end MAP


	void Transcribe(){
		for(int l=0;l<ontimes.size();l+=1){
// cout<<"Transcribe -- "<<(l+1)<<"/"<<ontimes.size()<<endl;

			///Viterbi
			vector<int> optPath(ontimes[l].size());
			vector<double> LP(nEffState);
			vector<vector<int> > amax;
			amax.resize(ontimes[l].size());
			for(int n=0;n<ontimes[l].size();n+=1){amax[n].resize(nEffState);}

			/// ///Initialization
			//(n=0) H=28, g=0, b,s are the only variables
			LP.assign(nEffState,-DBL_MAX);
			for(int b=0;b<nBeat;b+=1){
				for(int s=0;s<shiftVal.size();s+=1){
					if(indexUnifier[b][28][0][s]<0){continue;}
					LP[indexUnifier[b][28][0][s]]=iniProb.LP[b]+shiftProb.LP[s];
				}//endfor s
			}//endfor b

			/// ///Update
			double dur;
			double logP;
			for(int n=1;n<ontimes[l].size();n+=1){
				vector<double> preLP(LP);
				dur=ontimes[l][n]-ontimes[l][n-1];
				LP.assign(nEffState,-DBL_MAX);

				if(n==1){
					for(int i=0;i<nEffState;i+=1){
						if(indexSplitter[i][2]!=0){continue;}
						LP[i]=preLP[indexUnifier[0][28][0][0]]+FirstTrLP(indexUnifier[0][28][0][0],i)+OutLP(indexUnifier[0][28][0][0],i,dur);
						amax[n][i]=indexUnifier[0][28][0][0];
						for(int b=0;b<nBeat;b+=1){
							for(int s=0;s<shiftVal.size();s+=1){
								if(indexUnifier[b][28][0][s]<0){continue;}
								logP=preLP[indexUnifier[b][28][0][s]]+FirstTrLP(indexUnifier[b][28][0][s],i)+OutLP(indexUnifier[b][28][0][s],i,dur);
								if(logP>LP[i]){LP[i]=logP; amax[n][i]=indexUnifier[b][28][0][s];}
							}//endfor s
						}//endfor b
					}//endfor i
					continue;
				}//endif

				double trlp,outlp;
				for(int i=0;i<nEffState;i+=1){
					LP[i]=preLP[0]+TrLP(0,i)+OutLP(0,i,dur);
					amax[n][i]=0;
					for(int ip=0;ip<nEffState;ip+=1){
						trlp=TrLP(ip,i);
						if(trlp<-1E10){continue;}
						outlp=OutLP(ip,i,dur);
						if(outlp<-1E10){continue;}
						logP=preLP[ip]+trlp+outlp;
						if(logP>LP[i]){LP[i]=logP; amax[n][i]=ip;}
					}//endfor ip
				}//endfor i

			}//endfor n

			/// ///Backtracking and set stimes
			optPath[optPath.size()-1]=0;
			for(int i=0;i<nEffState;i+=1){
				if(LP[i]>LP[optPath[optPath.size()-1]]){optPath[optPath.size()-1]=i;}//endif
			}//endfor i
			for(int n=optPath.size()-2;n>=0;n-=1){optPath[n]=amax[n+1][optPath[n+1]];}//endfor n

			for(int n=1;n<ontimes[l].size();n+=1){
				stimes[l][n]=stimes[l][n-1]+insPattern[insPatIndexSplitter[indexSplitter[optPath[n]][1]][0]][insPatIndexSplitter[indexSplitter[optPath[n]][1]][1]][indexSplitter[optPath[n]][2]]+shiftVal[indexSplitter[optPath[n]][3]]-shiftVal[indexSplitter[optPath[n-1]][3]];
			}//endfor n
		}//endfor l
	}//end Transcribe


	void BayesTranscribe(int nIter=10, int seed=2){
		/// Should be used after setting Dirichlet parameters
		boost::mt19937 gen;
		gen.seed(seed);
		Prob<int> genIniProb(iniProb);
		vector<Prob<int> > genTrProb(trProb);//(nBeat x nBeat)
		vector<Prob<int> > genInsProb(insProb);//insertion probability r -> h
		Prob<int> genShiftProb(shiftProb);//shift probability (2*nBeat-1) [0]<->-(nBeat-1),[nBeat-1]<->0,[2*nBeat-2]<->nBeat-1

		for(int l=0;l<ontimes.size();l+=1){
if(printOn){cout<<"BayesTranscribe -- "<<(l+1)<<"/"<<ontimes.size()<<endl;}

			iniProb=genIniProb;
			trProb=genTrProb;
			insProb=genInsProb;
			shiftProb=genShiftProb;
			Prob<int> maxIniProb(iniProb);
			vector<Prob<int> > maxTrProb(trProb);//(nBeat x nBeat)
			vector<Prob<int> > maxInsProb(insProb);//insertion probability r -> h
			Prob<int> maxShiftProb(shiftProb);//shift probability (2*nBeat-1) [0]<->-(nBeat-1),[nBeat-1]<->0,[2*nBeat-2]<->nBeat-1
			double evidLP;
			double maxEvidLP;
			int maxIter;
			double dur;

			///Gibbs sampling
			for(int iter=0;iter<nIter;iter+=1){

				///Sample scores by forward-filtering backward sampling
				vector<int> sampledStates(ontimes[l].size());
				vector<vector<double> > forwardVar;// ontimes[l].size() x nEffState
				forwardVar.resize(ontimes[l].size());
				for(int n=0;n<ontimes[l].size();n+=1){forwardVar[n].assign(nEffState,-DBL_MAX);}

				/// //Forward
				//(n=0) H=28, g=0, b,s are the only variables
				for(int b=0;b<nBeat;b+=1){
					for(int s=0;s<shiftVal.size();s+=1){
						if(indexUnifier[b][28][0][s]<0){continue;}
						forwardVar[0][indexUnifier[b][28][0][s]]=iniProb.LP[b]+shiftProb.LP[s];
					}//endfor s
				}//endfor b

				for(int n=1;n<ontimes[l].size();n+=1){
					dur=ontimes[l][n]-ontimes[l][n-1];
//cout<<"n:\t"<<n<<endl;
					if(n==1){
						for(int i=0;i<nEffState;i+=1){
							if(indexSplitter[i][2]!=0){continue;}
							for(int b=0;b<nBeat;b+=1){
								for(int s=0;s<shiftVal.size();s+=1){
									if(indexUnifier[b][28][0][s]<0){continue;}
									forwardVar[n][i]=LogAdd(forwardVar[n][i],
										forwardVar[n-1][indexUnifier[b][28][0][s]]+FirstTrLP(indexUnifier[b][28][0][s],i)+OutLP(indexUnifier[b][28][0][s],i,dur)
									);
								}//endfor s
							}//endfor b
						}//endfor i
						continue;
					}//endif

					double trlp,outlp;
					for(int i=0;i<nEffState;i+=1){
						for(int ip=0;ip<nEffState;ip+=1){
							trlp=TrLP(ip,i);
							if(trlp<-1E10){continue;}
							outlp=OutLP(ip,i,dur);
							if(outlp<-1E10){continue;}
							forwardVar[n][i]=LogAdd(forwardVar[n][i],forwardVar[n-1][ip]+trlp+outlp);
						}//endfor ip
					}//endfor i

				}//endfor n

				evidLP=-DBL_MAX;
				for(int i=0;i<nEffState;i+=1){
					evidLP=LogAdd(evidLP,forwardVar[ontimes[l].size()-1][i]);
				}//endfor i

				if(iter==0 || evidLP>maxEvidLP){
					maxEvidLP=evidLP;
					maxIniProb=iniProb;
					maxTrProb=trProb;
					maxInsProb=insProb;
					maxShiftProb=shiftProb;
					maxIter=iter;
				}//endif
if(printOn){cout<<"Iteration: "<<iter<<"\t-NORM(evidLP,maxEvidLP): "<<-evidLP/double(ontimes[l].size())<<"\t"<<-maxEvidLP/double(ontimes[l].size())<<"\t"<<((evidLP==maxEvidLP)? "******":"")<<endl;}

				/// //Backward sampling
				Prob<int> prob;
				prob.LP=forwardVar[ontimes[l].size()-1];
				prob.LogNormalize();
				sampledStates[ontimes[l].size()-1]=SampleDistr(prob.P);

				for(int n=ontimes[l].size()-2;n>=1;n-=1){
					for(int i=0;i<nEffState;i+=1){
						prob.LP[i]=forwardVar[n][i]+TrLP(i,sampledStates[n+1])+OutLP(i,sampledStates[n+1],ontimes[l][n+1]-ontimes[l][n]);
					}//endfor i
					prob.LogNormalize();
					sampledStates[n]=SampleDistr(prob.P);
				}//endfor n

				prob.LP.assign(nEffState,-DBL_MAX);
				for(int b=0;b<nBeat;b+=1){
					for(int s=0;s<shiftVal.size();s+=1){
						if(indexUnifier[b][28][0][s]<0){continue;}
						prob.LP[indexUnifier[b][28][0][s]]=forwardVar[0][indexUnifier[b][28][0][s]]+FirstTrLP(indexUnifier[b][28][0][s],sampledStates[1])+OutLP(indexUnifier[b][28][0][s],sampledStates[1],ontimes[l][1]-ontimes[l][0]);
					}//endfor s
				}//endfor b
				prob.LogNormalize();
				sampledStates[0]=SampleDistr(prob.P);

				///Sample parameters
				iniProb.P=iniDirParam;
				iniProb.P[indexSplitter[sampledStates[0]][0]]+=1;
				for(int b=0;b<nBeat;b+=1){
					boost::gamma_distribution<> dst( iniProb.P[b], 1. );
					boost::variate_generator<boost::mt19937&, boost::gamma_distribution<> > gamma_rand( gen, dst );
					iniProb.P[b]=gamma_rand();
				}//endfor b
				iniProb.Normalize();

				for(int b=0;b<nBeat;b+=1){
					trProb[b].P=trDirParam[b];
				}//endfor b
				for(int n=1;n<ontimes[l].size();n+=1){
					if(indexSplitter[sampledStates[n]][2]!=0){continue;}
					trProb[indexSplitter[sampledStates[n-1]][0]].P[indexSplitter[sampledStates[n]][0]]+=1;
				}//endfor n
				for(int b=0;b<nBeat;b+=1){
					for(int bp=0;bp<nBeat;bp+=1){
						boost::gamma_distribution<> dst( trProb[b].P[bp], 1. );
						boost::variate_generator<boost::mt19937&, boost::gamma_distribution<> > gamma_rand( gen, dst );
						trProb[b].P[bp]=gamma_rand();
					}//endfor bp
					trProb[b].Normalize();
				}//endfor b

				for(int r=0;r<nBeat;r+=1){
					insProb[r].P=insDirParam[r];
				}//endfor r
				for(int n=1;n<ontimes[l].size();n+=1){
					if(indexSplitter[sampledStates[n]][2]!=0){continue;}
					insProb[insPatIndexSplitter[indexSplitter[sampledStates[n]][1]][0]].P[insPatIndexSplitter[indexSplitter[sampledStates[n]][1]][1]]+=1;
				}//endfor n
				for(int r=0;r<nBeat;r+=1){
					for(int h=0;h<insDirParam[r].size();h+=1){
						boost::gamma_distribution<> dst( insProb[r].P[h], 1. );
						boost::variate_generator<boost::mt19937&, boost::gamma_distribution<> > gamma_rand( gen, dst );
						insProb[r].P[h]=gamma_rand();
					}//endfor h
					insProb[r].Normalize();
				}//endfor r

				shiftProb.P=shiftDirParam;
				for(int n=0;n<ontimes[l].size();n+=1){
					shiftProb.P[indexSplitter[sampledStates[n]][3]]+=1;
				}//endfor n
				for(int s=0;s<shiftVal.size();s+=1){
					boost::gamma_distribution<> dst( shiftProb.P[s], 1. );
					boost::variate_generator<boost::mt19937&, boost::gamma_distribution<> > gamma_rand( gen, dst );
					shiftProb.P[s]=gamma_rand();
				}//endfor s
				shiftProb.Normalize();

			}//endfor iter


			///Set optimal parameter
			iniProb=maxIniProb;
			trProb=maxTrProb;
			insProb=maxInsProb;
			shiftProb=maxShiftProb;

			///Viterbi
			vector<int> optPath(ontimes[l].size());
			vector<double> LP(nEffState);
			vector<vector<int> > amax;
			amax.resize(ontimes[l].size());
			for(int n=0;n<ontimes[l].size();n+=1){amax[n].resize(nEffState);}

			/// ///Initialization
			//(n=0) H=28, g=0, b,s are the only variables
			LP.assign(nEffState,-DBL_MAX);
			for(int b=0;b<nBeat;b+=1){
				for(int s=0;s<shiftVal.size();s+=1){
					if(indexUnifier[b][28][0][s]<0){continue;}
					LP[indexUnifier[b][28][0][s]]=iniProb.LP[b]+shiftProb.LP[s];
				}//endfor s
			}//endfor b

			/// ///Update
			double logP;
			for(int n=1;n<ontimes[l].size();n+=1){
				vector<double> preLP(LP);
				dur=ontimes[l][n]-ontimes[l][n-1];
				LP.assign(nEffState,-DBL_MAX);

				if(n==1){
					for(int i=0;i<nEffState;i+=1){
						if(indexSplitter[i][2]!=0){continue;}
						LP[i]=preLP[indexUnifier[0][28][0][0]]+FirstTrLP(indexUnifier[0][28][0][0],i)+OutLP(indexUnifier[0][28][0][0],i,dur);
						amax[n][i]=indexUnifier[0][28][0][0];
						for(int b=0;b<nBeat;b+=1){
							for(int s=0;s<shiftVal.size();s+=1){
								if(indexUnifier[b][28][0][s]<0){continue;}
								logP=preLP[indexUnifier[b][28][0][s]]+FirstTrLP(indexUnifier[b][28][0][s],i)+OutLP(indexUnifier[b][28][0][s],i,dur);
								if(logP>LP[i]){LP[i]=logP; amax[n][i]=indexUnifier[b][28][0][s];}
							}//endfor s
						}//endfor b
					}//endfor i
					continue;
				}//endif

				double trlp,outlp;
				for(int i=0;i<nEffState;i+=1){
					LP[i]=preLP[0]+TrLP(0,i)+OutLP(0,i,dur);
					amax[n][i]=0;
					for(int ip=0;ip<nEffState;ip+=1){
						trlp=TrLP(ip,i);
						if(trlp<-1E10){continue;}
						outlp=OutLP(ip,i,dur);
						if(outlp<-1E10){continue;}
						logP=preLP[ip]+trlp+outlp;
						if(logP>LP[i]){LP[i]=logP; amax[n][i]=ip;}
					}//endfor ip
				}//endfor i
			}//endfor n

			/// ///Backtracking and set stimes
			optPath[optPath.size()-1]=0;
			for(int i=0;i<nEffState;i+=1){
				if(LP[i]>LP[optPath[optPath.size()-1]]){optPath[optPath.size()-1]=i;}//endif
			}//endfor i
			for(int n=optPath.size()-2;n>=0;n-=1){optPath[n]=amax[n+1][optPath[n+1]];}//endfor n

			for(int n=1;n<ontimes[l].size();n+=1){
				stimes[l][n]=stimes[l][n-1]+insPattern[insPatIndexSplitter[indexSplitter[optPath[n]][1]][0]][insPatIndexSplitter[indexSplitter[optPath[n]][1]][1]][indexSplitter[optPath[n]][2]]+shiftVal[indexSplitter[optPath[n]][3]]-shiftVal[indexSplitter[optPath[n-1]][3]];
			}//endfor n

			///Write piece-specific parameter file
			stringstream ss;
			ss.str(""); ss<<paramFolder<<"param_metMM1DS_"<<l<<".txt";
			WriteFile(ss.str());

		}//endfor l
	}//end BayesTranscribe

};//endclass MetMM1DS

class MetMM1S : public MetMM1DS{
public:
	vector<vector<int> > indexSplitter;//[][0,1]=b,s
	vector<vector<int> > indexUnifier;//[b][s]
	int nEffState;//indexSplitter.size()

	MetMM1S(){
		printOn=false;
	}//end MetMM1S
	~MetMM1S(){
	}//end ~MetMM1S

	void Clear(){
		iniProb.Clear();
		iniDirParam.clear();
		trProb.clear();
		trDirParam.clear();
		shiftVal.clear();
		shiftProb.Clear();
		shiftDirParam.clear();
	}//end Clear

	void RandomInit(int nBeat_){
		Clear();
		nBeat=nBeat_;
		iniProb.Resize(nBeat);
		iniProb.Randomize();
		iniDirParam.assign(nBeat,1);
		trProb.resize(nBeat);
		trDirParam.resize(nBeat);
		for(int r=0;r<nBeat;r+=1){
			trProb[r].Resize(nBeat);
			trProb[r].Randomize();
			trDirParam[r].assign(nBeat,1);
		}//endfor r

		shiftVal.clear();
		for(int val=-nBeat+1;val<=nBeat-1;val+=1){
			shiftVal.push_back(val);
		}//endfor val
		shiftProb.Resize(shiftVal.size());
		shiftProb.Randomize();
		shiftDirParam.assign(shiftVal.size(),1);

		indexSplitter.clear();
		indexUnifier.clear();
		vector<int> vi(2);
		indexUnifier.resize(nBeat);
		for(int b=0;b<nBeat;b+=1){
			indexUnifier[b].resize(shiftVal.size());
			for(int s=0;s<shiftVal.size();s+=1){
				indexUnifier[b][s]=indexSplitter.size();
				vi[0]=b; vi[1]=s;
				indexSplitter.push_back(vi);
			}//endfor s
		}//endfor b
		nEffState=indexSplitter.size();
if(printOn){cout<<"nEffState:\t"<<nEffState<<endl;}
	}//end RandomInit

	void WriteFile(string filename){
		ofstream ofs(filename.c_str());
		ofs<<"//BeatResolution: "<<nBeat<<"\n";

		ofs<<"### Init Prob\n";
		for(int r=0;r<nBeat;r+=1){
ofs<<iniProb.P[r]<<"\t";
		}//endfor r
ofs<<"\n";

		ofs<<"### Transition Prob\n";
		for(int r=0;r<nBeat;r+=1){
			for(int rp=0;rp<nBeat;rp+=1){
ofs<<trProb[r].P[rp]<<"\t";
			}//endfor rp
ofs<<"\n";
		}//endfor r

		ofs<<"### Shift Prob\n";
		for(int i=0;i<shiftVal.size();i+=1){
ofs<<shiftVal[i]<<"\t"<<shiftProb.P[i]<<"\n";
		}//endfor i

		ofs.close();
	}//end WriteFile

	void ReadFile(string filename){
		vector<int> v(100);
		vector<double> d(100);
		vector<string> s(100);
		stringstream ss;

		ifstream ifs(filename.c_str());
		ifs>>s[1]>>nBeat;
		getline(ifs,s[99]);

		RandomInit(nBeat);

		getline(ifs,s[99]);//### Init Prob
		for(int b=0;b<nBeat;b+=1){
			ifs>>iniProb.P[b];
		}//endfor b
		getline(ifs,s[99]);
		iniProb.Normalize();

		getline(ifs,s[99]);//### Transition Prob
		for(int b=0;b<nBeat;b+=1){
			for(int b_=0;b_<nBeat;b_+=1){
				ifs>>trProb[b].P[b_];
			}//endfor b_
			getline(ifs,s[99]);
			trProb[b].Normalize();
		}//endfor b

		getline(ifs,s[99]);//### Shift Prob
		for(int i=0;i<shiftVal.size();i+=1){
			ifs>>d[1]>>shiftProb.P[i];
			getline(ifs,s[99]);
		}//endfor i
		shiftProb.Normalize();

		ifs.close();
	}//end ReadFile

	void ReadFileFromBasic(string filename){
		MetricalMarkovModel basicModel;
		basicModel.ReadFile(filename);
		nBeat=basicModel.nBeat;
		RandomInit(nBeat);
		uniProb=basicModel.uniProb;
		iniProb=basicModel.iniProb;
		trProb=basicModel.trProb;
	}//end ReadFileFromBasic

	void SetSimpleModificationModel(double noShiftP=0.9){
		for(int s=0;s<shiftVal.size();s+=1){
			if(s==nBeat-1){
				shiftProb.P[s]=noShiftP;
			}else{
				shiftProb.P[s]=(1-noShiftP)/double(shiftVal.size()-1);
			}//endif
		}//endfor s
		shiftProb.Normalize();
	}//end SetSimpleModificationModel

	void SetDirParam(double alpha_ini,double alpha_tr,double alpha_shift){
		for(int b=0;b<nBeat;b+=1){
			iniDirParam[b]=alpha_ini*iniProb.P[b];
			for(int bp=0;bp<nBeat;bp+=1){
				trDirParam[b][bp]=alpha_tr*trProb[b].P[bp];
			}//endfor bp
		}//endfor b
		for(int i=0;i<shiftVal.size();i+=1){
			shiftDirParam[i]=alpha_shift*shiftProb.P[i];
		}//endfor i
	}//end SetDirParam

	double OutLP(int ip,int i,double dur){
		int nv=indexSplitter[i][0]-indexSplitter[ip][0]+((indexSplitter[i][0]>indexSplitter[ip][0])? 0:nBeat)+shiftVal[indexSplitter[i][1]]-shiftVal[indexSplitter[ip][1]];
		if(nv>0){
			return -0.5*pow((dur-nv*secPerTick)/sig_t,2.);
		}else{
			return -DBL_MAX;
		}//endif
	}//end OutLP

	double TrLP(int ip,int i){
		return trProb[indexSplitter[ip][0]].LP[indexSplitter[i][0]]+shiftProb.LP[indexSplitter[i][1]];
	}//end TrLP

	int MetPos(int i){
		return (indexSplitter[i][0]+shiftVal[indexSplitter[i][1]]+nBeat)%nBeat;
	}//end MetPos

	double GetLP(){
		double LP=0;

		for(int l=0;l<data.size();l+=1){
			vector<int> metposSeq;
			for(int m=0;m<data[l].size();m+=1){
				for(int n=0;n<data[l][m].size();n+=1){
					metposSeq.push_back(data[l][m][n]);
				}//endfor n
			}//endfor m
			int len=metposSeq.size();
			vector<vector<double> > forwardVar;
			forwardVar.resize(len);
			for(int n=0;n<len;n+=1){
				forwardVar[n].assign(nEffState,-DBL_MAX);
				if(n==0){
					for(int i=0;i<nEffState;i+=1){
						if(MetPos(i)!=metposSeq[n]){continue;}
						forwardVar[n][i]=iniProb.LP[indexSplitter[i][0]]+shiftProb.LP[indexSplitter[i][1]];
					}//endfor i
					continue;
				}//endif

				for(int i=0;i<nEffState;i+=1){
					if(MetPos(i)!=metposSeq[n]){continue;}
					for(int ip=0;ip<nEffState;ip+=1){
						forwardVar[n][i]=LogAdd(forwardVar[n][i],forwardVar[n-1][ip]+TrLP(ip,i));
					}//endfor ip
				}//endfor i
			}//endfor n

			double partLP=-DBL_MAX;
			for(int i=0;i<nEffState;i+=1){
				partLP=LogAdd(partLP,forwardVar[len-1][i]);
			}//endfor i
			LP+=partLP;
		}//endfor l

		return LP;
	}//end GetLP

	void MAP(int nIter=10){
		/// MAP estimation for the parameters
		/// Should be used after setting dirichlet parameters
		boost::mt19937 gen;
		Prob<int> genIniProb(iniProb);
		vector<Prob<int> > genTrProb(trProb);//(nBeat x nBeat)
		Prob<int> genShiftProb(shiftProb);//shift probability (2*nBeat-1) [0]<->-(nBeat-1),[nBeat-1]<->0,[2*nBeat-2]<->nBeat-1

		for(int l=0;l<data.size();l+=1){

if(printOn){cout<<"MAP -- "<<(l+1)<<"/"<<data.size()<<endl;}

			vector<int> metposSeq;
			for(int m=0;m<data[l].size();m+=1){
				for(int n=0;n<data[l][m].size();n+=1){
					metposSeq.push_back(data[l][m][n]);
				}//endfor n
			}//endfor m
			int len=metposSeq.size();

			iniProb=genIniProb;
			trProb=genTrProb;
			shiftProb=genShiftProb;
			Prob<int> maxIniProb(iniProb);
			vector<Prob<int> > maxTrProb(trProb);//(nBeat x nBeat)
			Prob<int> maxShiftProb(shiftProb);//shift probability (2*nBeat-1) [0]<->-(nBeat-1),[nBeat-1]<->0,[2*nBeat-2]<->nBeat-1
			double evidLP;
			double maxEvidLP;
			int maxIter;

			///Gibbs sampling
			for(int iter=0;iter<nIter;iter+=1){

				///Sample scores by forward-filtering backward sampling
				vector<int> sampledStates(len);
				vector<vector<double> > forwardVar;// ontimes[l].size() x nEffState
				forwardVar.resize(len);
				for(int n=0;n<len;n+=1){
					forwardVar[n].assign(nEffState,-DBL_MAX);
					if(n==0){
						for(int i=0;i<nEffState;i+=1){
							if(MetPos(i)!=metposSeq[n]){continue;}
							forwardVar[n][i]=iniProb.LP[indexSplitter[i][0]]+shiftProb.LP[indexSplitter[i][1]];
						}//endfor i
						continue;
					}//endif
	
					for(int i=0;i<nEffState;i+=1){
						if(MetPos(i)!=metposSeq[n]){continue;}
						for(int ip=0;ip<nEffState;ip+=1){
							forwardVar[n][i]=LogAdd(forwardVar[n][i],forwardVar[n-1][ip]+TrLP(ip,i));
						}//endfor ip
					}//endfor i
				}//endfor n

				evidLP=-DBL_MAX;
				for(int i=0;i<nEffState;i+=1){
					evidLP=LogAdd(evidLP,forwardVar[len-1][i]);
				}//endfor i

				if(iter==0 || evidLP>maxEvidLP){
					maxEvidLP=evidLP;
					maxIniProb=iniProb;
					maxTrProb=trProb;
					maxShiftProb=shiftProb;
					maxIter=iter;
				}//endif
if(printOn){cout<<"Iteration: "<<iter<<"\t-NORM(evidLP,maxEvidLP): "<<-evidLP/double(len)<<"\t"<<-maxEvidLP/double(len)<<"\t"<<((evidLP==maxEvidLP)? "******":"")<<endl;}

				/// //Backward sampling
				Prob<int> prob;
				prob.LP=forwardVar[len-1];
				prob.LogNormalize();
				sampledStates[len-1]=SampleDistr(prob.P);

				for(int n=len-2;n>=0;n-=1){
					for(int i=0;i<nEffState;i+=1){
						prob.LP[i]=forwardVar[n][i]+TrLP(i,sampledStates[n+1]);
					}//endfor i
					prob.LogNormalize();
					sampledStates[n]=SampleDistr(prob.P);
				}//endfor n

				///Sample parameters
				iniProb.P=iniDirParam;
				iniProb.P[indexSplitter[sampledStates[0]][0]]+=1;
				for(int b=0;b<nBeat;b+=1){
					boost::gamma_distribution<> dst( iniProb.P[b], 1. );
					boost::variate_generator<boost::mt19937&, boost::gamma_distribution<> > gamma_rand( gen, dst );
					iniProb.P[b]=gamma_rand();
				}//endfor b
				iniProb.Normalize();

				for(int b=0;b<nBeat;b+=1){
					trProb[b].P=trDirParam[b];
				}//endfor b
				for(int n=1;n<len;n+=1){
					trProb[indexSplitter[sampledStates[n-1]][0]].P[indexSplitter[sampledStates[n]][0]]+=1;
				}//endfor n
				for(int b=0;b<nBeat;b+=1){
					for(int bp=0;bp<nBeat;bp+=1){
						boost::gamma_distribution<> dst( trProb[b].P[bp], 1. );
						boost::variate_generator<boost::mt19937&, boost::gamma_distribution<> > gamma_rand( gen, dst );
						trProb[b].P[bp]=gamma_rand();
					}//endfor bp
					trProb[b].Normalize();
				}//endfor b

				shiftProb.P=shiftDirParam;
				for(int n=0;n<len;n+=1){
					shiftProb.P[indexSplitter[sampledStates[n]][1]]+=1;
				}//endfor n
				for(int s=0;s<shiftVal.size();s+=1){
					boost::gamma_distribution<> dst( shiftProb.P[s], 1. );
					boost::variate_generator<boost::mt19937&, boost::gamma_distribution<> > gamma_rand( gen, dst );
					shiftProb.P[s]=gamma_rand();
				}//endfor s
				shiftProb.Normalize();

			}//endfor iter

			///Set optimal parameter
			iniProb=maxIniProb;
			trProb=maxTrProb;
			shiftProb=maxShiftProb;

		}//endfor l

	}//end MAP


	void Transcribe(){
		for(int l=0;l<ontimes.size();l+=1){
// cout<<"Transcribe -- "<<(l+1)<<"/"<<ontimes.size()<<endl;

			///Viterbi
			vector<int> optPath(ontimes[l].size());
			vector<double> LP(nEffState);
			vector<vector<int> > amax;
			amax.resize(ontimes[l].size());
			for(int n=0;n<ontimes[l].size();n+=1){amax[n].resize(nEffState);}

			/// ///Initialization
			LP.assign(nEffState,-DBL_MAX);
			for(int i=0;i<nEffState;i+=1){
				LP[i]=iniProb.LP[indexSplitter[i][0]]+shiftProb.LP[indexSplitter[i][1]];
			}//endfor i

			/// ///Update
			double dur;
			double logP;
			for(int n=1;n<ontimes[l].size();n+=1){
				vector<double> preLP(LP);
				dur=ontimes[l][n]-ontimes[l][n-1];
				LP.assign(nEffState,-DBL_MAX);

				for(int i=0;i<nEffState;i+=1){
					LP[i]=preLP[0]+TrLP(0,i)+OutLP(0,i,dur);
					amax[n][i]=0;
					for(int ip=0;ip<nEffState;ip+=1){
						logP=preLP[ip]+TrLP(ip,i)+OutLP(ip,i,dur);
						if(logP>LP[i]){LP[i]=logP; amax[n][i]=ip;}
					}//endfor ip
				}//endfor i
			}//endfor n

			/// ///Backtracking and set stimes
			optPath[optPath.size()-1]=0;
			for(int i=0;i<nEffState;i+=1){
				if(LP[i]>LP[optPath[optPath.size()-1]]){optPath[optPath.size()-1]=i;}//endif
			}//endfor i
			for(int n=optPath.size()-2;n>=0;n-=1){optPath[n]=amax[n+1][optPath[n+1]];}//endfor n

			for(int n=1;n<ontimes[l].size();n+=1){
				stimes[l][n]=stimes[l][n-1]+indexSplitter[optPath[n]][0]-indexSplitter[optPath[n-1]][0]+((indexSplitter[optPath[n]][0]>indexSplitter[optPath[n-1]][0])? 0:nBeat)+shiftVal[indexSplitter[optPath[n]][1]]-shiftVal[indexSplitter[optPath[n-1]][1]];
			}//endfor n
		}//endfor l
	}//end Transcribe


	void BayesTranscribe(int nIter=10, int seed=2){
		/// Should be used after setting Dirichlet parameters
		boost::mt19937 gen;
		gen.seed(seed);
		Prob<int> genIniProb(iniProb);
		vector<Prob<int> > genTrProb(trProb);//(nBeat x nBeat)
		Prob<int> genShiftProb(shiftProb);//shift probability (2*nBeat-1) [0]<->-(nBeat-1),[nBeat-1]<->0,[2*nBeat-2]<->nBeat-1

		for(int l=0;l<ontimes.size();l+=1){
if(printOn){cout<<"BayesTranscribe -- "<<(l+1)<<"/"<<ontimes.size()<<endl;}

			iniProb=genIniProb;
			trProb=genTrProb;
			shiftProb=genShiftProb;
			Prob<int> maxIniProb(iniProb);
			vector<Prob<int> > maxTrProb(trProb);//(nBeat x nBeat)
			Prob<int> maxShiftProb(shiftProb);//shift probability (2*nBeat-1) [0]<->-(nBeat-1),[nBeat-1]<->0,[2*nBeat-2]<->nBeat-1
			double evidLP;
			double maxEvidLP;
			int maxIter;
			double dur;

			///Gibbs sampling
			for(int iter=0;iter<nIter;iter+=1){

				///Sample scores by forward-filtering backward sampling
				vector<int> sampledStates(ontimes[l].size());
				vector<vector<double> > forwardVar;// ontimes[l].size() x nEffState
				forwardVar.resize(ontimes[l].size());
				for(int n=0;n<ontimes[l].size();n+=1){forwardVar[n].assign(nEffState,-DBL_MAX);}

				/// //Forward
				for(int i=0;i<nEffState;i+=1){
					forwardVar[0][i]=iniProb.LP[indexSplitter[i][0]]+shiftProb.LP[indexSplitter[i][1]];
				}//endfor i

				for(int n=1;n<ontimes[l].size();n+=1){
					dur=ontimes[l][n]-ontimes[l][n-1];
					for(int i=0;i<nEffState;i+=1){
						for(int ip=0;ip<nEffState;ip+=1){
							forwardVar[n][i]=LogAdd(forwardVar[n][i],forwardVar[n-1][ip]+TrLP(ip,i)+OutLP(ip,i,dur));
						}//endfor ip
					}//endfor i
				}//endfor n

				evidLP=-DBL_MAX;
				for(int i=0;i<nEffState;i+=1){
					evidLP=LogAdd(evidLP,forwardVar[ontimes[l].size()-1][i]);
				}//endfor i

				if(iter==0 || evidLP>maxEvidLP){
					maxEvidLP=evidLP;
					maxIniProb=iniProb;
					maxTrProb=trProb;
					maxShiftProb=shiftProb;
					maxIter=iter;
				}//endif
if(printOn){cout<<"Iteration: "<<iter<<"\t-NORM(evidLP,maxEvidLP): "<<-evidLP/double(ontimes[l].size())<<"\t"<<-maxEvidLP/double(ontimes[l].size())<<"\t"<<((evidLP==maxEvidLP)? "******":"")<<endl;}

				/// //Backward sampling
				Prob<int> prob;
				prob.LP=forwardVar[ontimes[l].size()-1];
				prob.LogNormalize();
				sampledStates[ontimes[l].size()-1]=SampleDistr(prob.P);

				for(int n=ontimes[l].size()-2;n>=0;n-=1){
					for(int i=0;i<nEffState;i+=1){
						prob.LP[i]=forwardVar[n][i]+TrLP(i,sampledStates[n+1])+OutLP(i,sampledStates[n+1],ontimes[l][n+1]-ontimes[l][n]);
					}//endfor i
					prob.LogNormalize();
					sampledStates[n]=SampleDistr(prob.P);
				}//endfor n


				///Sample parameters
				iniProb.P=iniDirParam;
				iniProb.P[indexSplitter[sampledStates[0]][0]]+=1;
				for(int r=0;r<nBeat;r+=1){
					boost::gamma_distribution<> dst( iniProb.P[r], 1. );
					boost::variate_generator<boost::mt19937&, boost::gamma_distribution<> > gamma_rand( gen, dst );
					iniProb.P[r]=gamma_rand();
				}//endfor r
				iniProb.Normalize();

				for(int r=0;r<nBeat;r+=1){
					trProb[r].P=trDirParam[r];
				}//endfor r
				for(int n=1;n<ontimes[l].size();n+=1){
					trProb[indexSplitter[sampledStates[n-1]][0]].P[indexSplitter[sampledStates[n]][0]]+=1;
				}//endfor n
				for(int r=0;r<nBeat;r+=1){
					for(int rp=0;rp<nBeat;rp+=1){
						boost::gamma_distribution<> dst( trProb[r].P[rp], 1. );
						boost::variate_generator<boost::mt19937&, boost::gamma_distribution<> > gamma_rand( gen, dst );
						trProb[r].P[rp]=gamma_rand();
					}//endfor rp
					trProb[r].Normalize();
				}//endfor r

				shiftProb.P=shiftDirParam;
				for(int n=0;n<ontimes[l].size();n+=1){
					shiftProb.P[indexSplitter[sampledStates[n]][1]]+=1;
				}//endfor n
				for(int s=0;s<shiftVal.size();s+=1){
					boost::gamma_distribution<> dst( shiftProb.P[s], 1. );
					boost::variate_generator<boost::mt19937&, boost::gamma_distribution<> > gamma_rand( gen, dst );
					shiftProb.P[s]=gamma_rand();
				}//endfor s
				shiftProb.Normalize();

			}//endfor iter


			///Set optimal parameter
			iniProb=maxIniProb;
			trProb=maxTrProb;
			shiftProb=maxShiftProb;

			///Viterbi
			vector<int> optPath(ontimes[l].size());
			vector<double> LP(nEffState);
			vector<vector<int> > amax;
			amax.resize(ontimes[l].size());
			for(int n=0;n<ontimes[l].size();n+=1){amax[n].resize(nEffState);}

			/// ///Initialization
			LP.assign(nEffState,-DBL_MAX);
			for(int i=0;i<nEffState;i+=1){
				LP[i]=iniProb.LP[indexSplitter[i][0]]+shiftProb.LP[indexSplitter[i][1]];
			}//endfor i

			/// ///Update
			double logP;
			for(int n=1;n<ontimes[l].size();n+=1){
				vector<double> preLP(LP);
				dur=ontimes[l][n]-ontimes[l][n-1];
				LP.assign(nEffState,-DBL_MAX);

				for(int i=0;i<nEffState;i+=1){
					LP[i]=preLP[0]+TrLP(0,i)+OutLP(0,i,dur);
					amax[n][i]=0;
					for(int ip=0;ip<nEffState;ip+=1){
						logP=preLP[ip]+TrLP(ip,i)+OutLP(ip,i,dur);
						if(logP>LP[i]){LP[i]=logP; amax[n][i]=ip;}
					}//endfor ip
				}//endfor i
			}//endfor n

			/// ///Backtracking and set stimes
			optPath[optPath.size()-1]=0;
			for(int i=0;i<nEffState;i+=1){
				if(LP[i]>LP[optPath[optPath.size()-1]]){optPath[optPath.size()-1]=i;}//endif
			}//endfor i
			for(int n=optPath.size()-2;n>=0;n-=1){optPath[n]=amax[n+1][optPath[n+1]];}//endfor n

			for(int n=1;n<ontimes[l].size();n+=1){
				stimes[l][n]=stimes[l][n-1]+indexSplitter[optPath[n]][0]-indexSplitter[optPath[n-1]][0]+((indexSplitter[optPath[n]][0]>indexSplitter[optPath[n-1]][0])? 0:nBeat)+shiftVal[indexSplitter[optPath[n]][1]]-shiftVal[indexSplitter[optPath[n-1]][1]];
			}//endfor n

			///Write piece-specific parameter file
			stringstream ss;
			ss.str(""); ss<<paramFolder<<"param_metMM1S_"<<l<<".txt";
			WriteFile(ss.str());

		}//endfor l
	}//end BayesTranscribe

};//endclass MetMM1S


class MetMM1D : public MetMM1DS{
public:
	vector<vector<int> > indexSplitter;//[][0,1,2]=b,H,g
	vector<vector<vector<int> > > indexUnifier;//[b][H][g]
	int nEffState;//indexSplitter.size()

	MetMM1D(){
		printOn=false;
	}//end MetMM1D
	~MetMM1D(){
	}//end ~MetMM1D

	void Clear(){
		iniProb.Clear();
		iniDirParam.clear();
		trProb.clear();
		trDirParam.clear();
		insPattern.clear();
		insProb.clear();
		insDirParam.clear();
	}//end Clear

	void RandomInit(int nBeat_){
		Clear();
		nBeat=nBeat_;
		iniProb.Resize(nBeat);
		iniProb.Randomize();
		iniDirParam.assign(nBeat,1);
		trProb.resize(nBeat);
		trDirParam.resize(nBeat);
		for(int r=0;r<nBeat;r+=1){
			trProb[r].Resize(nBeat);
			trProb[r].Randomize();
			trDirParam[r].assign(nBeat,1);
		}//endfor r

		insPattern.resize(nBeat);
		insProb.resize(nBeat);
		insDirParam.resize(nBeat);
		vector<int> vi;
		for(int i=0;i<nBeat;i+=1){
			vi.clear();
			vi.push_back(i+1);
			insPattern[i].push_back(vi);
			for(int j=1;j<=i;j+=1){
				vi.clear();
				vi.push_back(j);
				vi.push_back(i+1-j);
				insPattern[i].push_back(vi);
			}//endfor j
			insProb[i].Resize(insPattern[i].size());
			insProb[i].Randomize();
			insDirParam[i].assign(insPattern[i].size(),1);
		}//endfor i

		insPatIndexSplitter.clear();
		insPatIndexUnifier.clear();
		vi.clear(); vi.resize(2);
		insPatIndexUnifier.resize(nBeat);
		for(int r=0;r<nBeat;r+=1){
			insPatIndexUnifier[r].resize(insPattern[r].size());
			for(int h=0;h<insPattern[r].size();h+=1){
				insPatIndexUnifier[r][h]=insPatIndexSplitter.size();
				vi[0]=r; vi[1]=h;
				insPatIndexSplitter.push_back(vi);
			}//endfor h
		}//endfor r
		nInsPat=insPatIndexSplitter.size();
//cout<<nInsPat<<endl;

		indexSplitter.clear();
		indexUnifier.clear();
		vi.clear(); vi.resize(3);
		indexUnifier.resize(nBeat);
		for(int b=0;b<nBeat;b+=1){
			indexUnifier[b].resize(nInsPat);
			for(int H=0;H<nInsPat;H+=1){
				indexUnifier[b][H].resize(insPattern[insPatIndexSplitter[H][0]][insPatIndexSplitter[H][1]].size());
				for(int g=0;g<insPattern[insPatIndexSplitter[H][0]][insPatIndexSplitter[H][1]].size();g+=1){
					indexUnifier[b][H][g]=indexSplitter.size();
					vi[0]=b; vi[1]=H; vi[2]=g;
					indexSplitter.push_back(vi);
				}//endfor g
			}//endfor H
		}//endfor b
		nEffState=indexSplitter.size();
if(printOn){cout<<"nEffState:\t"<<nEffState<<endl;}
	}//end RandomInit

	void WriteFile(string filename){
		ofstream ofs(filename.c_str());
		ofs<<"//BeatResolution: "<<nBeat<<"\n";

		ofs<<"### Init Prob\n";
		for(int r=0;r<nBeat;r+=1){
ofs<<iniProb.P[r]<<"\t";
		}//endfor r
ofs<<"\n";

		ofs<<"### Transition Prob\n";
		for(int r=0;r<nBeat;r+=1){
			for(int rp=0;rp<nBeat;rp+=1){
ofs<<trProb[r].P[rp]<<"\t";
			}//endfor rp
ofs<<"\n";
		}//endfor r

		ofs<<"### Insertion Prob\n";
		for(int i=0;i<insPattern.size();i+=1){
			for(int h=0;h<insPattern[i].size();h+=1){
ofs<<i+1<<"\t"<<h<<"\t"<<insProb[i].P[h]<<"\t"<<insPattern[i][h].size()<<"\t";
				for(int g=0;g<insPattern[i][h].size();g+=1){
ofs<<insPattern[i][h][g]<<" ";
				}//endfor g
ofs<<"\n";
			}//endfor h
		}//endfor i

		ofs.close();
	}//end WriteFile

	void ReadFile(string filename){
		vector<int> v(100);
		vector<double> d(100);
		vector<string> s(100);
		stringstream ss;

		ifstream ifs(filename.c_str());
		ifs>>s[1]>>nBeat;
		getline(ifs,s[99]);

		RandomInit(nBeat);

		getline(ifs,s[99]);//### Init Prob
		for(int b=0;b<nBeat;b+=1){
			ifs>>iniProb.P[b];
		}//endfor b
		getline(ifs,s[99]);
		iniProb.Normalize();

		getline(ifs,s[99]);//### Transition Prob
		for(int b=0;b<nBeat;b+=1){
			for(int b_=0;b_<nBeat;b_+=1){
				ifs>>trProb[b].P[b_];
			}//endfor b_
			getline(ifs,s[99]);
			trProb[b].Normalize();
		}//endfor b

		getline(ifs,s[99]);//### Insertion Prob
		for(int i=0;i<insPattern.size();i+=1){
			for(int h=0;h<insPattern[i].size();h+=1){
				ifs>>d[1]>>d[2]>>insProb[i].P[h];
				getline(ifs,s[99]);
			}//endfor h
			insProb[i].Normalize();
		}//endfor i

		ifs.close();
	}//end ReadFile

	void ReadFileFromBasic(string filename){
		MetricalMarkovModel basicModel;
		basicModel.ReadFile(filename);
		nBeat=basicModel.nBeat;
		RandomInit(nBeat);
		uniProb=basicModel.uniProb;
		iniProb=basicModel.iniProb;
		trProb=basicModel.trProb;
	}//end ReadFileFromBasic

	void SetSimpleModificationModel(double noInsP=0.9){
		for(int i=0;i<nBeat;i+=1){
			insProb[i].P[0]=noInsP;
			for(int h=1;h<insPattern[i].size();h+=1){
				insProb[i].P[h]=(1-noInsP)/double(insPattern[i].size()-1);
			}//endfor h
			insProb[i].Normalize();
		}//endfor i
	}//end SetSimpleModificationModel

	void SetDirParam(double alpha_ini,double alpha_tr,double alpha_ins){
		for(int b=0;b<nBeat;b+=1){
			iniDirParam[b]=alpha_ini*iniProb.P[b];
			for(int bp=0;bp<nBeat;bp+=1){
				trDirParam[b][bp]=alpha_tr*trProb[b].P[bp];
			}//endfor bp
		}//endfor b
		for(int i=0;i<nBeat;i+=1){
			for(int h=0;h<insPattern[i].size();h+=1){
				insDirParam[i][h]=alpha_ins*insProb[i].P[h];
			}//endfor h
		}//endfor i
	}//end SetDirParam

	double OutLP(int i,double dur){
		return -0.5*pow((dur-insPattern[insPatIndexSplitter[indexSplitter[i][1]][0]][insPatIndexSplitter[indexSplitter[i][1]][1]][indexSplitter[i][2]]*secPerTick)/sig_t,2.);
	}//end OutLP

	double TrLP(int ip,int i){
		int nvID=indexSplitter[i][0]-indexSplitter[ip][0]+((indexSplitter[i][0]>indexSplitter[ip][0])? 0:nBeat)-1;
		if(indexSplitter[i][2]==0){
			if(indexSplitter[ip][2]==insPattern[insPatIndexSplitter[indexSplitter[ip][1]][0]][insPatIndexSplitter[indexSplitter[ip][1]][1]].size()-1){
				if(insPatIndexSplitter[indexSplitter[i][1]][0]==nvID){
					return trProb[indexSplitter[ip][0]].LP[indexSplitter[i][0]]+insProb[insPatIndexSplitter[indexSplitter[i][1]][0]].LP[insPatIndexSplitter[indexSplitter[i][1]][1]];
				}else{
					return -DBL_MAX;
				}//endif
			}else{
				return -DBL_MAX;
			}//endif
		}else{//indexSplitter[i][2]>0
			if(indexSplitter[i][2]==indexSplitter[ip][2]+1
			   && indexSplitter[i][0]==indexSplitter[ip][0]
			   && indexSplitter[i][1]==indexSplitter[ip][1]){
				return 0;
			}else{
				return -DBL_MAX;
			}//endif
		}//endif
	}//end TrLP

	double FirstTrLP(int ip,int i){
		int nvID=indexSplitter[i][0]-indexSplitter[ip][0]+((indexSplitter[i][0]>indexSplitter[ip][0])? 0:nBeat)-1;
		if(insPatIndexSplitter[indexSplitter[i][1]][0]==nvID){
			return trProb[indexSplitter[ip][0]].LP[indexSplitter[i][0]]+insProb[insPatIndexSplitter[indexSplitter[i][1]][0]].LP[insPatIndexSplitter[indexSplitter[i][1]][1]];
		}else{
			return -DBL_MAX;
		}//endif
	}//end FirstTrLP

	int MetPos(int i){
		int delta=0;
		for(int g=insPattern[insPatIndexSplitter[indexSplitter[i][1]][0]][insPatIndexSplitter[indexSplitter[i][1]][1]][indexSplitter[i][2]]+1;g<insPattern[insPatIndexSplitter[indexSplitter[i][1]][0]][insPatIndexSplitter[indexSplitter[i][1]][1]].size();g+=1){
			delta+=insPattern[insPatIndexSplitter[indexSplitter[i][1]][0]][insPatIndexSplitter[indexSplitter[i][1]][1]][g];
		}//endfor h
		return (indexSplitter[i][0]-delta+10*nBeat)%nBeat;
	}//end MetPos

	double GetLP(){
		double LP=0;

		for(int l=0;l<data.size();l+=1){
			vector<int> metposSeq;
			for(int m=0;m<data[l].size();m+=1){
				for(int n=0;n<data[l][m].size();n+=1){
					metposSeq.push_back(data[l][m][n]);
				}//endfor n
			}//endfor m
			int len=metposSeq.size();
			vector<vector<double> > forwardVar;
			forwardVar.resize(len);
			for(int n=0;n<len;n+=1){
				forwardVar[n].assign(nEffState,-DBL_MAX);
				if(n==0){
					for(int b=0;b<nBeat;b+=1){
						if(b!=metposSeq[n]){continue;}
						forwardVar[n][indexUnifier[b][0][0]]=iniProb.LP[b];
					}//endfor b
					continue;
				}else if(n==1){
					for(int i=0;i<nEffState;i+=1){
						if(MetPos(i)!=metposSeq[n]){continue;}
						for(int ip=0;ip<nEffState;ip+=1){
							forwardVar[n][i]=LogAdd(forwardVar[n][i],forwardVar[n-1][ip]+FirstTrLP(ip,i));
						}//endfor ip
					}//endfor i
					continue;
				}//endif

				for(int i=0;i<nEffState;i+=1){
					if(MetPos(i)!=metposSeq[n]){continue;}
					for(int ip=0;ip<nEffState;ip+=1){
						forwardVar[n][i]=LogAdd(forwardVar[n][i],forwardVar[n-1][ip]+TrLP(ip,i));
					}//endfor ip
				}//endfor i
			}//endfor n

			double partLP=-DBL_MAX;
			for(int i=0;i<nEffState;i+=1){
				partLP=LogAdd(partLP,forwardVar[len-1][i]);
			}//endfor i
			LP+=partLP;
		}//endfor l

		return LP;
	}//end GetLP


	void MAP(int nIter=10){
		/// MAP estimation for the parameters
		/// Should be used after setting dirichlet parameters
		boost::mt19937 gen;
		Prob<int> genIniProb(iniProb);
		vector<Prob<int> > genTrProb(trProb);//(nBeat x nBeat)
		vector<Prob<int> > genInsProb(insProb);//insertion probability r -> h

		for(int l=0;l<data.size();l+=1){

if(printOn){cout<<"MAP -- "<<(l+1)<<"/"<<data.size()<<endl;}

			vector<int> metposSeq;
			for(int m=0;m<data[l].size();m+=1){
				for(int n=0;n<data[l][m].size();n+=1){
					metposSeq.push_back(data[l][m][n]);
				}//endfor n
			}//endfor m
			int len=metposSeq.size();

			iniProb=genIniProb;
			trProb=genTrProb;
			insProb=genInsProb;
			Prob<int> maxIniProb(iniProb);
			vector<Prob<int> > maxTrProb(trProb);//(nBeat x nBeat)
			vector<Prob<int> > maxInsProb(insProb);//insertion probability r -> h
			double evidLP;
			double maxEvidLP;
			int maxIter;

			///Gibbs sampling
			for(int iter=0;iter<nIter;iter+=1){

				///Sample scores by forward-filtering backward sampling
				vector<int> sampledStates(len);
				vector<vector<double> > forwardVar;// ontimes[l].size() x nEffState
				forwardVar.resize(len);
				for(int n=0;n<len;n+=1){
					forwardVar[n].assign(nEffState,-DBL_MAX);
					if(n==0){
						for(int b=0;b<nBeat;b+=1){
							if(b!=metposSeq[n]){continue;}
							forwardVar[n][indexUnifier[b][0][0]]=iniProb.LP[b];
						}//endfor b
						continue;
					}else if(n==1){
						for(int i=0;i<nEffState;i+=1){
							if(MetPos(i)!=metposSeq[n]){continue;}
							for(int ip=0;ip<nEffState;ip+=1){
								forwardVar[n][i]=LogAdd(forwardVar[n][i],forwardVar[n-1][ip]+FirstTrLP(ip,i));
							}//endfor ip
						}//endfor i
						continue;
					}//endif
	
					for(int i=0;i<nEffState;i+=1){
						if(MetPos(i)!=metposSeq[n]){continue;}
						for(int ip=0;ip<nEffState;ip+=1){
							forwardVar[n][i]=LogAdd(forwardVar[n][i],forwardVar[n-1][ip]+TrLP(ip,i));
						}//endfor ip
					}//endfor i
				}//endfor n

				evidLP=-DBL_MAX;
				for(int i=0;i<nEffState;i+=1){
					evidLP=LogAdd(evidLP,forwardVar[len-1][i]);
				}//endfor i

				if(iter==0 || evidLP>maxEvidLP){
					maxEvidLP=evidLP;
					maxIniProb=iniProb;
					maxTrProb=trProb;
					maxInsProb=insProb;
					maxIter=iter;
				}//endif
if(printOn){cout<<"Iteration: "<<iter<<"\t-NORM(evidLP,maxEvidLP): "<<-evidLP/double(len)<<"\t"<<-maxEvidLP/double(len)<<"\t"<<((evidLP==maxEvidLP)? "******":"")<<endl;}

				/// //Backward sampling
				Prob<int> prob;
				prob.LP=forwardVar[len-1];
				prob.LogNormalize();
				sampledStates[len-1]=SampleDistr(prob.P);

				for(int n=len-2;n>=1;n-=1){
					for(int i=0;i<nEffState;i+=1){
						prob.LP[i]=forwardVar[n][i]+TrLP(i,sampledStates[n+1]);
					}//endfor i
					prob.LogNormalize();
					sampledStates[n]=SampleDistr(prob.P);
				}//endfor n

				prob.LP.assign(nEffState,-DBL_MAX);

				for(int b=0;b<nBeat;b+=1){
					for(int s=0;s<shiftVal.size();s+=1){
						if(b!=metposSeq[0]){continue;}
						prob.LP[indexUnifier[b][0][0]]=forwardVar[0][indexUnifier[b][0][0]]+FirstTrLP(indexUnifier[b][0][0],sampledStates[1]);
					}//endfor s
				}//endfor b
				prob.LogNormalize();
				sampledStates[0]=SampleDistr(prob.P);

				///Sample parameters
				iniProb.P=iniDirParam;
				iniProb.P[indexSplitter[sampledStates[0]][0]]+=1;
				for(int b=0;b<nBeat;b+=1){
					boost::gamma_distribution<> dst( iniProb.P[b], 1. );
					boost::variate_generator<boost::mt19937&, boost::gamma_distribution<> > gamma_rand( gen, dst );
					iniProb.P[b]=gamma_rand();
				}//endfor b
				iniProb.Normalize();

				for(int b=0;b<nBeat;b+=1){
					trProb[b].P=trDirParam[b];
				}//endfor b
				for(int n=1;n<len;n+=1){
					if(indexSplitter[sampledStates[n]][2]!=0){continue;}
					trProb[indexSplitter[sampledStates[n-1]][0]].P[indexSplitter[sampledStates[n]][0]]+=1;
				}//endfor n
				for(int b=0;b<nBeat;b+=1){
					for(int bp=0;bp<nBeat;bp+=1){
						boost::gamma_distribution<> dst( trProb[b].P[bp], 1. );
						boost::variate_generator<boost::mt19937&, boost::gamma_distribution<> > gamma_rand( gen, dst );
						trProb[b].P[bp]=gamma_rand();
					}//endfor bp
					trProb[b].Normalize();
				}//endfor b

				for(int r=0;r<nBeat;r+=1){
					insProb[r].P=insDirParam[r];
				}//endfor r
				for(int n=1;n<len;n+=1){
					if(indexSplitter[sampledStates[n]][2]!=0){continue;}
					insProb[insPatIndexSplitter[indexSplitter[sampledStates[n]][1]][0]].P[insPatIndexSplitter[indexSplitter[sampledStates[n]][1]][1]]+=1;
				}//endfor n
				for(int r=0;r<nBeat;r+=1){
					for(int h=0;h<insDirParam[r].size();h+=1){
						boost::gamma_distribution<> dst( insProb[r].P[h], 1. );
						boost::variate_generator<boost::mt19937&, boost::gamma_distribution<> > gamma_rand( gen, dst );
						insProb[r].P[h]=gamma_rand();
					}//endfor h
					insProb[r].Normalize();
				}//endfor r

			}//endfor iter

			///Set optimal parameter
			iniProb=maxIniProb;
			trProb=maxTrProb;
			insProb=maxInsProb;

		}//endfor l

	}//end MAP


	void Transcribe(){

		for(int l=0;l<ontimes.size();l+=1){
// cout<<"Transcribe -- "<<(l+1)<<"/"<<ontimes.size()<<endl;

			///Viterbi
			vector<int> optPath(ontimes[l].size());
			vector<double> LP(nEffState);
			vector<vector<int> > amax;
			amax.resize(ontimes[l].size());
			for(int n=0;n<ontimes[l].size();n+=1){amax[n].resize(nEffState);}

			/// ///Initialization
			//(n=0) H=g=0, b is the only variable
			LP.assign(nEffState,-DBL_MAX);
			for(int b=0;b<nBeat;b+=1){
				LP[indexUnifier[b][0][0]]=iniProb.LP[b];
			}//endfor b

			/// ///Update
			double dur;
			double logP;
			for(int n=1;n<ontimes[l].size();n+=1){
				vector<double> preLP(LP);
				dur=ontimes[l][n]-ontimes[l][n-1];
				LP.assign(nEffState,-DBL_MAX);

				if(n==1){
					for(int i=0;i<nEffState;i+=1){
						if(indexSplitter[i][2]!=0){continue;}
						LP[i]=preLP[indexUnifier[0][0][0]]+FirstTrLP(indexUnifier[0][0][0],i)+OutLP(i,dur);
						amax[n][i]=indexUnifier[0][0][0];
						for(int b=0;b<nBeat;b+=1){
							logP=preLP[indexUnifier[b][0][0]]+FirstTrLP(indexUnifier[b][0][0],i)+OutLP(i,dur);
							if(logP>LP[i]){LP[i]=logP; amax[n][i]=indexUnifier[b][0][0];}
						}//endfor b
					}//endfor i
					continue;
				}//endif

				double trlp,outlp;
				for(int i=0;i<nEffState;i+=1){
					LP[i]=preLP[0]+TrLP(0,i)+OutLP(i,dur);
					amax[n][i]=0;
					for(int ip=0;ip<nEffState;ip+=1){
						trlp=TrLP(ip,i);
						if(trlp<-1E10){continue;}
						outlp=OutLP(i,dur);
						if(outlp<-1E10){continue;}
						logP=preLP[ip]+trlp+outlp;
						if(logP>LP[i]){LP[i]=logP; amax[n][i]=ip;}
					}//endfor ip
				}//endfor i

			}//endfor n

			/// ///Backtracking and set stimes
			optPath[optPath.size()-1]=0;
			for(int i=0;i<nEffState;i+=1){
				if(LP[i]>LP[optPath[optPath.size()-1]]){optPath[optPath.size()-1]=i;}//endif
			}//endfor i
			for(int n=optPath.size()-2;n>=0;n-=1){optPath[n]=amax[n+1][optPath[n+1]];}//endfor n

			for(int n=1;n<ontimes[l].size();n+=1){
				stimes[l][n]=stimes[l][n-1]+insPattern[insPatIndexSplitter[indexSplitter[optPath[n]][1]][0]][insPatIndexSplitter[indexSplitter[optPath[n]][1]][1]][indexSplitter[optPath[n]][2]];
			}//endfor n
		}//endfor l

	}//end Transcribe


	void BayesTranscribe(int nIter=10, int seed=2){
		/// Should be used after setting Dirichlet parameters
		boost::mt19937 gen;
		gen.seed(seed);
		Prob<int> genIniProb(iniProb);
		vector<Prob<int> > genTrProb(trProb);//(nBeat x nBeat)
		vector<Prob<int> > genInsProb(insProb);//insertion probability r -> h

		for(int l=0;l<ontimes.size();l+=1){
if(printOn){cout<<"BayesTranscribe -- "<<(l+1)<<"/"<<ontimes.size()<<endl;}

			iniProb=genIniProb;
			trProb=genTrProb;
			insProb=genInsProb;
			Prob<int> maxIniProb(iniProb);
			vector<Prob<int> > maxTrProb(trProb);//(nBeat x nBeat)
			vector<Prob<int> > maxInsProb(insProb);//insertion probability r -> h
			double evidLP;
			double maxEvidLP;
			int maxIter;
			double dur;

			///Gibbs sampling
			for(int iter=0;iter<nIter;iter+=1){

				///Sample scores by forward-filtering backward sampling
				vector<int> sampledStates(ontimes[l].size());
				vector<vector<double> > forwardVar;// ontimes[l].size() x nEffState
				forwardVar.resize(ontimes[l].size());
				for(int n=0;n<ontimes[l].size();n+=1){forwardVar[n].assign(nEffState,-DBL_MAX);}

				/// //Forward
				//(n=0) H=g=0, b is the only variable
				for(int b=0;b<nBeat;b+=1){
					forwardVar[0][indexUnifier[b][0][0]]=iniProb.LP[b];
				}//endfor b

				for(int n=1;n<ontimes[l].size();n+=1){
					dur=ontimes[l][n]-ontimes[l][n-1];

					if(n==1){
						for(int i=0;i<nEffState;i+=1){
							if(indexSplitter[i][2]!=0){continue;}
							for(int b=0;b<nBeat;b+=1){
								forwardVar[n][i]=LogAdd(forwardVar[n][i],
									forwardVar[n-1][indexUnifier[b][0][0]]+FirstTrLP(indexUnifier[b][0][0],i)+OutLP(i,dur)
								);
							}//endfor b
						}//endfor i
						continue;
					}//endif

					double trlp,outlp;
					for(int i=0;i<nEffState;i+=1){
						for(int ip=0;ip<nEffState;ip+=1){
							trlp=TrLP(ip,i);
							if(trlp<-1E10){continue;}
							outlp=OutLP(i,dur);
							if(outlp<-1E10){continue;}
							forwardVar[n][i]=LogAdd(forwardVar[n][i],forwardVar[n-1][ip]+trlp+outlp);
						}//endfor ip
					}//endfor i

				}//endfor n

				evidLP=-DBL_MAX;
				for(int i=0;i<nEffState;i+=1){
					evidLP=LogAdd(evidLP,forwardVar[ontimes[l].size()-1][i]);
				}//endfor i

				if(iter==0 || evidLP>maxEvidLP){
					maxEvidLP=evidLP;
					maxIniProb=iniProb;
					maxTrProb=trProb;
					maxInsProb=insProb;
					maxIter=iter;
				}//endif
if(printOn){cout<<"Iteration: "<<iter<<"\t-NORM(evidLP,maxEvidLP): "<<-evidLP/double(ontimes[l].size())<<"\t"<<-maxEvidLP/double(ontimes[l].size())<<"\t"<<((evidLP==maxEvidLP)? "******":"")<<endl;}

				/// //Backward sampling
				Prob<int> prob;
				prob.LP=forwardVar[ontimes[l].size()-1];
				prob.LogNormalize();
				sampledStates[ontimes[l].size()-1]=SampleDistr(prob.P);

				for(int n=ontimes[l].size()-2;n>=1;n-=1){
					for(int i=0;i<nEffState;i+=1){
						prob.LP[i]=forwardVar[n][i]+TrLP(i,sampledStates[n+1]);
					}//endfor i
					prob.LogNormalize();
					sampledStates[n]=SampleDistr(prob.P);
				}//endfor n

				prob.LP.assign(nEffState,-DBL_MAX);
				for(int b=0;b<nBeat;b+=1){
					prob.LP[indexUnifier[b][0][0]]=forwardVar[0][indexUnifier[b][0][0]]+FirstTrLP(indexUnifier[b][0][0],sampledStates[1]);
				}//endfor b
				prob.LogNormalize();
				sampledStates[0]=SampleDistr(prob.P);

				///Sample parameters
				iniProb.P=iniDirParam;
				iniProb.P[indexSplitter[sampledStates[0]][0]]+=1;
				for(int b=0;b<nBeat;b+=1){
					boost::gamma_distribution<> dst( iniProb.P[b], 1. );
					boost::variate_generator<boost::mt19937&, boost::gamma_distribution<> > gamma_rand( gen, dst );
					iniProb.P[b]=gamma_rand();
				}//endfor b
				iniProb.Normalize();

				for(int b=0;b<nBeat;b+=1){
					trProb[b].P=trDirParam[b];
				}//endfor b
				for(int n=1;n<ontimes[l].size();n+=1){
					if(indexSplitter[sampledStates[n]][2]!=0){continue;}
					trProb[indexSplitter[sampledStates[n-1]][0]].P[indexSplitter[sampledStates[n]][0]]+=1;
				}//endfor n
				for(int b=0;b<nBeat;b+=1){
					for(int bp=0;bp<nBeat;bp+=1){
						boost::gamma_distribution<> dst( trProb[b].P[bp], 1. );
						boost::variate_generator<boost::mt19937&, boost::gamma_distribution<> > gamma_rand( gen, dst );
						trProb[b].P[bp]=gamma_rand();
					}//endfor bp
					trProb[b].Normalize();
				}//endfor b

				for(int r=0;r<nBeat;r+=1){
					insProb[r].P=insDirParam[r];
				}//endfor r
				for(int n=1;n<ontimes[l].size();n+=1){
					if(indexSplitter[sampledStates[n]][2]!=0){continue;}
					insProb[insPatIndexSplitter[indexSplitter[sampledStates[n]][1]][0]].P[insPatIndexSplitter[indexSplitter[sampledStates[n]][1]][1]]+=1;
				}//endfor n
				for(int r=0;r<nBeat;r+=1){
					for(int h=0;h<insDirParam[r].size();h+=1){
						boost::gamma_distribution<> dst( insProb[r].P[h], 1. );
						boost::variate_generator<boost::mt19937&, boost::gamma_distribution<> > gamma_rand( gen, dst );
						insProb[r].P[h]=gamma_rand();
					}//endfor h
					insProb[r].Normalize();
				}//endfor r

			}//endfor iter


			///Set optimal parameter
			iniProb=maxIniProb;
			trProb=maxTrProb;
			insProb=maxInsProb;

			///Viterbi
			vector<int> optPath(ontimes[l].size());
			vector<double> LP(nEffState);
			vector<vector<int> > amax;
			amax.resize(ontimes[l].size());
			for(int n=0;n<ontimes[l].size();n+=1){amax[n].resize(nEffState);}

			/// ///Initialization
			//(n=0) H=g=0, b is the only variable
			LP.assign(nEffState,-DBL_MAX);
			for(int b=0;b<nBeat;b+=1){
				LP[indexUnifier[b][0][0]]=iniProb.LP[b];
			}//endfor b

			/// ///Update
			double logP;
			for(int n=1;n<ontimes[l].size();n+=1){
				vector<double> preLP(LP);
				dur=ontimes[l][n]-ontimes[l][n-1];
				LP.assign(nEffState,-DBL_MAX);

				if(n==1){
					for(int i=0;i<nEffState;i+=1){
						if(indexSplitter[i][2]!=0){continue;}
						LP[i]=preLP[indexUnifier[0][0][0]]+FirstTrLP(indexUnifier[0][0][0],i)+OutLP(i,dur);
						amax[n][i]=indexUnifier[0][0][0];
						for(int b=0;b<nBeat;b+=1){
							logP=preLP[indexUnifier[b][0][0]]+FirstTrLP(indexUnifier[b][0][0],i)+OutLP(i,dur);
							if(logP>LP[i]){LP[i]=logP; amax[n][i]=indexUnifier[b][0][0];}
						}//endfor b
					}//endfor i
					continue;
				}//endif

				double trlp,outlp;
				for(int i=0;i<nEffState;i+=1){
					LP[i]=preLP[0]+TrLP(0,i)+OutLP(i,dur);
					amax[n][i]=0;
					for(int ip=0;ip<nEffState;ip+=1){
						trlp=TrLP(ip,i);
						if(trlp<-1E10){continue;}
						outlp=OutLP(i,dur);
						if(outlp<-1E10){continue;}
						logP=preLP[ip]+trlp+outlp;
						if(logP>LP[i]){LP[i]=logP; amax[n][i]=ip;}
					}//endfor ip
				}//endfor i
			}//endfor n

			/// ///Backtracking and set stimes
			optPath[optPath.size()-1]=0;
			for(int i=0;i<nEffState;i+=1){
				if(LP[i]>LP[optPath[optPath.size()-1]]){optPath[optPath.size()-1]=i;}//endif
			}//endfor i
			for(int n=optPath.size()-2;n>=0;n-=1){optPath[n]=amax[n+1][optPath[n+1]];}//endfor n

			for(int n=1;n<ontimes[l].size();n+=1){
				stimes[l][n]=stimes[l][n-1]+insPattern[insPatIndexSplitter[indexSplitter[optPath[n]][1]][0]][insPatIndexSplitter[indexSplitter[optPath[n]][1]][1]][indexSplitter[optPath[n]][2]];
			}//endfor n

			///Write piece-specific parameter file
			stringstream ss;
			ss.str(""); ss<<paramFolder<<"param_metMM1D_"<<l<<".txt";
			WriteFile(ss.str());

		}//endfor l
	}//end BayesTranscribe

};//endclass MetMM1D

#endif // MetricalMarkovModelMod_HPP
