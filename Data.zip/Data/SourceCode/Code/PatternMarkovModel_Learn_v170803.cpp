#include<fstream>
#include<iostream>
#include<cmath>
#include<string>
#include<sstream>
#include<vector>
#include<algorithm>
#include"stdio.h"
#include"stdlib.h"
#include"PatternMarkovModel_v170803.hpp"
using namespace std;

int main(int argc, char** argv){
	vector<int> v(100);
	vector<double> d(100);
	vector<string> s(100);
	stringstream ss;
	clock_t start, end;
	start = clock();

	if(argc!=6){
		cout<<"Error in usage: $./this order pattern.txt data.txt out_param.txt smoothCoeff(0.1)"<<endl;
		return -1;
	}//endif

	int order=atoi(argv[1]);
	string patternfile=string(argv[2]);
	string datafile=string(argv[3]);
	string paramfile=string(argv[4]);
	double smoothCoeff=atof(argv[5]);

	assert(order>=0 && order<=1);

	if(order==1){

		PatternMarkovModel patMM;
		patMM.ReadPatterns(patternfile);
		patMM.ReadData(datafile);
		patMM.LearnAdditiveSmoothing(smoothCoeff);
		patMM.WriteFile(paramfile);

	}else if(order==0){

		PatternMarkovModel_0th patMM0;
		patMM0.ReadPatterns(patternfile);
		patMM0.ReadData(datafile);
		patMM0.LearnAdditiveSmoothing(smoothCoeff);
		patMM0.WriteFile(paramfile);

//cout<<patMM0.uniPatProb.Entropy()/log(2)<<endl;

	}//endif


	return 0;
}//end main
