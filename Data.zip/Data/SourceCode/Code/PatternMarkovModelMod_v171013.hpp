#ifndef PatternMarkovModelMod_HPP
#define PatternMarkovModelMod_HPP

#include<iostream>
#include<iomanip>
#include<fstream>
#include<string>
#include<sstream>
#include<vector>
#include<stdio.h>
#include<stdlib.h>
#include<cfloat>
#include<cmath>
#include<cassert>
#include<algorithm>
#include<boost/math/distributions.hpp> 
#include<boost/random.hpp>
#include"PatternMarkovModel_v170803.hpp"

#define EPS (0.1)
#define PRINTON_ true

using namespace std;

class PatMM1DS : public PatternMarkovModel{
public:
	bool printOn;

// 	int nBeat;//Beat resolution
// 	vector<vector<int> > patterns;//Each pattern is represented with onset beat positions
// 	int nPat;//number of patterns
// 	Prob<int> uniPatProb;//nPat
// 	Prob<int> iniPatProb;//nPat
// 	vector<Prob<int> > trPatProb;//(nPat x nPat)

	vector<vector<vector<int> > > insPattern;//[nvID][h][g]
	vector<Prob<int> > insProb;//insertion probability r -> h
	Prob<int> shiftProb;//shift probability (2*nBeat-1) [0]<->-(nBeat-1),[nBeat-1]<->0,[2*nBeat-2]<->nBeat-1
	vector<int> shiftVal;//(2*nBeat-1)

	vector<vector<double> > insDirParam;
	vector<double> shiftDirParam;

	vector<vector<int> > insPatIndexSplitter;//[H][0,1]=nvID,h
	vector<vector<int> > insPatIndexUnifier;//[nvID][h]=H
	int nInsPat;

	vector<vector<int> > indexSplitter;//[][0,1,2,3,4]=k,i,H,g,s
	vector<vector<vector<vector<vector<int> > > > > indexUnifier;//[k][i][H][g][s]
	int nEffState;//indexSplitter.size()

	int pruningCutOff;
	PatMM1DS(){
		printOn=true;
		pruningCutOff=1000;
	}//end PatMM1DS
	~PatMM1DS(){
	}//end ~PatMM1DS

	void Clear(){
		iniPatProb.Clear();
		iniPatDirParam.clear();
		trPatProb.clear();
		trPatDirParam.clear();
		insPattern.clear();
		insProb.clear();
		insDirParam.clear();
		shiftVal.clear();
		shiftProb.Clear();
		shiftDirParam.clear();
	}//end Clear

	void RandomInit(int nBeat_){
		// Use after ReadPatterns
		Clear();
		nBeat=nBeat_;

		iniPatProb.Resize(nPat);
		iniPatProb.Randomize();
		iniPatDirParam.assign(nPat,1);
		trPatProb.resize(nPat);
		trPatDirParam.resize(nPat);
		for(int k=0;k<nPat;k+=1){
			trPatProb[k].Resize(nPat);
			trPatProb[k].Randomize();
			trPatDirParam[k].assign(nPat,1);
		}//endfor k

		insPattern.resize(nBeat);
		insProb.resize(nBeat);
		insDirParam.resize(nBeat);
		vector<int> vi;
		for(int i=0;i<nBeat;i+=1){
			vi.clear();
			vi.push_back(i+1);
			insPattern[i].push_back(vi);
			for(int j=1;j<=i;j+=1){
				vi.clear();
				vi.push_back(j);
				vi.push_back(i+1-j);
				insPattern[i].push_back(vi);
			}//endfor j
			insProb[i].Resize(insPattern[i].size());
			insProb[i].Randomize();
			insDirParam[i].assign(insPattern[i].size(),1);
		}//endfor i

		shiftVal.clear();
		for(int val=-nBeat+1;val<=nBeat-1;val+=1){
			shiftVal.push_back(val);
		}//endfor val
		shiftProb.Resize(shiftVal.size());
		shiftProb.Randomize();
		shiftDirParam.assign(shiftVal.size(),1);

		insPatIndexSplitter.clear();
		insPatIndexUnifier.clear();
		vi.clear(); vi.resize(2);
		insPatIndexUnifier.resize(nBeat);
		for(int r=0;r<nBeat;r+=1){
			insPatIndexUnifier[r].resize(insPattern[r].size());
			for(int h=0;h<insPattern[r].size();h+=1){
				insPatIndexUnifier[r][h]=insPatIndexSplitter.size();
				vi[0]=r; vi[1]=h;
				insPatIndexSplitter.push_back(vi);
			}//endfor h
		}//endfor r
		nInsPat=insPatIndexSplitter.size();
if(printOn){cout<<"nPat:\t"<<nPat<<endl;}
if(printOn){cout<<"nInsPat:\t"<<nInsPat<<endl;}

		indexSplitter.clear();
		indexUnifier.clear();
		bool goodIndex;
		vi.clear(); vi.resize(5);
		indexUnifier.resize(patterns.size());
		for(int k=0;k<patterns.size();k+=1){
			indexUnifier[k].resize(patterns[k].size());
			for(int i=0;i<patterns[k].size();i+=1){
				indexUnifier[k][i].resize(nInsPat);
				for(int H=0;H<nInsPat;H+=1){
					indexUnifier[k][i][H].resize(insPattern[insPatIndexSplitter[H][0]][insPatIndexSplitter[H][1]].size());
					for(int g=0;g<insPattern[insPatIndexSplitter[H][0]][insPatIndexSplitter[H][1]].size();g+=1){
						indexUnifier[k][i][H][g].resize(shiftVal.size());
						for(int s=0;s<shiftVal.size();s+=1){
							goodIndex=true;
							if(i>0){
								// H<->patterns[k][i] (if i>=2)
								if(insPatIndexSplitter[H][0]+1!=patterns[k][i]-patterns[k][i-1]){goodIndex=false;}
							}//endif
							//Impose -q_{h_ng_n} < s_n <=q_{h_ng_n}
							if(shiftVal[s]>insPattern[insPatIndexSplitter[H][0]][insPatIndexSplitter[H][1]][g]){goodIndex=false;}
							if(shiftVal[s]<=-insPattern[insPatIndexSplitter[H][0]][insPatIndexSplitter[H][1]][g]){goodIndex=false;}
							if(g<insPattern[insPatIndexSplitter[H][0]][insPatIndexSplitter[H][1]].size()-1){
								//Impose s_n<q_{h_ng_{n+1}}
								if(shiftVal[s]>=insPattern[insPatIndexSplitter[H][0]][insPatIndexSplitter[H][1]][g+1]){goodIndex=false;}
								if(shiftVal[s]!=0){goodIndex=false;}
							}else{//g=insPattern[insPatIndexSplitter[H][0]][insPatIndexSplitter[H][1]].size()-1
								if(i<patterns[k].size()-1){
									//Impose B_{k_{n}i_{n}}+s_n < B_{k_{n}i_{n+1}}
									if(patterns[k][i]+shiftVal[s]>=patterns[k][i+1]){goodIndex=false;}
								}else{//i==patterns[k].size()-1
									//Impose B_{k_{n}i_{n}}+s_n <= nBeat}
									if(patterns[k][i]+shiftVal[s]>nBeat){goodIndex=false;}
								}//endif
							}//endif
							if(goodIndex){
								indexUnifier[k][i][H][g][s]=indexSplitter.size();
								vi[0]=k; vi[1]=i; vi[2]=H; vi[3]=g; vi[4]=s;
								indexSplitter.push_back(vi);
							}else{
								indexUnifier[k][i][H][g][s]=-1;
							}//endif
						}//endfor s
					}//endfor g
				}//endfor H
			}//endfor i
		}//endfor k
		nEffState=indexSplitter.size();
if(printOn){cout<<"nEffState:\t"<<nEffState<<endl;}
	}//end RandomInit

	void WriteFile(string filename){
		ofstream ofs(filename.c_str());
		ofs<<"//BeatResolution: "<<nBeat<<"\n";
		ofs<<"//NumOfPatterns: "<<nPat<<"\n";

		ofs<<"### Patterns\n";
		for(int i=0;i<nPat;i+=1){
ofs<<i<<"\t"<<patterns[i].size()<<" : ";
			for(int j=0;j<patterns[i].size();j+=1){
ofs<<patterns[i][j]<<" ";
			}//endfor j
ofs<<"\n";
		}//endfor i

		ofs<<"### Init Pattern Prob\n";
		for(int i=0;i<nPat;i+=1){
ofs<<iniPatProb.P[i]<<"\t";
		}//endfor i
ofs<<"\n";

		ofs<<"### Transition Pattern Prob\n";
		for(int i=0;i<nPat;i+=1){
			for(int ip=0;ip<nPat;ip+=1){
ofs<<trPatProb[i].P[ip]<<"\t";
			}//endfor ip
ofs<<"\n";
		}//endfor i

		ofs<<"### Shift Prob\n";
		for(int i=0;i<shiftVal.size();i+=1){
ofs<<shiftVal[i]<<"\t"<<shiftProb.P[i]<<"\n";
		}//endfor i

		ofs<<"### Insertion Prob\n";
		for(int i=0;i<insPattern.size();i+=1){
			for(int h=0;h<insPattern[i].size();h+=1){
ofs<<i+1<<"\t"<<h<<"\t"<<insProb[i].P[h]<<"\t"<<insPattern[i][h].size()<<"\t";
				for(int g=0;g<insPattern[i][h].size();g+=1){
ofs<<insPattern[i][h][g]<<" ";
				}//endfor g
ofs<<"\n";
			}//endfor h
		}//endfor i

		ofs.close();
	}//end WriteFile

	void ReadFile(string filename){
		vector<int> v(100);
		vector<double> d(100);
		vector<string> s(100);
		stringstream ss;

		ifstream ifs(filename.c_str());
		ifs>>s[1]>>nBeat;
		getline(ifs,s[99]);
		ifs>>s[1]>>nPat;
		getline(ifs,s[99]);

		patterns.clear();
		patterns.resize(nPat);

		getline(ifs,s[99]);//### Patterns
		for(int i=0;i<nPat;i+=1){
			ifs>>v[1]>>v[2]>>s[3];
			for(int j=0;j<v[2];j+=1){
				ifs>>v[0];
				patterns[i].push_back(v[0]);
			}//endfor j
			getline(ifs,s[99]);
		}//endfor i

		RandomInit(nBeat);

		getline(ifs,s[99]);//### Init Pattern Prob
		for(int i=0;i<nPat;i+=1){
			ifs>>iniPatProb.P[i];
		}//endfor i
		getline(ifs,s[99]);
		iniPatProb.Normalize();

		getline(ifs,s[99]);//### Transition Pattern Prob
		for(int i=0;i<nPat;i+=1){
			for(int ip=0;ip<nPat;ip+=1){
				ifs>>trPatProb[i].P[ip];
			}//endfor ip
			getline(ifs,s[99]);
			trPatProb[i].Normalize();
		}//endfor i

		getline(ifs,s[99]);//### Shift Prob
		for(int i=0;i<shiftVal.size();i+=1){
			ifs>>d[1]>>shiftProb.P[i];
			getline(ifs,s[99]);
		}//endfor i
		shiftProb.Normalize();

		getline(ifs,s[99]);//### Insertion Prob
		for(int i=0;i<insPattern.size();i+=1){
			for(int h=0;h<insPattern[i].size();h+=1){
				ifs>>d[1]>>d[2]>>insProb[i].P[h];
				getline(ifs,s[99]);
			}//endfor h
			insProb[i].Normalize();
		}//endfor i

		ifs.close();
	}//end ReadFile

	void ReadFileFromBasic(string filename,double interpCoeff=0){
		PatternMarkovModel basicModel;
		basicModel.ReadFile(filename);
		basicModel.LinearInterpolate(interpCoeff);
		nBeat=basicModel.nBeat;
		nPat=basicModel.nPat;
		patterns=basicModel.patterns;
		RandomInit(nBeat);
		uniPatProb=basicModel.uniPatProb;
		iniPatProb=basicModel.iniPatProb;
		trPatProb=basicModel.trPatProb;
	}//end ReadFileFromBasic

	void SetSimpleModificationModel(double noShiftP=0.9,double noInsP=0.9){
		for(int s=0;s<shiftVal.size();s+=1){
			if(s==nBeat-1){
				shiftProb.P[s]=noShiftP;
			}else{
				shiftProb.P[s]=(1-noShiftP)/double(shiftVal.size()-1);
			}//endif
		}//endfor s
		shiftProb.Normalize();
		for(int i=0;i<nBeat;i+=1){
			insProb[i].P[0]=noInsP;
			for(int h=1;h<insPattern[i].size();h+=1){
				insProb[i].P[h]=(1-noInsP)/double(insPattern[i].size()-1);
			}//endfor h
			insProb[i].Normalize();
		}//endfor i
	}//end SetSimpleModificationModel

	void SetDirParam(double alpha_ini,double alpha_tr,double alpha_shift,double alpha_ins){
		for(int k=0;k<nPat;k+=1){
			iniPatDirParam[k]=alpha_ini*iniPatProb.P[k];
			for(int kp=0;kp<nPat;kp+=1){
				trPatDirParam[k][kp]=alpha_tr*trPatProb[k].P[kp];
			}//endfor kp
		}//endfor k
		for(int i=0;i<shiftVal.size();i+=1){
			shiftDirParam[i]=alpha_shift*shiftProb.P[i];
		}//endfor i
		for(int i=0;i<nBeat;i+=1){
			for(int h=0;h<insPattern[i].size();h+=1){
				insDirParam[i][h]=alpha_ins*insProb[i].P[h];
			}//endfor h
		}//endfor i
	}//end SetDirParam

	double OutLP(int zp,int z,double dur){
		int nv=insPattern[insPatIndexSplitter[indexSplitter[z][2]][0]][insPatIndexSplitter[indexSplitter[z][2]][1]][indexSplitter[z][3]]+shiftVal[indexSplitter[z][4]]-shiftVal[indexSplitter[zp][4]];
		if(nv>0){
			return -0.5*pow((dur-nv*secPerTick)/sig_t,2.);
		}else{
			return -DBL_MAX;
		}//endif
	}//end OutLP

	double TrLP(int zp,int z){
		int nvID=patterns[indexSplitter[z][0]][indexSplitter[z][1]]-patterns[indexSplitter[zp][0]][indexSplitter[zp][1]]+((patterns[indexSplitter[z][0]][indexSplitter[z][1]]>patterns[indexSplitter[zp][0]][indexSplitter[zp][1]])? 0:nBeat)-1;
		if(indexSplitter[z][3]==0){
			if(indexSplitter[zp][3]==insPattern[insPatIndexSplitter[indexSplitter[zp][2]][0]][insPatIndexSplitter[indexSplitter[zp][2]][1]].size()-1){
				double lp;
				if(indexSplitter[z][1]==0){
					if(indexSplitter[zp][1]==patterns[indexSplitter[zp][0]].size()-1){
						lp=trPatProb[indexSplitter[zp][0]].LP[indexSplitter[z][0]];
					}else{
						return -DBL_MAX;
					}//endif
				}else{//indexSplitter[z][1]>0
					if(indexSplitter[z][1]==indexSplitter[zp][1]+1
					   && indexSplitter[z][0]==indexSplitter[zp][0]){
						lp=0;
					}else{
						return -DBL_MAX;
					}//endif
				}//endif

				if(insPatIndexSplitter[indexSplitter[z][2]][0]==nvID){
					return lp+insProb[insPatIndexSplitter[indexSplitter[z][2]][0]].LP[insPatIndexSplitter[indexSplitter[z][2]][1]]+shiftProb.LP[indexSplitter[z][4]];
				}else{
					return -DBL_MAX;
				}//endif

			}else{
				return -DBL_MAX;
			}//endif
		}else{//indexSplitter[z][3]>0
			if(indexSplitter[z][3]==indexSplitter[zp][3]+1
			   && indexSplitter[z][0]==indexSplitter[zp][0]
			   && indexSplitter[z][1]==indexSplitter[zp][1]
			   && indexSplitter[z][2]==indexSplitter[zp][2]){
				return shiftProb.LP[indexSplitter[z][4]];
			}else{
				return -DBL_MAX;
			}//endif
		}//endif
	}//end TrLP

	double FirstTrLP(int zp,int z){
		if(indexSplitter[z][3]!=0){return -DBL_MAX;}
		int nvID=patterns[indexSplitter[z][0]][indexSplitter[z][1]]-patterns[indexSplitter[zp][0]][indexSplitter[zp][1]]+((patterns[indexSplitter[z][0]][indexSplitter[z][1]]>patterns[indexSplitter[zp][0]][indexSplitter[zp][1]])? 0:nBeat)-1;

		double lp;
		if(indexSplitter[z][1]==0){
			if(indexSplitter[zp][1]==patterns[indexSplitter[zp][0]].size()-1){
				lp=trPatProb[indexSplitter[zp][0]].LP[indexSplitter[z][0]];
			}else{
				return -DBL_MAX;
			}//endif
		}else{//indexSplitter[z][1]>0
			if(indexSplitter[z][1]==indexSplitter[zp][1]+1
			   && indexSplitter[z][0]==indexSplitter[zp][0]){
				lp=0;
			}else{
				return -DBL_MAX;
			}//endif
		}//endif

		if(insPatIndexSplitter[indexSplitter[z][2]][0]==nvID){
			return lp+insProb[insPatIndexSplitter[indexSplitter[z][2]][0]].LP[insPatIndexSplitter[indexSplitter[z][2]][1]]+shiftProb.LP[indexSplitter[z][4]];
		}else{
			return -DBL_MAX;
		}//endif
	}//end FirstTrLP

	void Transcribe(){
		for(int l=0;l<ontimes.size();l+=1){
cout<<"Transcribe -- "<<(l+1)<<"/"<<ontimes.size()<<endl;
			///Viterbi
			vector<int> optPath(ontimes[l].size());
			vector<double> LP(nEffState);
			vector<vector<int> > amax;
			amax.resize(ontimes[l].size());
			for(int n=0;n<ontimes[l].size();n+=1){amax[n].resize(nEffState);}
			vector<int> stateSalient;

			/// ///Initialization
			//(n=0) H=28, g=0, k,i=0,s are the only variables
			LP.assign(nEffState,-DBL_MAX);
			for(int k=0;k<patterns.size();k+=1){
				for(int s=0;s<shiftVal.size();s+=1){
					if(indexUnifier[k][0][28][0][s]<0){continue;}
					LP[indexUnifier[k][0][28][0][s]]=iniPatProb.LP[k]+shiftProb.LP[s];
				}//endfor s
			}//endfor k

			/// ///Update
			double dur;
			double logP;
			double trlp,outlp;
			for(int n=1;n<ontimes[l].size();n+=1){
				vector<double> preLP(LP);
				dur=ontimes[l][n]-ontimes[l][n-1];
				LP.assign(nEffState,-DBL_MAX);

				stateSalient.assign(nEffState,0);
				vector<Pair> pairs;
				Pair pair;
				for(int z=0;z<nEffState;z+=1){
					pair.ID=z; pair.value=preLP[z];
					pairs.push_back(pair);
				}//endfor z
				sort(pairs.begin(), pairs.end(), MorePair());
				for(int z=0;z<pruningCutOff;z+=1){
						stateSalient[pairs[z].ID]=1;
//cout<<pairs[z].ID<<"\t"<<pairs[z].value<<endl;
				}//endfor z

				if(n==1){
					for(int z=0;z<nEffState;z+=1){
						if(indexSplitter[z][3]!=0){continue;}
						LP[z]=preLP[indexUnifier[0][0][28][0][0]]+FirstTrLP(indexUnifier[0][0][28][0][0],z)+OutLP(indexUnifier[0][0][28][0][0],z,dur);
						amax[n][z]=indexUnifier[0][0][28][0][0];
						for(int k=0;k<patterns.size();k+=1){
							for(int s=0;s<shiftVal.size();s+=1){
								if(stateSalient[indexUnifier[k][0][28][0][s]]==0){continue;}
								trlp=FirstTrLP(indexUnifier[k][0][28][0][s],z);
								if(trlp<-1E10){continue;}
								outlp=OutLP(indexUnifier[k][0][28][0][s],z,dur);
								if(outlp<-1E10){continue;}
								if(indexUnifier[k][0][28][0][s]<0){continue;}
								logP=preLP[indexUnifier[k][0][28][0][s]]+trlp+outlp;
								if(logP>LP[z]){LP[z]=logP; amax[n][z]=indexUnifier[k][0][28][0][s];}
							}//endfor s
						}//endfor k
					}//endfor z
				}else{//n>1
					for(int z=0;z<nEffState;z+=1){
						LP[z]=preLP[0]+TrLP(0,z)+OutLP(0,z,dur);
						amax[n][z]=0;
						for(int zp=0;zp<nEffState;zp+=1){
							if(stateSalient[zp]==0){continue;}
							trlp=TrLP(zp,z);
							if(trlp<-1E10){continue;}
							outlp=OutLP(zp,z,dur);
							if(outlp<-1E10){continue;}
							logP=preLP[zp]+trlp+outlp;
							if(logP>LP[z]){LP[z]=logP; amax[n][z]=zp;}
						}//endfor zp
					}//endfor z
				}//endif

			}//endfor n

			/// ///Backtracking and set stimes
			optPath[optPath.size()-1]=0;
			for(int z=0;z<nEffState;z+=1){
				if(LP[z]>LP[optPath[optPath.size()-1]]){optPath[optPath.size()-1]=z;}//endif
			}//endfor i
			for(int n=optPath.size()-2;n>=0;n-=1){optPath[n]=amax[n+1][optPath[n+1]];}//endfor n

			for(int n=1;n<ontimes[l].size();n+=1){
				stimes[l][n]=stimes[l][n-1]+insPattern[insPatIndexSplitter[indexSplitter[optPath[n]][2]][0]][insPatIndexSplitter[indexSplitter[optPath[n]][2]][1]][indexSplitter[optPath[n]][3]]+shiftVal[indexSplitter[optPath[n]][4]]-shiftVal[indexSplitter[optPath[n-1]][4]];
			}//endfor n

		}//endfor l
	}//end Transcribe


	void BayesTranscribe(int nIter=10, int seed=2){
		/// Should be used after setting Dirichlet parameters
		boost::mt19937 gen;
		gen.seed(seed);
		Prob<int> genIniPatProb(iniPatProb);
		vector<Prob<int> > genTrPatProb(trPatProb);
		vector<Prob<int> > genInsProb(insProb);//insertion probability r -> h
		Prob<int> genShiftProb(shiftProb);//shift probability (2*nBeat-1) [0]<->-(nBeat-1),[nBeat-1]<->0,[2*nBeat-2]<->nBeat-1

		for(int l=0;l<ontimes.size();l+=1){
if(printOn){cout<<"BayesTranscribe -- "<<(l+1)<<"/"<<ontimes.size()<<endl;}

			iniPatProb=genIniPatProb;
			trPatProb=genTrPatProb;
			insProb=genInsProb;
			shiftProb=genShiftProb;
			Prob<int> maxIniPatProb(iniPatProb);
			vector<Prob<int> > maxTrPatProb(trPatProb);
			vector<Prob<int> > maxInsProb(insProb);//insertion probability r -> h
			Prob<int> maxShiftProb(shiftProb);//shift probability (2*nBeat-1) [0]<->-(nBeat-1),[nBeat-1]<->0,[2*nBeat-2]<->nBeat-1
			double evidLP;
			double maxEvidLP;
			int maxIter;
			double dur;

			///Gibbs sampling
			for(int iter=0;iter<nIter;iter+=1){

				///Sample scores by forward-filtering backward sampling
				vector<int> sampledStates(ontimes[l].size());
				vector<vector<double> > forwardVar;// ontimes[l].size() x nEffState
				forwardVar.resize(ontimes[l].size());
				for(int n=0;n<ontimes[l].size();n+=1){forwardVar[n].assign(nEffState,-DBL_MAX);}
				vector<int> stateSalient;

				/// //Forward
				//(n=0) H=g=0, k,i=0,s are the only variables
				for(int k=0;k<patterns.size();k+=1){
					for(int s=0;s<shiftVal.size();s+=1){
						if(indexUnifier[k][0][28][0][s]<0){continue;}
						forwardVar[0][indexUnifier[k][0][28][0][s]]=iniPatProb.LP[k]+shiftProb.LP[s];
					}//endfor s
				}//endfor k

				double trlp,outlp;
				for(int n=1;n<ontimes[l].size();n+=1){
					dur=ontimes[l][n]-ontimes[l][n-1];
//cout<<"n:\t"<<n<<endl;

					stateSalient.assign(nEffState,0);
					vector<Pair> pairs;
					Pair pair;
					for(int z=0;z<nEffState;z+=1){
						pair.ID=z; pair.value=forwardVar[n-1][z];
						pairs.push_back(pair);
					}//endfor z
					sort(pairs.begin(), pairs.end(), MorePair());
					for(int z=0;z<pruningCutOff;z+=1){
						stateSalient[pairs[z].ID]=1;
//cout<<pairs[z].ID<<"\t"<<pairs[z].value<<endl;
					}//endfor z

					if(n==1){
						for(int z=0;z<nEffState;z+=1){
							if(indexSplitter[z][3]!=0){continue;}
							for(int k=0;k<patterns.size();k+=1){
								for(int s=0;s<shiftVal.size();s+=1){
									if(stateSalient[indexUnifier[k][0][28][0][s]]==0){continue;}
									if(indexUnifier[k][0][28][0][s]<0){continue;}
									trlp=FirstTrLP(indexUnifier[k][0][28][0][s],z);
									if(trlp<-1E10){continue;}
									outlp=OutLP(indexUnifier[k][0][28][0][s],z,dur);
									if(outlp<-1E10){continue;}
									forwardVar[n][z]=LogAdd(forwardVar[n][z],
										forwardVar[n-1][indexUnifier[k][0][28][0][s]]+trlp+outlp
									);
								}//endfor s
							}//endfor k
						}//endfor z

					}else{//n>1

						for(int zp=0;zp<nEffState;zp+=1){
							if(stateSalient[zp]==0){continue;}
							for(int z=0;z<nEffState;z+=1){
								trlp=TrLP(zp,z);
								if(trlp<-1E10){continue;}
								outlp=OutLP(zp,z,dur);
								if(outlp<-1E10){continue;}
								forwardVar[n][z]=LogAdd(forwardVar[n][z],forwardVar[n-1][zp]+trlp+outlp);
							}//endfor z
						}//endfor zp

					}//endif

				}//endfor n

				evidLP=-DBL_MAX;
				for(int z=0;z<nEffState;z+=1){
					evidLP=LogAdd(evidLP,forwardVar[ontimes[l].size()-1][z]);
				}//endfor z

				if(iter==0 || evidLP>maxEvidLP){
					maxEvidLP=evidLP;
					maxIniPatProb=iniPatProb;
					maxTrPatProb=trPatProb;
					maxInsProb=insProb;
					maxShiftProb=shiftProb;
					maxIter=iter;
				}//endif
if(printOn){cout<<"Iteration: "<<iter<<"\t-NORM(evidLP,maxEvidLP): "<<-evidLP/double(ontimes[l].size())<<"\t"<<-maxEvidLP/double(ontimes[l].size())<<"\t"<<((evidLP==maxEvidLP)? "******":"")<<endl;}

				/// //Backward sampling
				Prob<int> prob;
				prob.LP=forwardVar[ontimes[l].size()-1];
				prob.LogNormalize();
				sampledStates[ontimes[l].size()-1]=SampleDistr(prob.P);

				for(int n=ontimes[l].size()-2;n>=1;n-=1){
					for(int i=0;i<nEffState;i+=1){
						prob.LP[i]=forwardVar[n][i]+TrLP(i,sampledStates[n+1])+OutLP(i,sampledStates[n+1],ontimes[l][n+1]-ontimes[l][n]);
					}//endfor i
					prob.LogNormalize();
					sampledStates[n]=SampleDistr(prob.P);
				}//endfor n

				prob.LP.assign(nEffState,-DBL_MAX);
				for(int k=0;k<patterns.size();k+=1){
					for(int s=0;s<shiftVal.size();s+=1){
						if(indexUnifier[k][0][28][0][s]<0){continue;}
						prob.LP[indexUnifier[k][0][28][0][s]]=forwardVar[0][indexUnifier[k][0][28][0][s]]+FirstTrLP(indexUnifier[k][0][28][0][s],sampledStates[1])+OutLP(indexUnifier[k][0][28][0][s],sampledStates[1],ontimes[l][1]-ontimes[l][0]);
					}//endfor s
				}//endfor k
				prob.LogNormalize();
				sampledStates[0]=SampleDistr(prob.P);

				///Sample parameters
				iniPatProb.P=iniPatDirParam;
				iniPatProb.P[indexSplitter[sampledStates[0]][0]]+=1;
				for(int k=0;k<patterns.size();k+=1){
					boost::gamma_distribution<> dst( iniPatProb.P[k], 1. );
					boost::variate_generator<boost::mt19937&, boost::gamma_distribution<> > gamma_rand( gen, dst );
					iniPatProb.P[k]=gamma_rand();
				}//endfor k
				iniPatProb.Normalize();

				for(int k=0;k<patterns.size();k+=1){
					trPatProb[k].P=trPatDirParam[k];
				}//endfor k
				for(int n=1;n<ontimes[l].size();n+=1){
					if(indexSplitter[sampledStates[n]][1]!=0 || indexSplitter[sampledStates[n]][3]!=0){continue;}
					trPatProb[indexSplitter[sampledStates[n-1]][0]].P[indexSplitter[sampledStates[n]][0]]+=1;
				}//endfor n
				for(int k=0;k<patterns.size();k+=1){
					for(int kp=0;kp<patterns.size();kp+=1){
						boost::gamma_distribution<> dst( trPatProb[k].P[kp], 1. );
						boost::variate_generator<boost::mt19937&, boost::gamma_distribution<> > gamma_rand( gen, dst );
						trPatProb[k].P[kp]=gamma_rand();
					}//endfor kp
					trPatProb[k].Normalize();
				}//endfor k

				for(int r=0;r<nBeat;r+=1){
					insProb[r].P=insDirParam[r];
				}//endfor r
				for(int n=1;n<ontimes[l].size();n+=1){
					if(indexSplitter[sampledStates[n]][3]!=0){continue;}
					insProb[insPatIndexSplitter[indexSplitter[sampledStates[n]][2]][0]].P[insPatIndexSplitter[indexSplitter[sampledStates[n]][2]][1]]+=1;
				}//endfor n
				for(int r=0;r<nBeat;r+=1){
					for(int h=0;h<insDirParam[r].size();h+=1){
						boost::gamma_distribution<> dst( insProb[r].P[h], 1. );
						boost::variate_generator<boost::mt19937&, boost::gamma_distribution<> > gamma_rand( gen, dst );
						insProb[r].P[h]=gamma_rand();
					}//endfor h
					insProb[r].Normalize();
				}//endfor r

				shiftProb.P=shiftDirParam;
				for(int n=0;n<ontimes[l].size();n+=1){
					shiftProb.P[indexSplitter[sampledStates[n]][4]]+=1;
				}//endfor n
				for(int s=0;s<shiftVal.size();s+=1){
					boost::gamma_distribution<> dst( shiftProb.P[s], 1. );
					boost::variate_generator<boost::mt19937&, boost::gamma_distribution<> > gamma_rand( gen, dst );
					shiftProb.P[s]=gamma_rand();
				}//endfor s
				shiftProb.Normalize();

			}//endfor iter

			///Set optimal parameter
			iniPatProb=maxIniPatProb;
			trPatProb=maxTrPatProb;
			insProb=maxInsProb;
			shiftProb=maxShiftProb;

			///Viterbi
			vector<int> optPath(ontimes[l].size());
			vector<double> LP(nEffState);
			vector<vector<int> > amax;
			amax.resize(ontimes[l].size());
			for(int n=0;n<ontimes[l].size();n+=1){amax[n].resize(nEffState);}
			vector<int> stateSalient;

			/// ///Initialization
			//(n=0) H=g=0, k,i=0,s are the only variables
			LP.assign(nEffState,-DBL_MAX);
			for(int k=0;k<patterns.size();k+=1){
				for(int s=0;s<shiftVal.size();s+=1){
					if(indexUnifier[k][0][28][0][s]<0){continue;}
					LP[indexUnifier[k][0][28][0][s]]=iniPatProb.LP[k]+shiftProb.LP[s];
				}//endfor s
			}//endfor k

			/// ///Update
			double logP;
			double trlp,outlp;
			for(int n=1;n<ontimes[l].size();n+=1){
				vector<double> preLP(LP);
				dur=ontimes[l][n]-ontimes[l][n-1];
				LP.assign(nEffState,-DBL_MAX);
//cout<<"n:\t"<<n<<endl;

				stateSalient.assign(nEffState,0);
				vector<Pair> pairs;
				Pair pair;
				for(int z=0;z<nEffState;z+=1){
					pair.ID=z; pair.value=preLP[z];
					pairs.push_back(pair);
				}//endfor z
				sort(pairs.begin(), pairs.end(), MorePair());
				for(int z=0;z<pruningCutOff;z+=1){
						stateSalient[pairs[z].ID]=1;
//cout<<pairs[z].ID<<"\t"<<pairs[z].value<<endl;
				}//endfor z

				if(n==1){
					for(int z=0;z<nEffState;z+=1){
						if(indexSplitter[z][3]!=0){continue;}
						LP[z]=preLP[indexUnifier[0][0][28][0][0]]+FirstTrLP(indexUnifier[0][0][28][0][0],z)+OutLP(indexUnifier[0][0][28][0][0],z,dur);
						amax[n][z]=indexUnifier[0][0][28][0][0];
						for(int k=0;k<patterns.size();k+=1){
							for(int s=0;s<shiftVal.size();s+=1){
								if(stateSalient[indexUnifier[k][0][28][0][s]]==0){continue;}
								trlp=FirstTrLP(indexUnifier[k][0][28][0][s],z);
								if(trlp<-1E10){continue;}
								outlp=OutLP(indexUnifier[k][0][28][0][s],z,dur);
								if(outlp<-1E10){continue;}
								if(indexUnifier[k][0][28][0][s]<0){continue;}
								logP=preLP[indexUnifier[k][0][28][0][s]]+trlp+outlp;
								if(logP>LP[z]){LP[z]=logP; amax[n][z]=indexUnifier[k][0][28][0][s];}
							}//endfor s
						}//endfor k
					}//endfor z
				}else{//n>1
					for(int z=0;z<nEffState;z+=1){
						LP[z]=preLP[0]+TrLP(0,z)+OutLP(0,z,dur);
						amax[n][z]=0;
					}//endfor z
					for(int zp=0;zp<nEffState;zp+=1){
						if(stateSalient[zp]==0){continue;}
						for(int z=0;z<nEffState;z+=1){
							trlp=TrLP(zp,z);
							if(trlp<-1E10){continue;}
							outlp=OutLP(zp,z,dur);
							if(outlp<-1E10){continue;}
							logP=preLP[zp]+trlp+outlp;
							if(logP>LP[z]){LP[z]=logP; amax[n][z]=zp;}
						}//endfor z
					}//endfor zp
				}//endif

			}//endfor n

			/// ///Backtracking and set stimes
			optPath[optPath.size()-1]=0;
			for(int z=0;z<nEffState;z+=1){
				if(LP[z]>LP[optPath[optPath.size()-1]]){optPath[optPath.size()-1]=z;}//endif
			}//endfor i
			for(int n=optPath.size()-2;n>=0;n-=1){optPath[n]=amax[n+1][optPath[n+1]];}//endfor n
			for(int n=1;n<ontimes[l].size();n+=1){
				stimes[l][n]=stimes[l][n-1]+insPattern[insPatIndexSplitter[indexSplitter[optPath[n]][2]][0]][insPatIndexSplitter[indexSplitter[optPath[n]][2]][1]][indexSplitter[optPath[n]][3]]+shiftVal[indexSplitter[optPath[n]][4]]-shiftVal[indexSplitter[optPath[n-1]][4]];
			}//endfor n

			///Write piece-specific parameter file
			stringstream ss;
			ss.str(""); ss<<paramFolder<<"param_patMM1DS_"<<l<<".txt";
			WriteFile(ss.str());

		}//endfor l
	}//end BayesTranscribe

};//endclass PatMM1DS






class PatMM1S : public PatMM1DS{
public:
	Prob<int> shiftProb;//shift probability (2*nBeat-1) [0]<->-(nBeat-1),[nBeat-1]<->0,[2*nBeat-2]<->nBeat-1
	vector<int> shiftVal;//(2*nBeat-1)

	vector<double> shiftDirParam;

	vector<vector<int> > indexSplitter;//[][0,1,2]=k,i,s
	vector<vector<vector<int> > > indexUnifier;//[k][i][s]
	int nEffState;//indexSplitter.size()

	PatMM1S(){
		printOn=true;
		pruningCutOff=1000;
	}//end PatMM1S
	~PatMM1S(){
	}//end ~PatMM1S

	void Clear(){
		iniPatProb.Clear();
		iniPatDirParam.clear();
		trPatProb.clear();
		trPatDirParam.clear();
		shiftVal.clear();
		shiftProb.Clear();
		shiftDirParam.clear();
	}//end Clear

	void RandomInit(int nBeat_){
		// Use after ReadPatterns
		Clear();
		nBeat=nBeat_;

		iniPatProb.Resize(nPat);
		iniPatProb.Randomize();
		iniPatDirParam.assign(nPat,1);
		trPatProb.resize(nPat);
		trPatDirParam.resize(nPat);
		for(int k=0;k<nPat;k+=1){
			trPatProb[k].Resize(nPat);
			trPatProb[k].Randomize();
			trPatDirParam[k].assign(nPat,1);
		}//endfor k

		shiftVal.clear();
		for(int val=-nBeat+1;val<=nBeat-1;val+=1){
			shiftVal.push_back(val);
		}//endfor val
		shiftProb.Resize(shiftVal.size());
		shiftProb.Randomize();
		shiftDirParam.assign(shiftVal.size(),1);

		vector<int> vi;
		indexSplitter.clear();
		indexUnifier.clear();
		bool goodIndex;
		vi.clear(); vi.resize(3);
		indexUnifier.resize(patterns.size());
		for(int k=0;k<patterns.size();k+=1){
			indexUnifier[k].resize(patterns[k].size());
			for(int i=0;i<patterns[k].size();i+=1){
				indexUnifier[k][i].resize(shiftVal.size());
				for(int s=0;s<shiftVal.size();s+=1){
					goodIndex=true;
					if(i<patterns[k].size()-1){
						//Impose B_{k_{n}i_{n}}+s_n < B_{k_{n}i_{n+1}}
						if(patterns[k][i]+shiftVal[s]>=patterns[k][i+1]){goodIndex=false;}
					}else{//i==patterns[k].size()-1
						//Impose B_{k_{n}i_{n}}+s_n <= nBeat}
						if(patterns[k][i]+shiftVal[s]>nBeat){goodIndex=false;}
					}//endif
					if(i>0){
						//Impose B_{k_{n}i_{n}}+s_n > B_{k_{n}i_{n-1}}
						if(patterns[k][i]+shiftVal[s]<=patterns[k][i-1]){goodIndex=false;}
					}//endif
					if(goodIndex){
						indexUnifier[k][i][s]=indexSplitter.size();
						vi[0]=k; vi[1]=i; vi[2]=s;
						indexSplitter.push_back(vi);
					}else{
						indexUnifier[k][i][s]=-1;
					}//endif
				}//endfor s
			}//endfor i
		}//endfor k
		nEffState=indexSplitter.size();
if(printOn){cout<<"nPat:\t"<<nPat<<endl;}
if(printOn){cout<<"nEffState:\t"<<nEffState<<endl;}
	}//end RandomInit

	void WriteFile(string filename){
		ofstream ofs(filename.c_str());
		ofs<<"//BeatResolution: "<<nBeat<<"\n";
		ofs<<"//NumOfPatterns: "<<nPat<<"\n";

		ofs<<"### Patterns\n";
		for(int i=0;i<nPat;i+=1){
ofs<<i<<"\t"<<patterns[i].size()<<" : ";
			for(int j=0;j<patterns[i].size();j+=1){
ofs<<patterns[i][j]<<" ";
			}//endfor j
ofs<<"\n";
		}//endfor i

		ofs<<"### Init Pattern Prob\n";
		for(int i=0;i<nPat;i+=1){
ofs<<iniPatProb.P[i]<<"\t";
		}//endfor i
ofs<<"\n";

		ofs<<"### Transition Pattern Prob\n";
		for(int i=0;i<nPat;i+=1){
			for(int ip=0;ip<nPat;ip+=1){
ofs<<trPatProb[i].P[ip]<<"\t";
			}//endfor ip
ofs<<"\n";
		}//endfor i

		ofs<<"### Shift Prob\n";
		for(int i=0;i<shiftVal.size();i+=1){
ofs<<shiftVal[i]<<"\t"<<shiftProb.P[i]<<"\n";
		}//endfor i

		ofs.close();
	}//end WriteFile

	void ReadFile(string filename){
		vector<int> v(100);
		vector<double> d(100);
		vector<string> s(100);
		stringstream ss;

		ifstream ifs(filename.c_str());
		ifs>>s[1]>>nBeat;
		getline(ifs,s[99]);
		ifs>>s[1]>>nPat;
		getline(ifs,s[99]);

		patterns.clear();
		patterns.resize(nPat);

		getline(ifs,s[99]);//### Patterns
		for(int i=0;i<nPat;i+=1){
			ifs>>v[1]>>v[2]>>s[3];
			for(int j=0;j<v[2];j+=1){
				ifs>>v[0];
				patterns[i].push_back(v[0]);
			}//endfor j
			getline(ifs,s[99]);
		}//endfor i

		RandomInit(nBeat);

		getline(ifs,s[99]);//### Init Pattern Prob
		for(int i=0;i<nPat;i+=1){
			ifs>>iniPatProb.P[i];
		}//endfor i
		getline(ifs,s[99]);
		iniPatProb.Normalize();

		getline(ifs,s[99]);//### Transition Pattern Prob
		for(int i=0;i<nPat;i+=1){
			for(int ip=0;ip<nPat;ip+=1){
				ifs>>trPatProb[i].P[ip];
			}//endfor ip
			getline(ifs,s[99]);
			trPatProb[i].Normalize();
		}//endfor i

		getline(ifs,s[99]);//### Shift Prob
		for(int i=0;i<shiftVal.size();i+=1){
			ifs>>d[1]>>shiftProb.P[i];
			getline(ifs,s[99]);
		}//endfor i
		shiftProb.Normalize();

		ifs.close();
	}//end ReadFile

	void ReadFileFromBasic(string filename,double interpCoeff=0){
		PatternMarkovModel basicModel;
		basicModel.ReadFile(filename);
		basicModel.LinearInterpolate(interpCoeff);
		nBeat=basicModel.nBeat;
		nPat=basicModel.nPat;
		patterns=basicModel.patterns;
		RandomInit(nBeat);
		uniPatProb=basicModel.uniPatProb;
		iniPatProb=basicModel.iniPatProb;
		trPatProb=basicModel.trPatProb;
	}//end ReadFileFromBasic

	void SetSimpleModificationModel(double noShiftP=0.9){
		for(int s=0;s<shiftVal.size();s+=1){
			if(s==nBeat-1){
				shiftProb.P[s]=noShiftP;
			}else{
				shiftProb.P[s]=(1-noShiftP)/double(shiftVal.size()-1);
			}//endif
		}//endfor s
		shiftProb.Normalize();
	}//end SetSimpleModificationModel

	void SetDirParam(double alpha_ini,double alpha_tr,double alpha_shift){
		for(int k=0;k<nPat;k+=1){
			iniPatDirParam[k]=alpha_ini*iniPatProb.P[k];
			for(int kp=0;kp<nPat;kp+=1){
				trPatDirParam[k][kp]=alpha_tr*trPatProb[k].P[kp];
			}//endfor kp
		}//endfor k
		for(int i=0;i<shiftVal.size();i+=1){
			shiftDirParam[i]=alpha_shift*shiftProb.P[i];
		}//endfor i
	}//end SetDirParam

	double OutLP(int zp,int z,double dur){
		int nv=patterns[indexSplitter[z][0]][indexSplitter[z][1]]-patterns[indexSplitter[zp][0]][indexSplitter[zp][1]]+((patterns[indexSplitter[z][0]][indexSplitter[z][1]]>patterns[indexSplitter[zp][0]][indexSplitter[zp][1]])? 0:nBeat)+shiftVal[indexSplitter[z][2]]-shiftVal[indexSplitter[zp][2]];
		if(nv>0){
			return -0.5*pow((dur-nv*secPerTick)/sig_t,2.);
		}else{
			return -DBL_MAX;
		}//endif
	}//end OutLP

	double TrLP(int zp,int z){
		double lp;
		if(indexSplitter[z][1]==0){
			if(indexSplitter[zp][1]==patterns[indexSplitter[zp][0]].size()-1){
				lp=trPatProb[indexSplitter[zp][0]].LP[indexSplitter[z][0]];
			}else{
				return -DBL_MAX;
			}//endif
		}else{//indexSplitter[z][1]>0
			if(indexSplitter[z][1]==indexSplitter[zp][1]+1
			   && indexSplitter[z][0]==indexSplitter[zp][0]){
				lp=0;
			}else{
				return -DBL_MAX;
			}//endif
		}//endif
		return lp+shiftProb.LP[indexSplitter[z][2]];
	}//end TrLP

	void Transcribe(){
		for(int l=0;l<ontimes.size();l+=1){
cout<<"Transcribe -- "<<(l+1)<<"/"<<ontimes.size()<<endl;
			///Viterbi
			vector<int> optPath(ontimes[l].size());
			vector<double> LP(nEffState);
			vector<vector<int> > amax;
			amax.resize(ontimes[l].size());
			for(int n=0;n<ontimes[l].size();n+=1){amax[n].resize(nEffState);}

			/// ///Initialization
			//(n=0) k,i=0,s are the only variables
			LP.assign(nEffState,-DBL_MAX);
			for(int k=0;k<patterns.size();k+=1){
				for(int s=0;s<shiftVal.size();s+=1){
					if(indexUnifier[k][0][s]<0){continue;}
					LP[indexUnifier[k][0][s]]=iniPatProb.LP[k]+shiftProb.LP[s];
				}//endfor s
			}//endfor k

			/// ///Update
			double dur;
			double logP;
			double trlp,outlp;
			for(int n=1;n<ontimes[l].size();n+=1){
				vector<double> preLP(LP);
				dur=ontimes[l][n]-ontimes[l][n-1];
				LP.assign(nEffState,-DBL_MAX);

				for(int z=0;z<nEffState;z+=1){
					LP[z]=preLP[0]+TrLP(0,z)+OutLP(0,z,dur);
					amax[n][z]=0;
					for(int zp=0;zp<nEffState;zp+=1){
						trlp=TrLP(zp,z);
						if(trlp<-1E10){continue;}
						outlp=OutLP(zp,z,dur);
						if(outlp<-1E10){continue;}
						logP=preLP[zp]+trlp+outlp;
						if(logP>LP[z]){LP[z]=logP; amax[n][z]=zp;}
					}//endfor zp
				}//endfor z
			}//endfor n

			/// ///Backtracking and set stimes
			optPath[optPath.size()-1]=0;
			for(int z=0;z<nEffState;z+=1){
				if(LP[z]>LP[optPath[optPath.size()-1]]){optPath[optPath.size()-1]=z;}//endif
			}//endfor i
			for(int n=optPath.size()-2;n>=0;n-=1){optPath[n]=amax[n+1][optPath[n+1]];}//endfor n
			for(int n=1;n<ontimes[l].size();n+=1){
				stimes[l][n]=stimes[l][n-1]
				              +patterns[indexSplitter[optPath[n]][0]][indexSplitter[optPath[n]][1]]-patterns[indexSplitter[optPath[n-1]][0]][indexSplitter[optPath[n-1]][1]]+((patterns[indexSplitter[optPath[n]][0]][indexSplitter[optPath[n]][1]]>patterns[indexSplitter[optPath[n-1]][0]][indexSplitter[optPath[n-1]][1]])? 0:nBeat)+shiftVal[indexSplitter[optPath[n]][2]]-shiftVal[indexSplitter[optPath[n-1]][2]];
			}//endfor n

		}//endfor l
	}//end Transcribe


	void BayesTranscribe(int nIter=10, int seed=2){
		/// Should be used after setting Dirichlet parameters
		boost::mt19937 gen;
		gen.seed(seed);
		Prob<int> genIniPatProb(iniPatProb);
		vector<Prob<int> > genTrPatProb(trPatProb);
		Prob<int> genShiftProb(shiftProb);//shift probability (2*nBeat-1) [0]<->-(nBeat-1),[nBeat-1]<->0,[2*nBeat-2]<->nBeat-1

		for(int l=0;l<ontimes.size();l+=1){
if(printOn){cout<<"BayesTranscribe -- "<<(l+1)<<"/"<<ontimes.size()<<endl;}

			iniPatProb=genIniPatProb;
			trPatProb=genTrPatProb;
			shiftProb=genShiftProb;
			Prob<int> maxIniPatProb(iniPatProb);
			vector<Prob<int> > maxTrPatProb(trPatProb);
			Prob<int> maxShiftProb(shiftProb);//shift probability (2*nBeat-1) [0]<->-(nBeat-1),[nBeat-1]<->0,[2*nBeat-2]<->nBeat-1
			double evidLP;
			double maxEvidLP;
			int maxIter;
			double dur;

			///Gibbs sampling
			for(int iter=0;iter<nIter;iter+=1){

				///Sample scores by forward-filtering backward sampling
				vector<int> sampledStates(ontimes[l].size());
				vector<vector<double> > forwardVar;// ontimes[l].size() x nEffState
				forwardVar.resize(ontimes[l].size());
				for(int n=0;n<ontimes[l].size();n+=1){forwardVar[n].assign(nEffState,-DBL_MAX);}

				/// //Forward
				//(n=0) k,i=0,s are the only variables
				for(int k=0;k<patterns.size();k+=1){
					for(int s=0;s<shiftVal.size();s+=1){
						if(indexUnifier[k][0][s]<0){continue;}
						forwardVar[0][indexUnifier[k][0][s]]=iniPatProb.LP[k]+shiftProb.LP[s];
					}//endfor s
				}//endfor k

				double trlp,outlp;
				for(int n=1;n<ontimes[l].size();n+=1){
					dur=ontimes[l][n]-ontimes[l][n-1];

					for(int z=0;z<nEffState;z+=1){
						for(int zp=0;zp<nEffState;zp+=1){
							trlp=TrLP(zp,z);
							if(trlp<-1E10){continue;}
							outlp=OutLP(zp,z,dur);
							if(outlp<-1E10){continue;}
							forwardVar[n][z]=LogAdd(forwardVar[n][z],forwardVar[n-1][zp]+trlp+outlp);
						}//endfor zp
					}//endfor z

				}//endfor n

				evidLP=-DBL_MAX;
				for(int z=0;z<nEffState;z+=1){
					evidLP=LogAdd(evidLP,forwardVar[ontimes[l].size()-1][z]);
				}//endfor z

				if(iter==0 || evidLP>maxEvidLP){
					maxEvidLP=evidLP;
					maxIniPatProb=iniPatProb;
					maxTrPatProb=trPatProb;
					maxShiftProb=shiftProb;
					maxIter=iter;
				}//endif
if(printOn){cout<<"Iteration: "<<iter<<"\t-NORM(evidLP,maxEvidLP): "<<-evidLP/double(ontimes[l].size())<<"\t"<<-maxEvidLP/double(ontimes[l].size())<<"\t"<<((evidLP==maxEvidLP)? "******":"")<<endl;}

				/// //Backward sampling
				Prob<int> prob;
				prob.LP=forwardVar[ontimes[l].size()-1];
				prob.LogNormalize();
				sampledStates[ontimes[l].size()-1]=SampleDistr(prob.P);

				for(int n=ontimes[l].size()-2;n>=1;n-=1){
					for(int i=0;i<nEffState;i+=1){
						prob.LP[i]=forwardVar[n][i]+TrLP(i,sampledStates[n+1])+OutLP(i,sampledStates[n+1],ontimes[l][n+1]-ontimes[l][n]);
					}//endfor i
					prob.LogNormalize();
					sampledStates[n]=SampleDistr(prob.P);
				}//endfor n

				prob.LP.assign(nEffState,-DBL_MAX);
				for(int k=0;k<patterns.size();k+=1){
					for(int s=0;s<shiftVal.size();s+=1){
						if(indexUnifier[k][0][s]<0){continue;}
						prob.LP[indexUnifier[k][0][s]]=forwardVar[0][indexUnifier[k][0][s]]+TrLP(indexUnifier[k][0][s],sampledStates[1])+OutLP(indexUnifier[k][0][s],sampledStates[1],ontimes[l][1]-ontimes[l][0]);
					}//endfor s
				}//endfor k
				prob.LogNormalize();
				sampledStates[0]=SampleDistr(prob.P);

				///Sample parameters
				iniPatProb.P=iniPatDirParam;
				iniPatProb.P[indexSplitter[sampledStates[0]][0]]+=1;
				for(int k=0;k<patterns.size();k+=1){
					boost::gamma_distribution<> dst( iniPatProb.P[k], 1. );
					boost::variate_generator<boost::mt19937&, boost::gamma_distribution<> > gamma_rand( gen, dst );
					iniPatProb.P[k]=gamma_rand();
				}//endfor k
				iniPatProb.Normalize();

				for(int k=0;k<patterns.size();k+=1){
					trPatProb[k].P=trPatDirParam[k];
				}//endfor k
				for(int n=1;n<ontimes[l].size();n+=1){
					if(indexSplitter[sampledStates[n]][1]!=0){continue;}
					trPatProb[indexSplitter[sampledStates[n-1]][0]].P[indexSplitter[sampledStates[n]][0]]+=1;
				}//endfor n
				for(int k=0;k<patterns.size();k+=1){
					for(int kp=0;kp<patterns.size();kp+=1){
						boost::gamma_distribution<> dst( trPatProb[k].P[kp], 1. );
						boost::variate_generator<boost::mt19937&, boost::gamma_distribution<> > gamma_rand( gen, dst );
						trPatProb[k].P[kp]=gamma_rand();
					}//endfor kp
					trPatProb[k].Normalize();
				}//endfor k

				shiftProb.P=shiftDirParam;
				for(int n=0;n<ontimes[l].size();n+=1){
					shiftProb.P[indexSplitter[sampledStates[n]][2]]+=1;
				}//endfor n
				for(int s=0;s<shiftVal.size();s+=1){
					boost::gamma_distribution<> dst( shiftProb.P[s], 1. );
					boost::variate_generator<boost::mt19937&, boost::gamma_distribution<> > gamma_rand( gen, dst );
					shiftProb.P[s]=gamma_rand();
				}//endfor s
				shiftProb.Normalize();

			}//endfor iter

			///Set optimal parameter
			iniPatProb=maxIniPatProb;
			trPatProb=maxTrPatProb;
			shiftProb=maxShiftProb;

			///Viterbi
			vector<int> optPath(ontimes[l].size());
			vector<double> LP(nEffState);
			vector<vector<int> > amax;
			amax.resize(ontimes[l].size());
			for(int n=0;n<ontimes[l].size();n+=1){amax[n].resize(nEffState);}

			/// ///Initialization
			//(n=0) k,i=0,s are the only variables
			LP.assign(nEffState,-DBL_MAX);
			for(int k=0;k<patterns.size();k+=1){
				for(int s=0;s<shiftVal.size();s+=1){
					if(indexUnifier[k][0][s]<0){continue;}
					LP[indexUnifier[k][0][s]]=iniPatProb.LP[k]+shiftProb.LP[s];
				}//endfor s
			}//endfor k

			/// ///Update
			double logP;
			double trlp,outlp;
			for(int n=1;n<ontimes[l].size();n+=1){
				vector<double> preLP(LP);
				dur=ontimes[l][n]-ontimes[l][n-1];
				LP.assign(nEffState,-DBL_MAX);

				for(int z=0;z<nEffState;z+=1){
					LP[z]=preLP[0]+TrLP(0,z)+OutLP(0,z,dur);
					amax[n][z]=0;
					for(int zp=0;zp<nEffState;zp+=1){
						trlp=TrLP(zp,z);
						if(trlp<-1E10){continue;}
						outlp=OutLP(zp,z,dur);
						if(outlp<-1E10){continue;}
						logP=preLP[zp]+trlp+outlp;
						if(logP>LP[z]){LP[z]=logP; amax[n][z]=zp;}
					}//endfor zp
				}//endfor z
			}//endfor n

			/// ///Backtracking and set stimes
			optPath[optPath.size()-1]=0;
			for(int z=0;z<nEffState;z+=1){
				if(LP[z]>LP[optPath[optPath.size()-1]]){optPath[optPath.size()-1]=z;}//endif
			}//endfor i
			for(int n=optPath.size()-2;n>=0;n-=1){optPath[n]=amax[n+1][optPath[n+1]];}//endfor n
			for(int n=1;n<ontimes[l].size();n+=1){
				stimes[l][n]=stimes[l][n-1]
				              +patterns[indexSplitter[optPath[n]][0]][indexSplitter[optPath[n]][1]]-patterns[indexSplitter[optPath[n-1]][0]][indexSplitter[optPath[n-1]][1]]+((patterns[indexSplitter[optPath[n]][0]][indexSplitter[optPath[n]][1]]>patterns[indexSplitter[optPath[n-1]][0]][indexSplitter[optPath[n-1]][1]])? 0:nBeat)+shiftVal[indexSplitter[optPath[n]][2]]-shiftVal[indexSplitter[optPath[n-1]][2]];
			}//endfor n

			///Write piece-specific parameter file
			stringstream ss;
			ss.str(""); ss<<paramFolder<<"param_patMM1S_"<<l<<".txt";
			WriteFile(ss.str());

		}//endfor l
	}//end BayesTranscribe

};//endclass PatMM1S













class PatMM1D : public PatMM1DS{
public:
	vector<vector<vector<int> > > insPattern;//[nvID][h][g]
	vector<Prob<int> > insProb;//insertion probability r -> h

	vector<vector<double> > insDirParam;

	vector<vector<int> > insPatIndexSplitter;//[H][0,1]=nvID,h
	vector<vector<int> > insPatIndexUnifier;//[nvID][h]=H
	int nInsPat;

	vector<vector<int> > indexSplitter;//[][0,1,2,3]=k,i,H,g
	vector<vector<vector<vector<int> > > > indexUnifier;//[k][i][H][g]
	int nEffState;//indexSplitter.size()

	PatMM1D(){
		printOn=true;
		pruningCutOff=1000;
	}//end PatMM1D
	~PatMM1D(){
	}//end ~PatMM1D

	void Clear(){
		iniPatProb.Clear();
		iniPatDirParam.clear();
		trPatProb.clear();
		trPatDirParam.clear();
		insPattern.clear();
		insProb.clear();
		insDirParam.clear();
	}//end Clear

	void RandomInit(int nBeat_){
		// Use after ReadPatterns
		Clear();
		nBeat=nBeat_;

		iniPatProb.Resize(nPat);
		iniPatProb.Randomize();
		iniPatDirParam.assign(nPat,1);
		trPatProb.resize(nPat);
		trPatDirParam.resize(nPat);
		for(int k=0;k<nPat;k+=1){
			trPatProb[k].Resize(nPat);
			trPatProb[k].Randomize();
			trPatDirParam[k].assign(nPat,1);
		}//endfor k

		insPattern.resize(nBeat);
		insProb.resize(nBeat);
		insDirParam.resize(nBeat);
		vector<int> vi;
		for(int i=0;i<nBeat;i+=1){
			vi.clear();
			vi.push_back(i+1);
			insPattern[i].push_back(vi);
			for(int j=1;j<=i;j+=1){
				vi.clear();
				vi.push_back(j);
				vi.push_back(i+1-j);
				insPattern[i].push_back(vi);
			}//endfor j
			insProb[i].Resize(insPattern[i].size());
			insProb[i].Randomize();
			insDirParam[i].assign(insPattern[i].size(),1);
		}//endfor i

		insPatIndexSplitter.clear();
		insPatIndexUnifier.clear();
		vi.clear(); vi.resize(2);
		insPatIndexUnifier.resize(nBeat);
		for(int r=0;r<nBeat;r+=1){
			insPatIndexUnifier[r].resize(insPattern[r].size());
			for(int h=0;h<insPattern[r].size();h+=1){
				insPatIndexUnifier[r][h]=insPatIndexSplitter.size();
				vi[0]=r; vi[1]=h;
				insPatIndexSplitter.push_back(vi);
			}//endfor h
		}//endfor r
		nInsPat=insPatIndexSplitter.size();
if(printOn){cout<<"nPat:\t"<<nPat<<endl;}
if(printOn){cout<<"nInsPat:\t"<<nInsPat<<endl;}

		indexSplitter.clear();
		indexUnifier.clear();
		bool goodIndex;
		vi.clear(); vi.resize(4);
		indexUnifier.resize(patterns.size());
		for(int k=0;k<patterns.size();k+=1){
			indexUnifier[k].resize(patterns[k].size());
			for(int i=0;i<patterns[k].size();i+=1){
				indexUnifier[k][i].resize(nInsPat);
				for(int H=0;H<nInsPat;H+=1){
					indexUnifier[k][i][H].resize(insPattern[insPatIndexSplitter[H][0]][insPatIndexSplitter[H][1]].size());
					for(int g=0;g<insPattern[insPatIndexSplitter[H][0]][insPatIndexSplitter[H][1]].size();g+=1){
						goodIndex=true;
						if(i>0){
							// H<->patterns[k][i] (if i>=2)
							if(insPatIndexSplitter[H][0]+1!=patterns[k][i]-patterns[k][i-1]){goodIndex=false;}
						}//endif
						if(goodIndex){
							indexUnifier[k][i][H][g]=indexSplitter.size();
							vi[0]=k; vi[1]=i; vi[2]=H; vi[3]=g;
							indexSplitter.push_back(vi);
						}else{
							indexUnifier[k][i][H][g]=-1;
						}//endif
					}//endfor g
				}//endfor H
			}//endfor i
		}//endfor k
		nEffState=indexSplitter.size();
if(printOn){cout<<"nEffState:\t"<<nEffState<<endl;}
	}//end RandomInit

	void WriteFile(string filename){
		ofstream ofs(filename.c_str());
		ofs<<"//BeatResolution: "<<nBeat<<"\n";
		ofs<<"//NumOfPatterns: "<<nPat<<"\n";

		ofs<<"### Patterns\n";
		for(int i=0;i<nPat;i+=1){
ofs<<i<<"\t"<<patterns[i].size()<<" : ";
			for(int j=0;j<patterns[i].size();j+=1){
ofs<<patterns[i][j]<<" ";
			}//endfor j
ofs<<"\n";
		}//endfor i

		ofs<<"### Init Pattern Prob\n";
		for(int i=0;i<nPat;i+=1){
ofs<<iniPatProb.P[i]<<"\t";
		}//endfor i
ofs<<"\n";

		ofs<<"### Transition Pattern Prob\n";
		for(int i=0;i<nPat;i+=1){
			for(int ip=0;ip<nPat;ip+=1){
ofs<<trPatProb[i].P[ip]<<"\t";
			}//endfor ip
ofs<<"\n";
		}//endfor i

		ofs<<"### Insertion Prob\n";
		for(int i=0;i<insPattern.size();i+=1){
			for(int h=0;h<insPattern[i].size();h+=1){
ofs<<i+1<<"\t"<<h<<"\t"<<insProb[i].P[h]<<"\t"<<insPattern[i][h].size()<<"\t";
				for(int g=0;g<insPattern[i][h].size();g+=1){
ofs<<insPattern[i][h][g]<<" ";
				}//endfor g
ofs<<"\n";
			}//endfor h
		}//endfor i

		ofs.close();
	}//end WriteFile

	void ReadFile(string filename){
		vector<int> v(100);
		vector<double> d(100);
		vector<string> s(100);
		stringstream ss;

		ifstream ifs(filename.c_str());
		ifs>>s[1]>>nBeat;
		getline(ifs,s[99]);
		ifs>>s[1]>>nPat;
		getline(ifs,s[99]);

		patterns.clear();
		patterns.resize(nPat);

		getline(ifs,s[99]);//### Patterns
		for(int i=0;i<nPat;i+=1){
			ifs>>v[1]>>v[2]>>s[3];
			for(int j=0;j<v[2];j+=1){
				ifs>>v[0];
				patterns[i].push_back(v[0]);
			}//endfor j
			getline(ifs,s[99]);
		}//endfor i

		RandomInit(nBeat);

		getline(ifs,s[99]);//### Init Pattern Prob
		for(int i=0;i<nPat;i+=1){
			ifs>>iniPatProb.P[i];
		}//endfor i
		getline(ifs,s[99]);
		iniPatProb.Normalize();

		getline(ifs,s[99]);//### Transition Pattern Prob
		for(int i=0;i<nPat;i+=1){
			for(int ip=0;ip<nPat;ip+=1){
				ifs>>trPatProb[i].P[ip];
			}//endfor ip
			getline(ifs,s[99]);
			trPatProb[i].Normalize();
		}//endfor i

		getline(ifs,s[99]);//### Insertion Prob
		for(int i=0;i<insPattern.size();i+=1){
			for(int h=0;h<insPattern[i].size();h+=1){
				ifs>>d[1]>>d[2]>>insProb[i].P[h];
				getline(ifs,s[99]);
			}//endfor h
			insProb[i].Normalize();
		}//endfor i

		ifs.close();
	}//end ReadFile

	void ReadFileFromBasic(string filename,double interpCoeff=0){
		PatternMarkovModel basicModel;
		basicModel.ReadFile(filename);
		basicModel.LinearInterpolate(interpCoeff);
		nBeat=basicModel.nBeat;
		nPat=basicModel.nPat;
		patterns=basicModel.patterns;
		RandomInit(nBeat);
		uniPatProb=basicModel.uniPatProb;
		iniPatProb=basicModel.iniPatProb;
		trPatProb=basicModel.trPatProb;
	}//end ReadFileFromBasic

	void SetSimpleModificationModel(double noInsP=0.9){
		for(int i=0;i<nBeat;i+=1){
			insProb[i].P[0]=noInsP;
			for(int h=1;h<insPattern[i].size();h+=1){
				insProb[i].P[h]=(1-noInsP)/double(insPattern[i].size()-1);
			}//endfor h
			insProb[i].Normalize();
		}//endfor i
	}//end SetSimpleModificationModel

	void SetDirParam(double alpha_ini,double alpha_tr,double alpha_ins){
		for(int k=0;k<nPat;k+=1){
			iniPatDirParam[k]=alpha_ini*iniPatProb.P[k];
			for(int kp=0;kp<nPat;kp+=1){
				trPatDirParam[k][kp]=alpha_tr*trPatProb[k].P[kp];
			}//endfor kp
		}//endfor k
		for(int i=0;i<nBeat;i+=1){
			for(int h=0;h<insPattern[i].size();h+=1){
				insDirParam[i][h]=alpha_ins*insProb[i].P[h];
			}//endfor h
		}//endfor i
	}//end SetDirParam

	double OutLP(int z,double dur){
		int nv=insPattern[insPatIndexSplitter[indexSplitter[z][2]][0]][insPatIndexSplitter[indexSplitter[z][2]][1]][indexSplitter[z][3]];
		if(nv>0){
			return -0.5*pow((dur-nv*secPerTick)/sig_t,2.);
		}else{
			return -DBL_MAX;
		}//endif
	}//end OutLP

	double TrLP(int zp,int z){
		int nvID=patterns[indexSplitter[z][0]][indexSplitter[z][1]]-patterns[indexSplitter[zp][0]][indexSplitter[zp][1]]+((patterns[indexSplitter[z][0]][indexSplitter[z][1]]>patterns[indexSplitter[zp][0]][indexSplitter[zp][1]])? 0:nBeat)-1;
		if(indexSplitter[z][3]==0){
			if(indexSplitter[zp][3]==insPattern[insPatIndexSplitter[indexSplitter[zp][2]][0]][insPatIndexSplitter[indexSplitter[zp][2]][1]].size()-1){
				double lp;
				if(indexSplitter[z][1]==0){
					if(indexSplitter[zp][1]==patterns[indexSplitter[zp][0]].size()-1){
						lp=trPatProb[indexSplitter[zp][0]].LP[indexSplitter[z][0]];
					}else{
						return -DBL_MAX;
					}//endif
				}else{//indexSplitter[z][1]>0
					if(indexSplitter[z][1]==indexSplitter[zp][1]+1
					   && indexSplitter[z][0]==indexSplitter[zp][0]){
						lp=0;
					}else{
						return -DBL_MAX;
					}//endif
				}//endif

				if(insPatIndexSplitter[indexSplitter[z][2]][0]==nvID){
					return lp+insProb[insPatIndexSplitter[indexSplitter[z][2]][0]].LP[insPatIndexSplitter[indexSplitter[z][2]][1]];
				}else{
					return -DBL_MAX;
				}//endif

			}else{
				return -DBL_MAX;
			}//endif
		}else{//indexSplitter[z][3]>0
			if(indexSplitter[z][3]==indexSplitter[zp][3]+1
			   && indexSplitter[z][0]==indexSplitter[zp][0]
			   && indexSplitter[z][1]==indexSplitter[zp][1]
			   && indexSplitter[z][2]==indexSplitter[zp][2]){
				return 0;
			}else{
				return -DBL_MAX;
			}//endif
		}//endif
	}//end TrLP

	double FirstTrLP(int zp,int z){
		if(indexSplitter[z][3]!=0){return -DBL_MAX;}
		int nvID=patterns[indexSplitter[z][0]][indexSplitter[z][1]]-patterns[indexSplitter[zp][0]][indexSplitter[zp][1]]+((patterns[indexSplitter[z][0]][indexSplitter[z][1]]>patterns[indexSplitter[zp][0]][indexSplitter[zp][1]])? 0:nBeat)-1;

		double lp;
		if(indexSplitter[z][1]==0){
			if(indexSplitter[zp][1]==patterns[indexSplitter[zp][0]].size()-1){
				lp=trPatProb[indexSplitter[zp][0]].LP[indexSplitter[z][0]];
			}else{
				return -DBL_MAX;
			}//endif
		}else{//indexSplitter[z][1]>0
			if(indexSplitter[z][1]==indexSplitter[zp][1]+1
			   && indexSplitter[z][0]==indexSplitter[zp][0]){
				lp=0;
			}else{
				return -DBL_MAX;
			}//endif
		}//endif

		if(insPatIndexSplitter[indexSplitter[z][2]][0]==nvID){
			return lp+insProb[insPatIndexSplitter[indexSplitter[z][2]][0]].LP[insPatIndexSplitter[indexSplitter[z][2]][1]];
		}else{
			return -DBL_MAX;
		}//endif
	}//end FirstTrLP

	void Transcribe(){
		for(int l=0;l<ontimes.size();l+=1){
// cout<<"Transcribe -- "<<(l+1)<<"/"<<ontimes.size()<<endl;
			///Viterbi
			vector<int> optPath(ontimes[l].size());
			vector<double> LP(nEffState);
			vector<vector<int> > amax;
			amax.resize(ontimes[l].size());
			for(int n=0;n<ontimes[l].size();n+=1){amax[n].resize(nEffState);}
			vector<int> stateSalient;

			/// ///Initialization
			//(n=0) H=g=0, k,i=0 are the only variables
			LP.assign(nEffState,-DBL_MAX);
			for(int k=0;k<patterns.size();k+=1){
				if(indexUnifier[k][0][0][0]<0){continue;}
				LP[indexUnifier[k][0][0][0]]=iniPatProb.LP[k];
			}//endfor k

			/// ///Update
			double dur;
			double logP;
			double trlp,outlp;
			for(int n=1;n<ontimes[l].size();n+=1){
				vector<double> preLP(LP);
				dur=ontimes[l][n]-ontimes[l][n-1];
				LP.assign(nEffState,-DBL_MAX);

					stateSalient.assign(nEffState,0);
					vector<Pair> pairs;
					Pair pair;
					for(int z=0;z<nEffState;z+=1){
						pair.ID=z; pair.value=preLP[z];
						pairs.push_back(pair);
					}//endfor z
					sort(pairs.begin(), pairs.end(), MorePair());
					for(int z=0;z<pruningCutOff;z+=1){
						stateSalient[pairs[z].ID]=1;
//cout<<pairs[z].ID<<"\t"<<pairs[z].value<<endl;
					}//endfor z

				if(n==1){
					for(int z=0;z<nEffState;z+=1){
						if(indexSplitter[z][3]!=0){continue;}
						LP[z]=preLP[indexUnifier[0][0][0][0]]+FirstTrLP(indexUnifier[0][0][0][0],z)+OutLP(z,dur);
						amax[n][z]=indexUnifier[0][0][0][0];
						for(int k=0;k<patterns.size();k+=1){
							if(indexUnifier[k][0][0][0]<0){continue;}
							logP=preLP[indexUnifier[k][0][0][0]]+FirstTrLP(indexUnifier[k][0][0][0],z)+OutLP(z,dur);
							if(logP>LP[z]){LP[z]=logP; amax[n][z]=indexUnifier[k][0][0][0];}
						}//endfor k
					}//endfor z
					continue;
				}//endif

				for(int z=0;z<nEffState;z+=1){
					LP[z]=preLP[0]+TrLP(0,z)+OutLP(z,dur);
					amax[n][z]=0;
				}//endfor z
				for(int zp=0;zp<nEffState;zp+=1){
					if(stateSalient[zp]==0){continue;}
					for(int z=0;z<nEffState;z+=1){
						trlp=TrLP(zp,z);
						if(trlp<-1E10){continue;}
						outlp=OutLP(z,dur);
						if(outlp<-1E10){continue;}
						logP=preLP[zp]+trlp+outlp;
						if(logP>LP[z]){LP[z]=logP; amax[n][z]=zp;}
					}//endfor z
				}//endfor zp

			}//endfor n

			/// ///Backtracking and set stimes
			optPath[optPath.size()-1]=0;
			for(int z=0;z<nEffState;z+=1){
				if(LP[z]>LP[optPath[optPath.size()-1]]){optPath[optPath.size()-1]=z;}//endif
			}//endfor i
			for(int n=optPath.size()-2;n>=0;n-=1){optPath[n]=amax[n+1][optPath[n+1]];}//endfor n
			for(int n=1;n<ontimes[l].size();n+=1){
				stimes[l][n]=stimes[l][n-1]+insPattern[insPatIndexSplitter[indexSplitter[optPath[n]][2]][0]][insPatIndexSplitter[indexSplitter[optPath[n]][2]][1]][indexSplitter[optPath[n]][3]];
			}//endfor n

		}//endfor l
	}//end Transcribe


	void BayesTranscribe(int nIter=10, int seed=2){
		/// Should be used after setting Dirichlet parameters
		boost::mt19937 gen;
		gen.seed(seed);
		Prob<int> genIniPatProb(iniPatProb);
		vector<Prob<int> > genTrPatProb(trPatProb);
		vector<Prob<int> > genInsProb(insProb);//insertion probability r -> h

		for(int l=0;l<ontimes.size();l+=1){
if(printOn){cout<<"BayesTranscribe -- "<<(l+1)<<"/"<<ontimes.size()<<endl;}

			iniPatProb=genIniPatProb;
			trPatProb=genTrPatProb;
			insProb=genInsProb;
			Prob<int> maxIniPatProb(iniPatProb);
			vector<Prob<int> > maxTrPatProb(trPatProb);
			vector<Prob<int> > maxInsProb(insProb);//insertion probability r -> h
			double evidLP;
			double maxEvidLP;
			int maxIter;
			double dur;

			///Gibbs sampling
			for(int iter=0;iter<nIter;iter+=1){

				///Sample scores by forward-filtering backward sampling
				vector<int> sampledStates(ontimes[l].size());
				vector<vector<double> > forwardVar;// ontimes[l].size() x nEffState
				forwardVar.resize(ontimes[l].size());
				for(int n=0;n<ontimes[l].size();n+=1){forwardVar[n].assign(nEffState,-DBL_MAX);}
				vector<int> stateSalient;

				/// //Forward
				//(n=0) H=g=0, k,i=0 are the only variables
				for(int k=0;k<patterns.size();k+=1){
					if(indexUnifier[k][0][0][0]<0){continue;}
					forwardVar[0][indexUnifier[k][0][0][0]]=iniPatProb.LP[k];
				}//endfor k

				double trlp,outlp;
				for(int n=1;n<ontimes[l].size();n+=1){
					dur=ontimes[l][n]-ontimes[l][n-1];
//cout<<"n:\t"<<n<<endl;

					stateSalient.assign(nEffState,0);
					vector<Pair> pairs;
					Pair pair;
					for(int z=0;z<nEffState;z+=1){
						pair.ID=z; pair.value=forwardVar[n-1][z];
						pairs.push_back(pair);
					}//endfor z
					sort(pairs.begin(), pairs.end(), MorePair());
					for(int z=0;z<pruningCutOff;z+=1){
						stateSalient[pairs[z].ID]=1;
//cout<<pairs[z].ID<<"\t"<<pairs[z].value<<endl;
					}//endfor z

					if(n==1){
						for(int z=0;z<nEffState;z+=1){
							if(indexSplitter[z][3]!=0){continue;}
							for(int k=0;k<patterns.size();k+=1){
								if(stateSalient[indexUnifier[k][0][0][0]]==0){continue;}
								if(indexUnifier[k][0][0][0]<0){continue;}
								forwardVar[n][z]=LogAdd(forwardVar[n][z],
									forwardVar[n-1][indexUnifier[k][0][0][0]]+FirstTrLP(indexUnifier[k][0][0][0],z)+OutLP(z,dur)
								);
							}//endfor k
						}//endfor z
						continue;
					}//endif

					for(int zp=0;zp<nEffState;zp+=1){
						if(stateSalient[zp]==0){continue;}
						for(int z=0;z<nEffState;z+=1){
							trlp=TrLP(zp,z);
							if(trlp<-1E10){continue;}
							outlp=OutLP(z,dur);
							if(outlp<-1E10){continue;}
							forwardVar[n][z]=LogAdd(forwardVar[n][z],forwardVar[n-1][zp]+trlp+outlp);
						}//endfor z
					}//endfor zp

				}//endfor n

				evidLP=-DBL_MAX;
				for(int z=0;z<nEffState;z+=1){
					evidLP=LogAdd(evidLP,forwardVar[ontimes[l].size()-1][z]);
				}//endfor z

				if(iter==0 || evidLP>maxEvidLP){
					maxEvidLP=evidLP;
					maxIniPatProb=iniPatProb;
					maxTrPatProb=trPatProb;
					maxInsProb=insProb;
					maxIter=iter;
				}//endif
if(printOn){cout<<"Iteration: "<<iter<<"\t-NORM(evidLP,maxEvidLP): "<<-evidLP/double(ontimes[l].size())<<"\t"<<-maxEvidLP/double(ontimes[l].size())<<"\t"<<((evidLP==maxEvidLP)? "******":"")<<endl;}

				/// //Backward sampling
				Prob<int> prob;
				prob.LP=forwardVar[ontimes[l].size()-1];
				prob.LogNormalize();
				sampledStates[ontimes[l].size()-1]=SampleDistr(prob.P);

				for(int n=ontimes[l].size()-2;n>=1;n-=1){
					for(int i=0;i<nEffState;i+=1){
						prob.LP[i]=forwardVar[n][i]+TrLP(i,sampledStates[n+1]);
					}//endfor i
					prob.LogNormalize();
					sampledStates[n]=SampleDistr(prob.P);
				}//endfor n

				prob.LP.assign(nEffState,-DBL_MAX);
				for(int k=0;k<patterns.size();k+=1){
					if(indexUnifier[k][0][0][0]<0){continue;}
					prob.LP[indexUnifier[k][0][0][0]]=forwardVar[0][indexUnifier[k][0][0][0]]+FirstTrLP(indexUnifier[k][0][0][0],sampledStates[1]);
				}//endfor k
				prob.LogNormalize();
				sampledStates[0]=SampleDistr(prob.P);

				///Sample parameters
				iniPatProb.P=iniPatDirParam;
				iniPatProb.P[indexSplitter[sampledStates[0]][0]]+=1;
				for(int k=0;k<patterns.size();k+=1){
					boost::gamma_distribution<> dst( iniPatProb.P[k], 1. );
					boost::variate_generator<boost::mt19937&, boost::gamma_distribution<> > gamma_rand( gen, dst );
					iniPatProb.P[k]=gamma_rand();
				}//endfor k
				iniPatProb.Normalize();

				for(int k=0;k<patterns.size();k+=1){
					trPatProb[k].P=trPatDirParam[k];
				}//endfor k
				for(int n=1;n<ontimes[l].size();n+=1){
					if(indexSplitter[sampledStates[n]][1]!=0 || indexSplitter[sampledStates[n]][3]!=0){continue;}
					trPatProb[indexSplitter[sampledStates[n-1]][0]].P[indexSplitter[sampledStates[n]][0]]+=1;
				}//endfor n
				for(int k=0;k<patterns.size();k+=1){
					for(int kp=0;kp<patterns.size();kp+=1){
						boost::gamma_distribution<> dst( trPatProb[k].P[kp], 1. );
						boost::variate_generator<boost::mt19937&, boost::gamma_distribution<> > gamma_rand( gen, dst );
						trPatProb[k].P[kp]=gamma_rand();
					}//endfor kp
					trPatProb[k].Normalize();
				}//endfor k

				for(int r=0;r<nBeat;r+=1){
					insProb[r].P=insDirParam[r];
				}//endfor r
				for(int n=1;n<ontimes[l].size();n+=1){
					if(indexSplitter[sampledStates[n]][3]!=0){continue;}
					insProb[insPatIndexSplitter[indexSplitter[sampledStates[n]][2]][0]].P[insPatIndexSplitter[indexSplitter[sampledStates[n]][2]][1]]+=1;
				}//endfor n
				for(int r=0;r<nBeat;r+=1){
					for(int h=0;h<insDirParam[r].size();h+=1){
						boost::gamma_distribution<> dst( insProb[r].P[h], 1. );
						boost::variate_generator<boost::mt19937&, boost::gamma_distribution<> > gamma_rand( gen, dst );
						insProb[r].P[h]=gamma_rand();
					}//endfor h
					insProb[r].Normalize();
				}//endfor r

			}//endfor iter

			///Set optimal parameter
			iniPatProb=maxIniPatProb;
			trPatProb=maxTrPatProb;
			insProb=maxInsProb;

			///Viterbi
			vector<int> optPath(ontimes[l].size());
			vector<double> LP(nEffState);
			vector<vector<int> > amax;
			amax.resize(ontimes[l].size());
			for(int n=0;n<ontimes[l].size();n+=1){amax[n].resize(nEffState);}
			vector<int> stateSalient;

			/// ///Initialization
			//(n=0) H=g=0, k,i=0 are the only variables
			LP.assign(nEffState,-DBL_MAX);
			for(int k=0;k<patterns.size();k+=1){
				if(indexUnifier[k][0][0][0]<0){continue;}
				LP[indexUnifier[k][0][0][0]]=iniPatProb.LP[k];
			}//endfor k

			/// ///Update
			double logP;
			double trlp,outlp;
			for(int n=1;n<ontimes[l].size();n+=1){
				vector<double> preLP(LP);
				dur=ontimes[l][n]-ontimes[l][n-1];
				LP.assign(nEffState,-DBL_MAX);

					stateSalient.assign(nEffState,0);
					vector<Pair> pairs;
					Pair pair;
					for(int z=0;z<nEffState;z+=1){
						pair.ID=z; pair.value=preLP[z];
						pairs.push_back(pair);
					}//endfor z
					sort(pairs.begin(), pairs.end(), MorePair());
					for(int z=0;z<pruningCutOff;z+=1){
						stateSalient[pairs[z].ID]=1;
//cout<<pairs[z].ID<<"\t"<<pairs[z].value<<endl;
					}//endfor z

				if(n==1){
					for(int z=0;z<nEffState;z+=1){
						if(indexSplitter[z][3]!=0){continue;}
						LP[z]=preLP[indexUnifier[0][0][0][0]]+FirstTrLP(indexUnifier[0][0][0][0],z)+OutLP(z,dur);
						amax[n][z]=indexUnifier[0][0][0][0];
						for(int k=0;k<patterns.size();k+=1){
							if(indexUnifier[k][0][0][0]<0){continue;}
							logP=preLP[indexUnifier[k][0][0][0]]+FirstTrLP(indexUnifier[k][0][0][0],z)+OutLP(z,dur);
							if(logP>LP[z]){LP[z]=logP; amax[n][z]=indexUnifier[k][0][0][0];}
						}//endfor k
					}//endfor z
					continue;
				}//endif

				for(int z=0;z<nEffState;z+=1){
					LP[z]=preLP[0]+TrLP(0,z)+OutLP(z,dur);
					amax[n][z]=0;
				}//endfor z
				for(int zp=0;zp<nEffState;zp+=1){
					if(stateSalient[zp]==0){continue;}
					for(int z=0;z<nEffState;z+=1){
						trlp=TrLP(zp,z);
						if(trlp<-1E10){continue;}
						outlp=OutLP(z,dur);
						if(outlp<-1E10){continue;}
						logP=preLP[zp]+trlp+outlp;
						if(logP>LP[z]){LP[z]=logP; amax[n][z]=zp;}
					}//endfor z
				}//endfor zp

			}//endfor n

			/// ///Backtracking and set stimes
			optPath[optPath.size()-1]=0;
			for(int z=0;z<nEffState;z+=1){
				if(LP[z]>LP[optPath[optPath.size()-1]]){optPath[optPath.size()-1]=z;}//endif
			}//endfor i
			for(int n=optPath.size()-2;n>=0;n-=1){optPath[n]=amax[n+1][optPath[n+1]];}//endfor n
			for(int n=1;n<ontimes[l].size();n+=1){
				stimes[l][n]=stimes[l][n-1]+insPattern[insPatIndexSplitter[indexSplitter[optPath[n]][2]][0]][insPatIndexSplitter[indexSplitter[optPath[n]][2]][1]][indexSplitter[optPath[n]][3]];
			}//endfor n

			///Write piece-specific parameter file
			stringstream ss;
			ss.str(""); ss<<paramFolder<<"param_patMM1D_"<<l<<".txt";
			WriteFile(ss.str());

		}//endfor l
	}//end BayesTranscribe

};//endclass PatMM1D


#endif // PatternMarkovModelMod_HPP
