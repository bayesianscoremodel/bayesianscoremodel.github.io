#ifndef NoteMarkovModelMod_HPP
#define NoteMarkovModelMod_HPP

#include<iostream>
#include<iomanip>
#include<fstream>
#include<string>
#include<sstream>
#include<vector>
#include<stdio.h>
#include<stdlib.h>
#include<cfloat>
#include<cmath>
#include<cassert>
#include<algorithm>
#include<boost/math/distributions.hpp> 
#include<boost/random.hpp>
#include"NoteMarkovModel_v170803.hpp"

#define EPS (0.1)
//#define PRINTON_ true

using namespace std;

class NoteMM1DS : public NoteMarkovModel{
public:
	bool printOn; 

// 	int nBeat;//Beat resolution
// 	/// Identify nvID=0,...,nBeat-1 as nv=1,...,nBeat
// 	Prob<int> uniProb;
// 	Prob<int> iniProb;
// 	vector<Prob<int> > trProb;//(nBeat x nBeat)

	vector<vector<vector<int> > > insPattern;//[nvID][h][g]
	vector<Prob<int> > insProb;//insertion probability r -> h
	Prob<int> shiftProb;//shift probability (2*nBeat-1) [0]<->-(nBeat-1),[nBeat-1]<->0,[2*nBeat-2]<->nBeat-1
	vector<int> shiftVal;//(2*nBeat-1)

	vector<vector<double> > insDirParam;
	vector<double> shiftDirParam;

	vector<vector<int> > indexSplitter;//[][0,1,2,3]=nvID,h,g,s
	vector<vector<vector<vector<int> > > > indexUnifier;//[nvID][h][g][s]
	int nEffState;//indexSplitter.size()

	string paramFolder;

	NoteMM1DS(){
		printOn=false;
		paramFolder="./param/";
	}//end NoteMM1DS
	~NoteMM1DS(){
	}//end ~NoteMM1DS

	void Clear(){
		iniProb.Clear();
		iniDirParam.clear();
		trProb.clear();
		trDirParam.clear();
		insPattern.clear();
		insProb.clear();
		insDirParam.clear();
		shiftVal.clear();
		shiftProb.Clear();
		shiftDirParam.clear();
	}//end Clear

	void RandomInit(int nBeat_){
		Clear();
		nBeat=nBeat_;
		iniProb.Resize(nBeat);
		iniProb.Randomize();
		iniDirParam.assign(nBeat,1);
		trProb.resize(nBeat);
		trDirParam.resize(nBeat);
		for(int r=0;r<nBeat;r+=1){
			trProb[r].Resize(nBeat);
			trProb[r].Randomize();
			trDirParam[r].assign(nBeat,1);
		}//endfor r

		insPattern.resize(nBeat);
		insProb.resize(nBeat);
		insDirParam.resize(nBeat);
		vector<int> vi;
		for(int i=0;i<nBeat;i+=1){
			vi.clear();
			vi.push_back(i+1);
			insPattern[i].push_back(vi);
			for(int j=1;j<=i;j+=1){
				vi.clear();
				vi.push_back(j);
				vi.push_back(i+1-j);
				insPattern[i].push_back(vi);
			}//endfor j
			insProb[i].Resize(insPattern[i].size());
			insProb[i].Randomize();
			insDirParam[i].assign(insPattern[i].size(),1);
		}//endfor i

		shiftVal.clear();
		for(int val=-nBeat+1;val<=nBeat-1;val+=1){
			shiftVal.push_back(val);
		}//endfor val
		shiftProb.Resize(shiftVal.size());
		shiftProb.Randomize();
		shiftDirParam.assign(shiftVal.size(),1);

		indexSplitter.clear();
		indexUnifier.clear();
		bool goodIndex;
		vi.resize(4);
		indexUnifier.resize(nBeat);
		for(int i=0;i<nBeat;i+=1){
			indexUnifier[i].resize(insPattern[i].size());
			for(int h=0;h<insPattern[i].size();h+=1){
				indexUnifier[i][h].resize(insPattern[i][h].size());
				for(int g=0;g<insPattern[i][h].size();g+=1){
					indexUnifier[i][h][g].resize(shiftVal.size());
					for(int s=0;s<shiftVal.size();s+=1){
						goodIndex=true;
						//Impose -r_n < s_n <=r_n
						if(shiftVal[s]>i+1){goodIndex=false;}
						if(shiftVal[s]<-i){goodIndex=false;}
						if(goodIndex){
							indexUnifier[i][h][g][s]=indexSplitter.size();
							vi[0]=i; vi[1]=h; vi[2]=g; vi[3]=s;
							indexSplitter.push_back(vi);
						}else{
							indexUnifier[i][h][g][s]=-1;
						}//endif
					}//endfor s
				}//endfor g
			}//endfor h
		}//endfor i
		nEffState=indexSplitter.size();
if(printOn){cout<<nEffState<<endl;}
	}//end RandomInit

	void WriteFile(string filename){
		ofstream ofs(filename.c_str());
		ofs<<"//BeatResolution: "<<nBeat<<"\n";

		ofs<<"### Init Prob\n";
		for(int r=0;r<nBeat;r+=1){
ofs<<iniProb.P[r]<<"\t";
		}//endfor r
ofs<<"\n";

		ofs<<"### Transition Prob\n";
		for(int r=0;r<nBeat;r+=1){
			for(int rp=0;rp<nBeat;rp+=1){
ofs<<trProb[r].P[rp]<<"\t";
			}//endfor rp
ofs<<"\n";
		}//endfor r

		ofs<<"### Shift Prob\n";
		for(int i=0;i<shiftVal.size();i+=1){
ofs<<shiftVal[i]<<"\t"<<shiftProb.P[i]<<"\n";
		}//endfor i

		ofs<<"### Insertion Prob\n";
		for(int i=0;i<insPattern.size();i+=1){
			for(int h=0;h<insPattern[i].size();h+=1){
ofs<<i+1<<"\t"<<h<<"\t"<<insProb[i].P[h]<<"\t"<<insPattern[i][h].size()<<"\t";
				for(int g=0;g<insPattern[i][h].size();g+=1){
ofs<<insPattern[i][h][g]<<" ";
				}//endfor g
ofs<<"\n";
			}//endfor h
		}//endfor i

		ofs.close();
	}//end WriteFile

	void ReadFile(string filename){
		vector<int> v(100);
		vector<double> d(100);
		vector<string> s(100);
		stringstream ss;

		ifstream ifs(filename.c_str());
		ifs>>s[1]>>nBeat;
		getline(ifs,s[99]);

		RandomInit(nBeat);

		getline(ifs,s[99]);//### Init Prob
		for(int b=0;b<nBeat;b+=1){
			ifs>>iniProb.P[b];
		}//endfor b
		getline(ifs,s[99]);
		iniProb.Normalize();

		getline(ifs,s[99]);//### Transition Prob
		for(int b=0;b<nBeat;b+=1){
			for(int b_=0;b_<nBeat;b_+=1){
				ifs>>trProb[b].P[b_];
			}//endfor b_
			getline(ifs,s[99]);
			trProb[b].Normalize();
		}//endfor b

		getline(ifs,s[99]);//### Shift Prob
		for(int i=0;i<shiftVal.size();i+=1){
			ifs>>d[1]>>shiftProb.P[i];
			getline(ifs,s[99]);
		}//endfor i
		shiftProb.Normalize();

		getline(ifs,s[99]);//### Insertion Prob
		for(int i=0;i<insPattern.size();i+=1){
			for(int h=0;h<insPattern[i].size();h+=1){
				ifs>>d[1]>>d[2]>>insProb[i].P[h];
				getline(ifs,s[99]);
			}//endfor h
			insProb[i].Normalize();
		}//endfor i

		ifs.close();
	}//end ReadFile

	void SetParamFolder(string folder){
		paramFolder=folder+"/";
		stringstream ss;
		ss.str(""); ss<<"mkdir "<<paramFolder;
		system(ss.str().c_str());
	}//end 

	void ReadFileFromBasic(string filename){
		NoteMarkovModel basicModel;
		basicModel.ReadFile(filename);
		nBeat=basicModel.nBeat;
		RandomInit(nBeat);
		uniProb=basicModel.uniProb;
		iniProb=basicModel.iniProb;
		trProb=basicModel.trProb;
	}//end ReadFileFromBasic

	void SetSimpleModificationModel(double noShiftP=0.9,double noInsP=0.9){
		for(int s=0;s<shiftVal.size();s+=1){
			if(s==nBeat-1){
				shiftProb.P[s]=noShiftP;
			}else{
				shiftProb.P[s]=(1-noShiftP)/double(shiftVal.size()-1);
			}//endif
		}//endfor s
		shiftProb.Normalize();
		for(int i=0;i<nBeat;i+=1){
			insProb[i].P[0]=noInsP;
			for(int h=1;h<insPattern[i].size();h+=1){
				insProb[i].P[h]=(1-noInsP)/double(insPattern[i].size()-1);
			}//endfor h
			insProb[i].Normalize();
		}//endfor i
	}//end SetSimpleModificationModel

	void SetDirParam(double alpha_ini,double alpha_tr,double alpha_shift,double alpha_ins){
		for(int b=0;b<nBeat;b+=1){
			iniDirParam[b]=alpha_ini*iniProb.P[b];
			for(int bp=0;bp<nBeat;bp+=1){
				trDirParam[b][bp]=alpha_tr*trProb[b].P[bp];
			}//endfor bp
		}//endfor b
		for(int i=0;i<shiftVal.size();i+=1){
			shiftDirParam[i]=alpha_shift*shiftProb.P[i];
		}//endfor i
		for(int i=0;i<nBeat;i+=1){
			for(int h=0;h<insPattern[i].size();h+=1){
				insDirParam[i][h]=alpha_ins*insProb[i].P[h];
			}//endfor h
		}//endfor i
	}//end SetDirParam


	double OutLP(int ip,int i,double dur){
		int nv=insPattern[indexSplitter[i][0]][indexSplitter[i][1]][indexSplitter[i][2]]+shiftVal[indexSplitter[i][3]]-shiftVal[indexSplitter[ip][3]];
		if(nv>0){
			return -0.5*pow((dur-nv*secPerTick)/sig_t,2.);
		}else{
			return -DBL_MAX;
		}//endif
	}//end OutLP

	double TrLP(int ip,int i){
		if(indexSplitter[i][2]==0){
			if(indexSplitter[ip][2]==insPattern[indexSplitter[ip][0]][indexSplitter[ip][1]].size()-1){
				return trProb[indexSplitter[ip][0]].LP[indexSplitter[i][0]]+insProb[indexSplitter[i][0]].LP[indexSplitter[i][1]]+shiftProb.LP[indexSplitter[i][3]];
			}else{
				return -DBL_MAX;
			}//endif
		}else{//indexSplitter[i][2]>0
			if(indexSplitter[i][2]==indexSplitter[ip][2]+1
			   && indexSplitter[i][0]==indexSplitter[ip][0]
			   && indexSplitter[i][1]==indexSplitter[ip][1]){
				return shiftProb.LP[indexSplitter[i][3]];
			}else{
				return -DBL_MAX;
			}//endif
		}//endif
	}//end TrLP

	void Transcribe(){
		for(int l=0;l<ontimes.size();l+=1){
//cout<<"Transcribe -- "<<(l+1)<<"/"<<ontimes.size()<<endl;

			///Viterbi
			vector<int> optPath(ontimes[l].size());
			vector<double> LP(nEffState);
			vector<vector<int> > amax;
			amax.resize(ontimes[l].size());
			for(int n=0;n<ontimes[l].size();n+=1){amax[n].resize(nEffState);}

			/// ///Initialization
			//(n=0) r=nBeat-1, h=g=0, s is the only variable
			LP.assign(nEffState,-DBL_MAX);
			for(int s=0;s<shiftVal.size();s+=1){
				if(indexUnifier[nBeat-1][0][0][s]<0){continue;}
				LP[indexUnifier[nBeat-1][0][0][s]]=shiftProb.LP[s];
			}//endfor s

			/// ///Update
			double dur;
			double logP;
			for(int n=1;n<ontimes[l].size();n+=1){
				vector<double> preLP(LP);
				dur=ontimes[l][n]-ontimes[l][n-1];
				LP.assign(nEffState,-DBL_MAX);

				if(n==1){
					for(int i=0;i<nEffState;i+=1){
						if(indexSplitter[i][2]!=0){continue;}
						LP[i]=preLP[indexUnifier[nBeat-1][0][0][0]]
						      +iniProb.LP[indexSplitter[i][0]]+insProb[indexSplitter[i][0]].LP[indexSplitter[i][1]]+shiftProb.LP[indexSplitter[i][3]]
						      +OutLP(indexUnifier[nBeat-1][0][0][0],i,dur);
						amax[n][i]=indexUnifier[nBeat-1][0][0][0];
						for(int s=0;s<shiftVal.size();s+=1){
							if(indexUnifier[nBeat-1][0][0][s]<0){continue;}
							logP=preLP[indexUnifier[nBeat-1][0][0][s]]
							      +iniProb.LP[indexSplitter[i][0]]+insProb[indexSplitter[i][0]].LP[indexSplitter[i][1]]+shiftProb.LP[indexSplitter[i][3]]
							      +OutLP(indexUnifier[nBeat-1][0][0][s],i,dur);
							if(logP>LP[i]){LP[i]=logP; amax[n][i]=indexUnifier[nBeat-1][0][0][s];}
						}//endfor s
					}//endfor i
					continue;
				}//endif

				double trlp,outlp;
				for(int i=0;i<nEffState;i+=1){
					LP[i]=preLP[0]+TrLP(0,i)+OutLP(0,i,dur);
					amax[n][i]=0;
					for(int ip=0;ip<nEffState;ip+=1){
						outlp=OutLP(ip,i,dur);
						if(outlp<-1E10){continue;}
						trlp=TrLP(ip,i);
						if(trlp<-1E10){continue;}
						logP=preLP[ip]+trlp+outlp;
						if(logP>LP[i]){LP[i]=logP; amax[n][i]=ip;}
					}//endfor ip
				}//endfor i

			}//endfor n

			/// ///Backtracking and set stimes
			optPath[optPath.size()-1]=0;
			for(int i=0;i<nEffState;i+=1){
				if(LP[i]>LP[optPath[optPath.size()-1]]){optPath[optPath.size()-1]=i;}//endif
			}//endfor i
			for(int n=optPath.size()-2;n>=0;n-=1){optPath[n]=amax[n+1][optPath[n+1]];}//endfor n

			for(int n=1;n<ontimes[l].size();n+=1){
				stimes[l][n]=stimes[l][n-1]+insPattern[indexSplitter[optPath[n]][0]][indexSplitter[optPath[n]][1]][indexSplitter[optPath[n]][2]]+shiftVal[indexSplitter[optPath[n]][3]]-shiftVal[indexSplitter[optPath[n-1]][3]];
			}//endfor n
		}//endfor l
	}//end Transcribe


	void BayesTranscribe(int nIter=10, int seed=2){
		/// Should be used after setting Dirichlet parameters
		boost::mt19937 gen;
		gen.seed(seed);
		Prob<int> genIniProb(iniProb);
		vector<Prob<int> > genTrProb(trProb);//(nBeat x nBeat)
		vector<Prob<int> > genInsProb(insProb);//insertion probability r -> h
		Prob<int> genShiftProb(shiftProb);//shift probability (2*nBeat-1) [0]<->-(nBeat-1),[nBeat-1]<->0,[2*nBeat-2]<->nBeat-1

		for(int l=0;l<ontimes.size();l+=1){
if(printOn){cout<<"BayesTranscribe -- "<<(l+1)<<"/"<<ontimes.size()<<endl;}

			iniProb=genIniProb;
			trProb=genTrProb;
			insProb=genInsProb;
			shiftProb=genShiftProb;
			Prob<int> maxIniProb(iniProb);
			vector<Prob<int> > maxTrProb(trProb);//(nBeat x nBeat)
			vector<Prob<int> > maxInsProb(insProb);//insertion probability r -> h
			Prob<int> maxShiftProb(shiftProb);//shift probability (2*nBeat-1) [0]<->-(nBeat-1),[nBeat-1]<->0,[2*nBeat-2]<->nBeat-1
			double evidLP;
			double maxEvidLP;
			int maxIter;
			double dur;

			///Gibbs sampling
			for(int iter=0;iter<nIter;iter+=1){

				///Sample scores by forward-filtering backward sampling
				vector<int> sampledStates(ontimes[l].size());
				vector<vector<double> > forwardVar;// ontimes[l].size() x nEffState
				forwardVar.resize(ontimes[l].size());
				for(int n=0;n<ontimes[l].size();n+=1){forwardVar[n].assign(nEffState,-DBL_MAX);}

				/// //Forward
				//(n=0) r=nBeat-1, h=g=0, s is the only variable
				for(int s=0;s<shiftVal.size();s+=1){
					if(indexUnifier[nBeat-1][0][0][s]<0){continue;}
					forwardVar[0][indexUnifier[nBeat-1][0][0][s]]=shiftProb.LP[s];
				}//endfor s

				for(int n=1;n<ontimes[l].size();n+=1){
					dur=ontimes[l][n]-ontimes[l][n-1];

					if(n==1){
						for(int i=0;i<nEffState;i+=1){
							if(indexSplitter[i][2]!=0){continue;}
							for(int s=0;s<shiftVal.size();s+=1){
								if(indexUnifier[nBeat-1][0][0][s]<0){continue;}
								forwardVar[n][i]=LogAdd(forwardVar[n][i],
									forwardVar[n-1][indexUnifier[nBeat-1][0][0][s]]
									+iniProb.LP[indexSplitter[i][0]]+insProb[indexSplitter[i][0]].LP[indexSplitter[i][1]]+shiftProb.LP[indexSplitter[i][3]]
									+OutLP(indexUnifier[nBeat-1][0][0][s],i,dur)
								);
							}//endfor s
						}//endfor i
						continue;
					}//endif

					double trlp,outlp;
					for(int i=0;i<nEffState;i+=1){
						for(int ip=0;ip<nEffState;ip+=1){
							outlp=OutLP(ip,i,dur);
							if(outlp<-1E10){continue;}
							trlp=TrLP(ip,i);
							if(trlp<-1E10){continue;}
							forwardVar[n][i]=LogAdd(forwardVar[n][i],forwardVar[n-1][ip]+trlp+outlp);
						}//endfor ip
					}//endfor i

				}//endfor n

				evidLP=-DBL_MAX;
				for(int i=0;i<nEffState;i+=1){
					evidLP=LogAdd(evidLP,forwardVar[ontimes[l].size()-1][i]);
				}//endfor i

				if(iter==0 || evidLP>maxEvidLP){
					maxEvidLP=evidLP;
					maxIniProb=iniProb;
					maxTrProb=trProb;
					maxInsProb=insProb;
					maxShiftProb=shiftProb;
					maxIter=iter;
				}//endif
if(printOn){cout<<"Iteration: "<<iter<<"\t-NORM(evidLP,maxEvidLP): "<<-evidLP/double(ontimes[l].size())<<"\t"<<-maxEvidLP/double(ontimes[l].size())<<"\t"<<((evidLP==maxEvidLP)? "******":"")<<endl;}

				/// //Backward sampling
				Prob<int> prob;
				prob.LP=forwardVar[ontimes[l].size()-1];
				prob.LogNormalize();
				sampledStates[ontimes[l].size()-1]=SampleDistr(prob.P);

				for(int n=ontimes[l].size()-2;n>=1;n-=1){
					for(int i=0;i<nEffState;i+=1){
						prob.LP[i]=forwardVar[n][i]+TrLP(i,sampledStates[n+1])+OutLP(i,sampledStates[n+1],ontimes[l][n+1]-ontimes[l][n]);
					}//endfor i
					prob.LogNormalize();
					sampledStates[n]=SampleDistr(prob.P);
				}//endfor n

				prob.LP.assign(nEffState,-DBL_MAX);
				for(int s=0;s<shiftVal.size();s+=1){
					if(indexUnifier[nBeat-1][0][0][s]<0){continue;}
					prob.LP[indexUnifier[nBeat-1][0][0][s]]=forwardVar[0][indexUnifier[nBeat-1][0][0][s]]+TrLP(indexUnifier[nBeat-1][0][0][s],sampledStates[1])+OutLP(indexUnifier[nBeat-1][0][0][s],sampledStates[1],ontimes[l][1]-ontimes[l][0]);
				}//endfor s
				prob.LogNormalize();
				sampledStates[0]=SampleDistr(prob.P);


				///Sample parameters
				iniProb.P=iniDirParam;
				iniProb.P[indexSplitter[sampledStates[1]][0]]+=1;
				for(int r=0;r<nBeat;r+=1){
					boost::gamma_distribution<> dst( iniProb.P[r], 1. );
					boost::variate_generator<boost::mt19937&, boost::gamma_distribution<> > gamma_rand( gen, dst );
					iniProb.P[r]=gamma_rand();
				}//endfor r
				iniProb.Normalize();

				for(int r=0;r<nBeat;r+=1){
					trProb[r].P=trDirParam[r];
				}//endfor r
				for(int n=2;n<ontimes[l].size();n+=1){
					if(indexSplitter[sampledStates[n]][2]!=0){continue;}
					trProb[indexSplitter[sampledStates[n-1]][0]].P[indexSplitter[sampledStates[n]][0]]+=1;
				}//endfor n
				for(int r=0;r<nBeat;r+=1){
					for(int rp=0;rp<nBeat;rp+=1){
						boost::gamma_distribution<> dst( trProb[r].P[rp], 1. );
						boost::variate_generator<boost::mt19937&, boost::gamma_distribution<> > gamma_rand( gen, dst );
						trProb[r].P[rp]=gamma_rand();
					}//endfor rp
					trProb[r].Normalize();
				}//endfor r

				for(int r=0;r<nBeat;r+=1){
					insProb[r].P=insDirParam[r];
				}//endfor r
				for(int n=1;n<ontimes[l].size();n+=1){
					if(indexSplitter[sampledStates[n]][2]!=0){continue;}
					insProb[indexSplitter[sampledStates[n]][0]].P[indexSplitter[sampledStates[n]][1]]+=1;
				}//endfor n
				for(int r=0;r<nBeat;r+=1){
					for(int h=0;h<insDirParam[r].size();h+=1){
						boost::gamma_distribution<> dst( insProb[r].P[h], 1. );
						boost::variate_generator<boost::mt19937&, boost::gamma_distribution<> > gamma_rand( gen, dst );
						insProb[r].P[h]=gamma_rand();
					}//endfor h
					insProb[r].Normalize();
				}//endfor r

				shiftProb.P=shiftDirParam;
				for(int n=0;n<ontimes[l].size();n+=1){
					shiftProb.P[indexSplitter[sampledStates[n]][3]]+=1;
				}//endfor n
				for(int s=0;s<shiftVal.size();s+=1){
					boost::gamma_distribution<> dst( shiftProb.P[s], 1. );
					boost::variate_generator<boost::mt19937&, boost::gamma_distribution<> > gamma_rand( gen, dst );
					shiftProb.P[s]=gamma_rand();
				}//endfor s
				shiftProb.Normalize();

			}//endfor iter


			///Set optimal parameter
			iniProb=maxIniProb;
			trProb=maxTrProb;
			insProb=maxInsProb;
			shiftProb=maxShiftProb;

			///Viterbi
			vector<int> optPath(ontimes[l].size());
			vector<double> LP(nEffState);
			vector<vector<int> > amax;
			amax.resize(ontimes[l].size());
			for(int n=0;n<ontimes[l].size();n+=1){amax[n].resize(nEffState);}

			/// ///Initialization
			//(n=0) r=h=g=0, s is the only variable
			LP.assign(nEffState,-DBL_MAX);
			for(int s=0;s<shiftVal.size();s+=1){
				if(indexUnifier[nBeat-1][0][0][s]<0){continue;}
				LP[indexUnifier[nBeat-1][0][0][s]]=shiftProb.LP[s];
			}//endfor s

			/// ///Update
			double logP;
			for(int n=1;n<ontimes[l].size();n+=1){
				vector<double> preLP(LP);
				dur=ontimes[l][n]-ontimes[l][n-1];
				LP.assign(nEffState,-DBL_MAX);

				if(n==1){
					for(int i=0;i<nEffState;i+=1){
						if(indexSplitter[i][2]!=0){continue;}
						LP[i]=preLP[indexUnifier[nBeat-1][0][0][0]]
						      +iniProb.LP[indexSplitter[i][0]]+insProb[indexSplitter[i][0]].LP[indexSplitter[i][1]]+shiftProb.LP[indexSplitter[i][3]]
						      +OutLP(indexUnifier[nBeat-1][0][0][0],i,dur);
						amax[n][i]=indexUnifier[nBeat-1][0][0][0];
						for(int s=0;s<shiftVal.size();s+=1){
							if(indexUnifier[nBeat-1][0][0][s]<0){continue;}
							logP=preLP[indexUnifier[nBeat-1][0][0][s]]
							      +iniProb.LP[indexSplitter[i][0]]+insProb[indexSplitter[i][0]].LP[indexSplitter[i][1]]+shiftProb.LP[indexSplitter[i][3]]
							      +OutLP(indexUnifier[nBeat-1][0][0][s],i,dur);
							if(logP>LP[i]){LP[i]=logP; amax[n][i]=indexUnifier[nBeat-1][0][0][s];}
						}//endfor s
					}//endfor i
					continue;
				}//endif

				double trlp,outlp;
				for(int i=0;i<nEffState;i+=1){
					LP[i]=preLP[0]+TrLP(0,i)+OutLP(0,i,dur);
					amax[n][i]=0;
					for(int ip=0;ip<nEffState;ip+=1){
						outlp=OutLP(ip,i,dur);
						if(outlp<-1E10){continue;}
						trlp=TrLP(ip,i);
						if(trlp<-1E10){continue;}
						logP=preLP[ip]+trlp+outlp;
						if(logP>LP[i]){LP[i]=logP; amax[n][i]=ip;}
					}//endfor ip
				}//endfor i
			}//endfor n

			/// ///Backtracking and set stimes
			optPath[optPath.size()-1]=0;
			for(int i=0;i<nEffState;i+=1){
				if(LP[i]>LP[optPath[optPath.size()-1]]){optPath[optPath.size()-1]=i;}//endif
			}//endfor i
			for(int n=optPath.size()-2;n>=0;n-=1){optPath[n]=amax[n+1][optPath[n+1]];}//endfor n

			for(int n=1;n<ontimes[l].size();n+=1){
				stimes[l][n]=stimes[l][n-1]+insPattern[indexSplitter[optPath[n]][0]][indexSplitter[optPath[n]][1]][indexSplitter[optPath[n]][2]]+shiftVal[indexSplitter[optPath[n]][3]]-shiftVal[indexSplitter[optPath[n-1]][3]];
			}//endfor n

			///Write piece-specific parameter file
			stringstream ss;
			ss.str(""); ss<<paramFolder<<"param_noteMM1DS_"<<l<<".txt";
			WriteFile(ss.str());

		}//endfor l
	}//end BayesTranscribe

};//endclass NoteMM1DS


class NoteMM1S : public NoteMM1DS{
public:
	vector<vector<int> > indexSplitter;//[][0,1]=nvID,s
	vector<vector<int> > indexUnifier;//[nvID][s]
	int nEffState;//indexSplitter.size()

	NoteMM1S(){
		printOn=false;
	}//end NoteMM1S
	~NoteMM1S(){
	}//end ~NoteMM1S

	void Clear(){
		iniProb.Clear();
		iniDirParam.clear();
		trProb.clear();
		trDirParam.clear();
		shiftVal.clear();
		shiftProb.Clear();
		shiftDirParam.clear();
	}//end Clear

	void RandomInit(int nBeat_){
		Clear();
		nBeat=nBeat_;
		iniProb.Resize(nBeat);
		iniProb.Randomize();
		iniDirParam.assign(nBeat,1);
		trProb.resize(nBeat);
		trDirParam.resize(nBeat);
		for(int r=0;r<nBeat;r+=1){
			trProb[r].Resize(nBeat);
			trProb[r].Randomize();
			trDirParam[r].assign(nBeat,1);
		}//endfor r

		shiftVal.clear();
		for(int val=-nBeat+1;val<=nBeat-1;val+=1){
			shiftVal.push_back(val);
		}//endfor val
		shiftProb.Resize(shiftVal.size());
		shiftProb.Randomize();
		shiftDirParam.assign(shiftVal.size(),1);

		indexSplitter.clear();
		indexUnifier.clear();
		vector<int> vi(2);
		indexUnifier.resize(nBeat);
		for(int r=0;r<nBeat;r+=1){
			indexUnifier[r].resize(shiftVal.size());
			for(int s=0;s<shiftVal.size();s+=1){
				indexUnifier[r][s]=indexSplitter.size();
				vi[0]=r; vi[1]=s;
				indexSplitter.push_back(vi);
			}//endfor s
		}//endfor r
		nEffState=indexSplitter.size();
//cout<<nEffState<<endl;
	}//end RandomInit

	void WriteFile(string filename){
		ofstream ofs(filename.c_str());
		ofs<<"//BeatResolution: "<<nBeat<<"\n";

		ofs<<"### Init Prob\n";
		for(int r=0;r<nBeat;r+=1){
ofs<<iniProb.P[r]<<"\t";
		}//endfor r
ofs<<"\n";

		ofs<<"### Transition Prob\n";
		for(int r=0;r<nBeat;r+=1){
			for(int rp=0;rp<nBeat;rp+=1){
ofs<<trProb[r].P[rp]<<"\t";
			}//endfor rp
ofs<<"\n";
		}//endfor r

		ofs<<"### Shift Prob\n";
		for(int i=0;i<shiftVal.size();i+=1){
ofs<<shiftVal[i]<<"\t"<<shiftProb.P[i]<<"\n";
		}//endfor i

		ofs.close();
	}//end WriteFile

	void ReadFile(string filename){
		vector<int> v(100);
		vector<double> d(100);
		vector<string> s(100);
		stringstream ss;

		ifstream ifs(filename.c_str());
		ifs>>s[1]>>nBeat;
		getline(ifs,s[99]);

		RandomInit(nBeat);

		getline(ifs,s[99]);//### Init Prob
		for(int b=0;b<nBeat;b+=1){
			ifs>>iniProb.P[b];
		}//endfor b
		getline(ifs,s[99]);
		iniProb.Normalize();

		getline(ifs,s[99]);//### Transition Prob
		for(int b=0;b<nBeat;b+=1){
			for(int b_=0;b_<nBeat;b_+=1){
				ifs>>trProb[b].P[b_];
			}//endfor b_
			getline(ifs,s[99]);
			trProb[b].Normalize();
		}//endfor b

		getline(ifs,s[99]);//### Shift Prob
		for(int i=0;i<shiftVal.size();i+=1){
			ifs>>d[1]>>shiftProb.P[i];
			getline(ifs,s[99]);
		}//endfor i
		shiftProb.Normalize();

		ifs.close();
	}//end ReadFile

	void ReadFileFromBasic(string filename){
		NoteMarkovModel basicModel;
		basicModel.ReadFile(filename);
		nBeat=basicModel.nBeat;
		RandomInit(nBeat);
		uniProb=basicModel.uniProb;
		iniProb=basicModel.iniProb;
		trProb=basicModel.trProb;
	}//end ReadFileFromBasic

	void SetSimpleModificationModel(double noShiftP=0.9){
		for(int s=0;s<shiftVal.size();s+=1){
			if(s==nBeat-1){
				shiftProb.P[s]=noShiftP;
			}else{
				shiftProb.P[s]=(1-noShiftP)/double(shiftVal.size()-1);
			}//endif
		}//endfor s
		shiftProb.Normalize();
	}//end SetSimpleModificationModel

	void SetDirParam(double alpha_ini,double alpha_tr,double alpha_shift){
		for(int b=0;b<nBeat;b+=1){
			iniDirParam[b]=alpha_ini*iniProb.P[b];
			for(int bp=0;bp<nBeat;bp+=1){
				trDirParam[b][bp]=alpha_tr*trProb[b].P[bp];
			}//endfor bp
		}//endfor b
		for(int i=0;i<shiftVal.size();i+=1){
			shiftDirParam[i]=alpha_shift*shiftProb.P[i];
		}//endfor i
	}//end SetDirParam

	double OutLP(int ip,int i,double dur){
		int nv=indexSplitter[i][0]+1+shiftVal[indexSplitter[i][1]]-shiftVal[indexSplitter[ip][1]];
		if(nv>0){
			return -0.5*pow((dur-nv*secPerTick)/sig_t,2.);
		}else{
			return -DBL_MAX;
		}//endif
	}//end OutLP

	double TrLP(int ip,int i){
		return trProb[indexSplitter[ip][0]].LP[indexSplitter[i][0]]+shiftProb.LP[indexSplitter[i][1]];
	}//end TrLP

	void Transcribe(){
		for(int l=0;l<ontimes.size();l+=1){
// cout<<"Transcribe -- "<<(l+1)<<"/"<<ontimes.size()<<endl;

			///Viterbi
			vector<int> optPath(ontimes[l].size());
			vector<double> LP(nEffState);
			vector<vector<int> > amax;
			amax.resize(ontimes[l].size());
			for(int n=0;n<ontimes[l].size();n+=1){amax[n].resize(nEffState);}

			/// ///Initialization
			//(n=0) r=0, s is the only variable
			LP.assign(nEffState,-DBL_MAX);
			for(int s=0;s<shiftVal.size();s+=1){
				LP[indexUnifier[0][s]]=shiftProb.LP[s];
			}//endfor s

			/// ///Update
			double dur;
			double logP;
			for(int n=1;n<ontimes[l].size();n+=1){
				vector<double> preLP(LP);
				dur=ontimes[l][n]-ontimes[l][n-1];
				LP.assign(nEffState,-DBL_MAX);

				if(n==1){
					for(int i=0;i<nEffState;i+=1){
						LP[i]=preLP[indexUnifier[0][0]]
						      +iniProb.LP[indexSplitter[i][0]]+shiftProb.LP[indexSplitter[i][1]]
						      +OutLP(indexUnifier[0][0],i,dur);
						amax[n][i]=indexUnifier[0][0];
						for(int s=0;s<shiftVal.size();s+=1){
							logP=preLP[indexUnifier[0][s]]
							      +iniProb.LP[indexSplitter[i][0]]+shiftProb.LP[indexSplitter[i][1]]
							      +OutLP(indexUnifier[0][s],i,dur);
							if(logP>LP[i]){LP[i]=logP; amax[n][i]=indexUnifier[0][s];}
						}//endfor s
					}//endfor i
					continue;
				}//endif

				for(int i=0;i<nEffState;i+=1){
					LP[i]=preLP[0]+TrLP(0,i)+OutLP(0,i,dur);
					amax[n][i]=0;
					for(int ip=0;ip<nEffState;ip+=1){
						logP=preLP[ip]+TrLP(ip,i)+OutLP(ip,i,dur);
						if(logP>LP[i]){LP[i]=logP; amax[n][i]=ip;}
					}//endfor ip
				}//endfor i

			}//endfor n

			/// ///Backtracking and set stimes
			optPath[optPath.size()-1]=0;
			for(int i=0;i<nEffState;i+=1){
				if(LP[i]>LP[optPath[optPath.size()-1]]){optPath[optPath.size()-1]=i;}//endif
			}//endfor i
			for(int n=optPath.size()-2;n>=0;n-=1){optPath[n]=amax[n+1][optPath[n+1]];}//endfor n

			for(int n=1;n<ontimes[l].size();n+=1){
				stimes[l][n]=stimes[l][n-1]+indexSplitter[optPath[n]][0]+1+shiftVal[indexSplitter[optPath[n]][1]]-shiftVal[indexSplitter[optPath[n-1]][1]];
			}//endfor n
		}//endfor l
	}//end Transcribe


	void BayesTranscribe(int nIter=10, int seed=2){
		/// Should be used after setting Dirichlet parameters
		boost::mt19937 gen;
		gen.seed(seed);
		Prob<int> genIniProb(iniProb);
		vector<Prob<int> > genTrProb(trProb);//(nBeat x nBeat)
		Prob<int> genShiftProb(shiftProb);//shift probability (2*nBeat-1) [0]<->-(nBeat-1),[nBeat-1]<->0,[2*nBeat-2]<->nBeat-1

		for(int l=0;l<ontimes.size();l+=1){
if(printOn){cout<<"BayesTranscribe -- "<<(l+1)<<"/"<<ontimes.size()<<endl;}

			iniProb=genIniProb;
			trProb=genTrProb;
			shiftProb=genShiftProb;
			Prob<int> maxIniProb(iniProb);
			vector<Prob<int> > maxTrProb(trProb);//(nBeat x nBeat)
			Prob<int> maxShiftProb(shiftProb);//shift probability (2*nBeat-1) [0]<->-(nBeat-1),[nBeat-1]<->0,[2*nBeat-2]<->nBeat-1
			double evidLP;
			double maxEvidLP;
			int maxIter;
			double dur;

			///Gibbs sampling
			for(int iter=0;iter<nIter;iter+=1){

				///Sample scores by forward-filtering backward sampling
				vector<int> sampledStates(ontimes[l].size());
				vector<vector<double> > forwardVar;// ontimes[l].size() x nEffState
				forwardVar.resize(ontimes[l].size());
				for(int n=0;n<ontimes[l].size();n+=1){forwardVar[n].assign(nEffState,-DBL_MAX);}

				/// //Forward
				//(n=0) r=h=g=0, s is the only variable
				for(int s=0;s<shiftVal.size();s+=1){
					forwardVar[0][indexUnifier[0][s]]=shiftProb.LP[s];
				}//endfor s

				for(int n=1;n<ontimes[l].size();n+=1){
					dur=ontimes[l][n]-ontimes[l][n-1];

					if(n==1){
						for(int i=0;i<nEffState;i+=1){
							for(int s=0;s<shiftVal.size();s+=1){
								forwardVar[n][i]=LogAdd(forwardVar[n][i],
									forwardVar[n-1][indexUnifier[0][s]]
									+iniProb.LP[indexSplitter[i][0]]+shiftProb.LP[indexSplitter[i][1]]
									+OutLP(indexUnifier[0][s],i,dur)
								);
							}//endfor s
						}//endfor i
						continue;
					}//endif

					for(int i=0;i<nEffState;i+=1){
						for(int ip=0;ip<nEffState;ip+=1){
							forwardVar[n][i]=LogAdd(forwardVar[n][i],forwardVar[n-1][ip]+TrLP(ip,i)+OutLP(ip,i,dur));
						}//endfor ip
					}//endfor i

				}//endfor n

				evidLP=-DBL_MAX;
				for(int i=0;i<nEffState;i+=1){
					evidLP=LogAdd(evidLP,forwardVar[ontimes[l].size()-1][i]);
				}//endfor i

				if(iter==0 || evidLP>maxEvidLP){
					maxEvidLP=evidLP;
					maxIniProb=iniProb;
					maxTrProb=trProb;
					maxShiftProb=shiftProb;
					maxIter=iter;
				}//endif
if(printOn){cout<<"Iteration: "<<iter<<"\t-NORM(evidLP,maxEvidLP): "<<-evidLP/double(ontimes[l].size())<<"\t"<<-maxEvidLP/double(ontimes[l].size())<<"\t"<<((evidLP==maxEvidLP)? "******":"")<<endl;}

				/// //Backward sampling
				Prob<int> prob;
				prob.LP=forwardVar[ontimes[l].size()-1];
				prob.LogNormalize();
				sampledStates[ontimes[l].size()-1]=SampleDistr(prob.P);

				for(int n=ontimes[l].size()-2;n>=1;n-=1){
					for(int i=0;i<nEffState;i+=1){
						prob.LP[i]=forwardVar[n][i]+TrLP(i,sampledStates[n+1])+OutLP(i,sampledStates[n+1],ontimes[l][n+1]-ontimes[l][n]);
					}//endfor i
					prob.LogNormalize();
					sampledStates[n]=SampleDistr(prob.P);
				}//endfor n

				prob.LP.assign(nEffState,-DBL_MAX);
				for(int s=0;s<shiftVal.size();s+=1){
					prob.LP[indexUnifier[0][s]]=forwardVar[0][indexUnifier[0][s]]+TrLP(indexUnifier[0][s],sampledStates[1])+OutLP(indexUnifier[0][s],sampledStates[1],ontimes[l][1]-ontimes[l][0]);
				}//endfor s
				prob.LogNormalize();
				sampledStates[0]=SampleDistr(prob.P);


				///Sample parameters
				iniProb.P=iniDirParam;
				iniProb.P[indexSplitter[sampledStates[1]][0]]+=1;
				for(int r=0;r<nBeat;r+=1){
					boost::gamma_distribution<> dst( iniProb.P[r], 1. );
					boost::variate_generator<boost::mt19937&, boost::gamma_distribution<> > gamma_rand( gen, dst );
					iniProb.P[r]=gamma_rand();
				}//endfor r
				iniProb.Normalize();

				for(int r=0;r<nBeat;r+=1){
					trProb[r].P=trDirParam[r];
				}//endfor r
				for(int n=2;n<ontimes[l].size();n+=1){
					trProb[indexSplitter[sampledStates[n-1]][0]].P[indexSplitter[sampledStates[n]][0]]+=1;
				}//endfor n
				for(int r=0;r<nBeat;r+=1){
					for(int rp=0;rp<nBeat;rp+=1){
						boost::gamma_distribution<> dst( trProb[r].P[rp], 1. );
						boost::variate_generator<boost::mt19937&, boost::gamma_distribution<> > gamma_rand( gen, dst );
						trProb[r].P[rp]=gamma_rand();
					}//endfor rp
					trProb[r].Normalize();
				}//endfor r

				shiftProb.P=shiftDirParam;
				for(int n=0;n<ontimes[l].size();n+=1){
					shiftProb.P[indexSplitter[sampledStates[n]][1]]+=1;
				}//endfor n
				for(int s=0;s<shiftVal.size();s+=1){
					boost::gamma_distribution<> dst( shiftProb.P[s], 1. );
					boost::variate_generator<boost::mt19937&, boost::gamma_distribution<> > gamma_rand( gen, dst );
					shiftProb.P[s]=gamma_rand();
				}//endfor s
				shiftProb.Normalize();

			}//endfor iter


			///Set optimal parameter
			iniProb=maxIniProb;
			trProb=maxTrProb;
			shiftProb=maxShiftProb;

			///Viterbi
			vector<int> optPath(ontimes[l].size());
			vector<double> LP(nEffState);
			vector<vector<int> > amax;
			amax.resize(ontimes[l].size());
			for(int n=0;n<ontimes[l].size();n+=1){amax[n].resize(nEffState);}

			/// ///Initialization
			//(n=0) r=0, s is the only variable
			LP.assign(nEffState,-DBL_MAX);
			for(int s=0;s<shiftVal.size();s+=1){
				LP[indexUnifier[0][s]]=shiftProb.LP[s];
			}//endfor s

			/// ///Update
			double logP;
			for(int n=1;n<ontimes[l].size();n+=1){
				vector<double> preLP(LP);
				dur=ontimes[l][n]-ontimes[l][n-1];
				LP.assign(nEffState,-DBL_MAX);

				if(n==1){
					for(int i=0;i<nEffState;i+=1){
						LP[i]=preLP[indexUnifier[0][0]]
						      +iniProb.LP[indexSplitter[i][0]]+shiftProb.LP[indexSplitter[i][1]]
						      +OutLP(indexUnifier[0][0],i,dur);
						amax[n][i]=indexUnifier[0][0];
						for(int s=0;s<shiftVal.size();s+=1){
							logP=preLP[indexUnifier[0][s]]
							      +iniProb.LP[indexSplitter[i][0]]+shiftProb.LP[indexSplitter[i][1]]
							      +OutLP(indexUnifier[0][s],i,dur);
							if(logP>LP[i]){LP[i]=logP; amax[n][i]=indexUnifier[0][s];}
						}//endfor s
					}//endfor i
					continue;
				}//endif

				for(int i=0;i<nEffState;i+=1){
					LP[i]=preLP[0]+TrLP(0,i)+OutLP(0,i,dur);
					amax[n][i]=0;
					for(int ip=0;ip<nEffState;ip+=1){
						logP=preLP[ip]+TrLP(ip,i)+OutLP(ip,i,dur);
						if(logP>LP[i]){LP[i]=logP; amax[n][i]=ip;}
					}//endfor ip
				}//endfor i
			}//endfor n

			/// ///Backtracking and set stimes
			optPath[optPath.size()-1]=0;
			for(int i=0;i<nEffState;i+=1){
				if(LP[i]>LP[optPath[optPath.size()-1]]){optPath[optPath.size()-1]=i;}//endif
			}//endfor i
			for(int n=optPath.size()-2;n>=0;n-=1){optPath[n]=amax[n+1][optPath[n+1]];}//endfor n

			for(int n=1;n<ontimes[l].size();n+=1){
				stimes[l][n]=stimes[l][n-1]+indexSplitter[optPath[n]][0]+1+shiftVal[indexSplitter[optPath[n]][1]]-shiftVal[indexSplitter[optPath[n-1]][1]];
			}//endfor n

			///Write piece-specific parameter file
			stringstream ss;
			ss.str(""); ss<<paramFolder<<"param_noteMM1S_"<<l<<".txt";
			WriteFile(ss.str());

		}//endfor l
	}//end BayesTranscribe

};//endclass NoteMM1S


class NoteMM1D : public NoteMM1DS{
public:
	vector<vector<int> > indexSplitter;//[][0,1,2]=nvID,h,g
	vector<vector<vector<int> > > indexUnifier;//[nvID][h][g]
	int nEffState;//indexSplitter.size()

	NoteMM1D(){
		printOn=false;
	}//end NoteMM1D
	~NoteMM1D(){
	}//end ~NoteMM1D

	void Clear(){
		iniProb.Clear();
		iniDirParam.clear();
		trProb.clear();
		trDirParam.clear();
		insPattern.clear();
		insProb.clear();
		insDirParam.clear();
	}//end Clear

	void RandomInit(int nBeat_){
		Clear();
		nBeat=nBeat_;
		iniProb.Resize(nBeat);
		iniProb.Randomize();
		iniDirParam.assign(nBeat,1);
		trProb.resize(nBeat);
		trDirParam.resize(nBeat);
		for(int r=0;r<nBeat;r+=1){
			trProb[r].Resize(nBeat);
			trProb[r].Randomize();
			trDirParam[r].assign(nBeat,1);
		}//endfor r

		insPattern.resize(nBeat);
		insProb.resize(nBeat);
		insDirParam.resize(nBeat);
		vector<int> vi;
		for(int i=0;i<nBeat;i+=1){
			vi.clear();
			vi.push_back(i+1);
			insPattern[i].push_back(vi);
			for(int j=1;j<=i;j+=1){
				vi.clear();
				vi.push_back(j);
				vi.push_back(i+1-j);
				insPattern[i].push_back(vi);
			}//endfor j
			insProb[i].Resize(insPattern[i].size());
			insProb[i].Randomize();
			insDirParam[i].assign(insPattern[i].size(),1);
		}//endfor i

		indexSplitter.clear();
		indexUnifier.clear();
		vi.resize(3);
		indexUnifier.resize(nBeat);
		for(int i=0;i<nBeat;i+=1){
			indexUnifier[i].resize(insPattern[i].size());
			for(int h=0;h<insPattern[i].size();h+=1){
				indexUnifier[i][h].resize(insPattern[i][h].size());
				for(int g=0;g<insPattern[i][h].size();g+=1){
					indexUnifier[i][h][g]=indexSplitter.size();
					vi[0]=i; vi[1]=h; vi[2]=g;
					indexSplitter.push_back(vi);
				}//endfor g
			}//endfor h
		}//endfor i
		nEffState=indexSplitter.size();
//cout<<nEffState<<endl;
	}//end RandomInit

	void WriteFile(string filename){
		ofstream ofs(filename.c_str());
		ofs<<"//BeatResolution: "<<nBeat<<"\n";

		ofs<<"### Init Prob\n";
		for(int r=0;r<nBeat;r+=1){
ofs<<iniProb.P[r]<<"\t";
		}//endfor r
ofs<<"\n";

		ofs<<"### Transition Prob\n";
		for(int r=0;r<nBeat;r+=1){
			for(int rp=0;rp<nBeat;rp+=1){
ofs<<trProb[r].P[rp]<<"\t";
			}//endfor rp
ofs<<"\n";
		}//endfor r

		ofs<<"### Insertion Prob\n";
		for(int i=0;i<insPattern.size();i+=1){
			for(int h=0;h<insPattern[i].size();h+=1){
ofs<<i+1<<"\t"<<h<<"\t"<<insProb[i].P[h]<<"\t"<<insPattern[i][h].size()<<"\t";
				for(int g=0;g<insPattern[i][h].size();g+=1){
ofs<<insPattern[i][h][g]<<" ";
				}//endfor g
ofs<<"\n";
			}//endfor h
		}//endfor i

		ofs.close();
	}//end WriteFile

	void ReadFile(string filename){
		vector<int> v(100);
		vector<double> d(100);
		vector<string> s(100);
		stringstream ss;

		ifstream ifs(filename.c_str());
		ifs>>s[1]>>nBeat;
		getline(ifs,s[99]);

		RandomInit(nBeat);

		getline(ifs,s[99]);//### Init Prob
		for(int b=0;b<nBeat;b+=1){
			ifs>>iniProb.P[b];
		}//endfor b
		getline(ifs,s[99]);
		iniProb.Normalize();

		getline(ifs,s[99]);//### Transition Prob
		for(int b=0;b<nBeat;b+=1){
			for(int b_=0;b_<nBeat;b_+=1){
				ifs>>trProb[b].P[b_];
			}//endfor b_
			getline(ifs,s[99]);
			trProb[b].Normalize();
		}//endfor b

		getline(ifs,s[99]);//### Insertion Prob
		for(int i=0;i<insPattern.size();i+=1){
			for(int h=0;h<insPattern[i].size();h+=1){
				ifs>>d[1]>>d[2]>>insProb[i].P[h];
				getline(ifs,s[99]);
			}//endfor h
			insProb[i].Normalize();
		}//endfor i

		ifs.close();
	}//end ReadFile

	void ReadFileFromBasic(string filename){
		NoteMarkovModel basicModel;
		basicModel.ReadFile(filename);
		nBeat=basicModel.nBeat;
		RandomInit(nBeat);
		uniProb=basicModel.uniProb;
		iniProb=basicModel.iniProb;
		trProb=basicModel.trProb;
	}//end ReadFileFromBasic

	void SetSimpleModificationModel(double noInsP=0.9){
		for(int i=0;i<nBeat;i+=1){
			insProb[i].P[0]=noInsP;
			for(int h=1;h<insPattern[i].size();h+=1){
				insProb[i].P[h]=(1-noInsP)/double(insPattern[i].size()-1);
			}//endfor h
			insProb[i].Normalize();
		}//endfor i
	}//end SetSimpleModificationModel

	void SetDirParam(double alpha_ini,double alpha_tr,double alpha_ins){
		for(int b=0;b<nBeat;b+=1){
			iniDirParam[b]=alpha_ini*iniProb.P[b];
			for(int bp=0;bp<nBeat;bp+=1){
				trDirParam[b][bp]=alpha_tr*trProb[b].P[bp];
			}//endfor bp
		}//endfor b
		for(int i=0;i<nBeat;i+=1){
			for(int h=0;h<insPattern[i].size();h+=1){
				insDirParam[i][h]=alpha_ins*insProb[i].P[h];
			}//endfor h
		}//endfor i
	}//end SetDirParam


	double OutLP(int i,double dur){
		return -0.5*pow((dur-insPattern[indexSplitter[i][0]][indexSplitter[i][1]][indexSplitter[i][2]]*secPerTick)/sig_t,2.);
	}//end OutLP

	double TrLP(int ip,int i){
		if(indexSplitter[i][2]==0){
			if(indexSplitter[ip][2]==insPattern[indexSplitter[ip][0]][indexSplitter[ip][1]].size()-1){
				return trProb[indexSplitter[ip][0]].LP[indexSplitter[i][0]]+insProb[indexSplitter[i][0]].LP[indexSplitter[i][1]];
			}else{
				return -DBL_MAX;
			}//endif
		}else{//indexSplitter[i][2]>0
			if(indexSplitter[i][2]==indexSplitter[ip][2]+1
			   && indexSplitter[i][0]==indexSplitter[ip][0]
			   && indexSplitter[i][1]==indexSplitter[ip][1]){
				return 0;
			}else{
				return -DBL_MAX;
			}//endif
		}//endif
	}//end TrLP

	void Transcribe(){
		for(int l=0;l<ontimes.size();l+=1){
cout<<"Transcribe -- "<<(l+1)<<"/"<<ontimes.size()<<endl;

			///Viterbi
			vector<int> optPath(ontimes[l].size()-1);
			vector<double> LP(nEffState);
			vector<vector<int> > amax;
			amax.resize(ontimes[l].size()-1);
			for(int n=0;n<ontimes[l].size()-1;n+=1){amax[n].resize(nEffState);}

			/// ///Initialization
			double dur;
			dur=ontimes[l][1]-ontimes[l][0];
			LP.assign(nEffState,-DBL_MAX);
			for(int i=0;i<nEffState;i+=1){
				if(indexSplitter[i][2]!=0){continue;}
				LP[i]=iniProb.LP[indexSplitter[i][0]]+insProb[indexSplitter[i][0]].LP[indexSplitter[i][1]]+OutLP(i,dur);
			}//endfor i

			/// ///Update
			double logP;
			for(int n=2;n<ontimes[l].size();n+=1){
				vector<double> preLP(LP);
				dur=ontimes[l][n]-ontimes[l][n-1];
				LP.assign(nEffState,-DBL_MAX);
				for(int i=0;i<nEffState;i+=1){
					LP[i]=preLP[0]+TrLP(0,i);
					amax[n-1][i]=0;
					for(int ip=0;ip<nEffState;ip+=1){
						logP=preLP[ip]+TrLP(ip,i);
						if(logP>LP[i]){LP[i]=logP; amax[n-1][i]=ip;}
					}//endfor ip
					LP[i]+=OutLP(i,dur);
				}//endfor i
			}//endfor n

			/// ///Backtracking and set stimes
			optPath[optPath.size()-1]=0;
			for(int i=0;i<nEffState;i+=1){
				if(LP[i]>LP[optPath[optPath.size()-1]]){optPath[optPath.size()-1]=i;}//endif
			}//endfor i
			for(int n=optPath.size()-2;n>=0;n-=1){optPath[n]=amax[n+1][optPath[n+1]];}//endfor n

			for(int n=1;n<ontimes[l].size();n+=1){
				stimes[l][n]=stimes[l][n-1]+insPattern[indexSplitter[optPath[n-1]][0]][indexSplitter[optPath[n-1]][1]][indexSplitter[optPath[n-1]][2]];
			}//endfor n
		}//endfor l
	}//end Transcribe

	void BayesTranscribe(int nIter=10, int seed=2){
		/// Should be used after setting Dirichlet parameters
		boost::mt19937 gen;
		gen.seed(seed);
		Prob<int> genIniProb(iniProb);
		vector<Prob<int> > genTrProb(trProb);//(nBeat x nBeat)
		vector<Prob<int> > genInsProb(insProb);//insertion probability r -> h

		for(int l=0;l<ontimes.size();l+=1){
if(printOn){cout<<"BayesTranscribe -- "<<(l+1)<<"/"<<ontimes.size()<<endl;}

			iniProb=genIniProb;
			trProb=genTrProb;
			insProb=genInsProb;
			Prob<int> maxIniProb(iniProb);
			vector<Prob<int> > maxTrProb(trProb);//(nBeat x nBeat)
			vector<Prob<int> > maxInsProb(insProb);//insertion probability r -> h
			double evidLP;
			double maxEvidLP;
			int maxIter;
			double dur;

			///Gibbs sampling
			for(int iter=0;iter<nIter;iter+=1){

				///Sample scores by forward-filtering backward sampling
				vector<int> sampledStates(ontimes[l].size()-1);
				vector<vector<double> > forwardVar;// ontimes[l].size()-1 x nEffState
				forwardVar.resize(ontimes[l].size()-1);
				for(int n=0;n<ontimes[l].size()-1;n+=1){forwardVar[n].assign(nEffState,-DBL_MAX);}

				/// //Forward
				dur=ontimes[l][1]-ontimes[l][0];
				for(int i=0;i<nEffState;i+=1){
					if(indexSplitter[i][2]!=0){continue;}
					forwardVar[0][i]=LogAdd(forwardVar[0][i],iniProb.LP[indexSplitter[i][0]]+insProb[indexSplitter[i][0]].LP[indexSplitter[i][1]]+OutLP(i,dur));
				}//endfor i

				for(int n=2;n<ontimes[l].size();n+=1){
					dur=ontimes[l][n]-ontimes[l][n-1];
					for(int i=0;i<nEffState;i+=1){
						for(int ip=0;ip<nEffState;ip+=1){
							forwardVar[n-1][i]=LogAdd(forwardVar[n-1][i],forwardVar[n-2][ip]+TrLP(ip,i)+OutLP(i,dur));
						}//endfor ip
					}//endfor i
				}//endfor n

				evidLP=-DBL_MAX;
				for(int i=0;i<nEffState;i+=1){
					evidLP=LogAdd(evidLP,forwardVar[ontimes[l].size()-2][i]);
				}//endfor i

				if(iter==0 || evidLP>maxEvidLP){
					maxEvidLP=evidLP;
					maxIniProb=iniProb;
					maxTrProb=trProb;
					maxInsProb=insProb;
					maxIter=iter;
				}//endif
if(printOn){cout<<"Iteration: "<<iter<<"\t-NORM(evidLP,maxEvidLP): "<<-evidLP/double(ontimes[l].size())<<"\t"<<-maxEvidLP/double(ontimes[l].size())<<"\t"<<((evidLP==maxEvidLP)? "******":"")<<endl;}

				/// //Backward sampling
				Prob<int> prob;
				prob.LP=forwardVar[ontimes[l].size()-2];
				prob.LogNormalize();
				sampledStates[ontimes[l].size()-2]=SampleDistr(prob.P);

				for(int n=ontimes[l].size()-3;n>=0;n-=1){
					for(int i=0;i<nEffState;i+=1){
						prob.LP[i]=forwardVar[n][i]+TrLP(i,sampledStates[n+1]);
					}//endfor i
					prob.LogNormalize();
					sampledStates[n]=SampleDistr(prob.P);
				}//endfor n

				///Sample parameters
				iniProb.P=iniDirParam;
				iniProb.P[indexSplitter[sampledStates[0]][0]]+=1;
				for(int r=0;r<nBeat;r+=1){
					boost::gamma_distribution<> dst( iniProb.P[r], 1. );
					boost::variate_generator<boost::mt19937&, boost::gamma_distribution<> > gamma_rand( gen, dst );
					iniProb.P[r]=gamma_rand();
				}//endfor r
				iniProb.Normalize();

				for(int r=0;r<nBeat;r+=1){
					trProb[r].P=trDirParam[r];
				}//endfor r
				for(int n=1;n<ontimes[l].size()-1;n+=1){
					if(indexSplitter[sampledStates[n]][2]!=0){continue;}
					trProb[indexSplitter[sampledStates[n-1]][0]].P[indexSplitter[sampledStates[n]][0]]+=1;
				}//endfor n
				for(int r=0;r<nBeat;r+=1){
					for(int rp=0;rp<nBeat;rp+=1){
						boost::gamma_distribution<> dst( trProb[r].P[rp], 1. );
						boost::variate_generator<boost::mt19937&, boost::gamma_distribution<> > gamma_rand( gen, dst );
						trProb[r].P[rp]=gamma_rand();
					}//endfor rp
					trProb[r].Normalize();
				}//endfor r

				for(int r=0;r<nBeat;r+=1){
					insProb[r].P=insDirParam[r];
				}//endfor r
				for(int n=0;n<ontimes[l].size()-1;n+=1){
					if(indexSplitter[sampledStates[n]][2]!=0){continue;}
					insProb[indexSplitter[sampledStates[n]][0]].P[indexSplitter[sampledStates[n]][1]]+=1;
				}//endfor n
				for(int r=0;r<nBeat;r+=1){
					for(int h=0;h<insDirParam[r].size();h+=1){
						boost::gamma_distribution<> dst( insProb[r].P[h], 1. );
						boost::variate_generator<boost::mt19937&, boost::gamma_distribution<> > gamma_rand( gen, dst );
						insProb[r].P[h]=gamma_rand();
					}//endfor h
					insProb[r].Normalize();
				}//endfor r

			}//endfor iter


			///Set optimal parameter
			iniProb=maxIniProb;
			trProb=maxTrProb;
			insProb=maxInsProb;

			///Viterbi
			vector<int> optPath(ontimes[l].size()-1);
			vector<double> LP(nEffState);
			vector<vector<int> > amax;
			amax.resize(ontimes[l].size()-1);
			for(int n=0;n<ontimes[l].size()-1;n+=1){amax[n].resize(nEffState);}

			/// ///Initialization
			dur=ontimes[l][1]-ontimes[l][0];
			LP.assign(nEffState,-DBL_MAX);
			for(int i=0;i<nEffState;i+=1){
				if(indexSplitter[i][2]!=0){continue;}
				LP[i]=iniProb.LP[indexSplitter[i][0]]+insProb[indexSplitter[i][0]].LP[indexSplitter[i][1]]+OutLP(i,dur);
			}//endfor i

			/// ///Update
			double logP;
			for(int n=2;n<ontimes[l].size();n+=1){
				vector<double> preLP(LP);
				dur=ontimes[l][n]-ontimes[l][n-1];
				LP.assign(nEffState,-DBL_MAX);
				for(int i=0;i<nEffState;i+=1){
					LP[i]=preLP[0]+TrLP(0,i);
					amax[n-1][i]=0;
					for(int ip=0;ip<nEffState;ip+=1){
						logP=preLP[ip]+TrLP(ip,i);
						if(logP>LP[i]){LP[i]=logP; amax[n-1][i]=ip;}
					}//endfor ip
					LP[i]+=OutLP(i,dur);
				}//endfor i
			}//endfor n

			/// ///Backtracking and set stimes
			optPath[optPath.size()-1]=0;
			for(int i=0;i<nEffState;i+=1){
				if(LP[i]>LP[optPath[optPath.size()-1]]){optPath[optPath.size()-1]=i;}//endif
			}//endfor i
			for(int n=optPath.size()-2;n>=0;n-=1){optPath[n]=amax[n+1][optPath[n+1]];}//endfor n

			for(int n=1;n<ontimes[l].size();n+=1){
				stimes[l][n]=stimes[l][n-1]+insPattern[indexSplitter[optPath[n-1]][0]][indexSplitter[optPath[n-1]][1]][indexSplitter[optPath[n-1]][2]];
			}//endfor n

			///Write piece-specific parameter file
			stringstream ss;
			ss.str(""); ss<<paramFolder<<"param_noteMM1D_"<<l<<".txt";
			WriteFile(ss.str());

		}//endfor l
	}//end BayesTranscribe

};//endclass NoteMM1D

#endif // NoteMarkovModelMod_HPP
