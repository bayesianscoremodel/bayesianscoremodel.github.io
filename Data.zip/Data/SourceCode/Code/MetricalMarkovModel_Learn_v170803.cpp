#include<fstream>
#include<iostream>
#include<cmath>
#include<string>
#include<sstream>
#include<vector>
#include<algorithm>
#include"stdio.h"
#include"stdlib.h"
#include"MetricalMarkovModel_v170803.hpp"
using namespace std;

int main(int argc, char** argv){
	vector<int> v(100);
	vector<double> d(100);
	vector<string> s(100);
	stringstream ss;
	clock_t start, end;
	start = clock();

	if(argc!=6){
		cout<<"Error in usage: $./this order beatResolution data.txt out_param.txt smoothConst(0.1)"<<endl;
		return -1;
	}//endif

	int order=atoi(argv[1]);
	int nBeat=atoi(argv[2]);
	string datafile=string(argv[3]);
	string paramfile=string(argv[4]);
	double smoothConst=atof(argv[5]);

	assert(order>=0 && order<=2);

	if(order==1){

		MetricalMarkovModel metMM;
		metMM.RandomInit(nBeat);
		metMM.ReadData(datafile);
		metMM.LearnAdditiveSmoothing(smoothConst);
		metMM.WriteFile(paramfile);

	}else if(order==0){

		MetricalMarkovModel_0th metMM0;
		metMM0.RandomInit(nBeat);
		metMM0.ReadData(datafile);
		metMM0.LearnAdditiveSmoothing(smoothConst);
		metMM0.WriteFile(paramfile);

	}else if(order==2){

		MetricalMarkovModel_2nd metMM2;
		metMM2.RandomInit(nBeat);
		metMM2.ReadData(datafile);
		metMM2.LearnAdditiveSmoothing(smoothConst);
		metMM2.WriteFile(paramfile);

	}//endif


	return 0;
}//end main
