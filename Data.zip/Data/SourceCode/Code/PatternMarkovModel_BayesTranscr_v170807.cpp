#include<fstream>
#include<iostream>
#include<cmath>
#include<string>
#include<sstream>
#include<vector>
#include<algorithm>
#include"stdio.h"
#include"stdlib.h"
#include"PatternMarkovModel_v170803.hpp"
using namespace std;

int main(int argc, char** argv){
	vector<int> v(100);
	vector<double> d(100);
	vector<string> s(100);
	stringstream ss;
	clock_t start, end;
	start = clock();

	if(argc!=11){
		cout<<"Error in usage: $./this order param.txt perfmdata.txt out_transcr.txt paramFolder(/) sig_t alpha_tr(10) nIter(100) linearInterpolateCoeff(0) seed"<<endl;
		return -1;
	}//endif

	int order=atoi(argv[1]);
	string paramfile=string(argv[2]);
	string perfmfile=string(argv[3]);
	string transcrfile=string(argv[4]);
	string paramfolder=string(argv[5]);
	double sig_t=atof(argv[6]);
	double alpha_tr=atof(argv[7]);//200
	int nIter=atoi(argv[8]);//100
	double linearInterpolateCoeff=atof(argv[9]);
	int seed=atoi(argv[10]);

	assert(order>=0 && order<=1);

cout<<"#Output from NoteMarkovModel_BayesTranscr_v170807"<<endl;
cout<<"#order: "<<order<<" paramfile: "<<paramfile<<" perfmfile: "<<perfmfile<<" transcrfile: "<<transcrfile<<" paramfolder: "<<paramfolder<<" sig_t: "<<sig_t<<" alpha_tr: "<<alpha_tr<<" nIter: "<<nIter<<" linearInterpolateCoeff: "<<linearInterpolateCoeff<<" seed: "<<seed<<endl;

	if(order==1){

		PatternMarkovModel model;
		model.SetParamFolder(paramfolder);
		model.ReadFile(paramfile);
		model.LinearInterpolate(linearInterpolateCoeff);
		model.SetDirParam(alpha_tr);
		model.ReadPerfmData(perfmfile);
		if(sig_t>0){model.sig_t=sig_t;}
		model.BayesTranscribe(nIter,seed);
		model.WritePerfmData(transcrfile);

	}else if(order==0){

		PatternMarkovModel_0th model;
		model.SetParamFolder(paramfolder);
		model.ReadFile(paramfile);
		model.SetDirParam(alpha_tr);
		model.ReadPerfmData(perfmfile);
		if(sig_t>0){model.sig_t=sig_t;}
		model.BayesTranscribe(nIter,seed);
		model.WritePerfmData(transcrfile);

	}//endif



//	end = clock(); cout<<"Elapsed time : "<<((double)(end - start) / CLOCKS_PER_SEC)<<" sec"<<endl; start=end;
	return 0;
}//end main
