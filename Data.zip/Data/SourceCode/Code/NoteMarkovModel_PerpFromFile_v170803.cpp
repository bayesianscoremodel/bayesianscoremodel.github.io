#include<fstream>
#include<iostream>
#include<cmath>
#include<string>
#include<sstream>
#include<vector>
#include<algorithm>
#include"stdio.h"
#include"stdlib.h"
#include"NoteMarkovModel_v170803.hpp"
using namespace std;

int main(int argc, char** argv){
	vector<int> v(100);
	vector<double> d(100);
	vector<string> s(100);
	stringstream ss;
	clock_t start, end;
	start = clock();

	if(argc!=5){
		cout<<"Error in usage: $./this order param.txt data.txt coeff(0;2nd)"<<endl;
		return -1;
	}//endif

	int order=atoi(argv[1]);
	string paramfile=string(argv[2]);
	string datafile=string(argv[3]);
	double coeff=atof(argv[4]);

	assert(order>=0 && order<=2);

	if(order==1){

		NoteMarkovModel noteMM;
		noteMM.ReadFile(paramfile);
		noteMM.ReadData(datafile);
		d[0]=noteMM.GetLP();

cout<<"CE,Perp:\t"<<-d[0]/noteMM.nNote/log(2)<<"\t"<<exp(-d[0]/noteMM.nNote)<<endl;

	}else if(order==0){

		NoteMarkovModel_0th noteMM0;
		noteMM0.ReadFile(paramfile);
		noteMM0.ReadData(datafile);
		d[0]=noteMM0.GetLP();

cout<<"CE,Perp:\t"<<-d[0]/noteMM0.nNote/log(2)<<"\t"<<exp(-d[0]/noteMM0.nNote)<<endl;

	}else if(order==2){

		NoteMarkovModel_2nd noteMM2;
		noteMM2.ReadFile(paramfile);
		noteMM2.ReadData(datafile);
		noteMM2.LinearInterpolate(coeff);
		d[0]=noteMM2.GetLP();

cout<<"CE,Perp:\t"<<-d[0]/noteMM2.nNote/log(2)<<"\t"<<exp(-d[0]/noteMM2.nNote)<<endl;

	}//endif

	return 0;
}//end main
