#include<fstream>
#include<iostream>
#include<cmath>
#include<string>
#include<sstream>
#include<vector>
#include<algorithm>
#include"stdio.h"
#include"stdlib.h"
#include"PatternMarkovModel_v170803.hpp"
using namespace std;

int main(int argc, char** argv){
	vector<int> v(100);
	vector<double> d(100);
	vector<string> s(100);
	stringstream ss;
	clock_t start, end;
	start = clock();

	if(argc!=5){
		cout<<"Error in usage: $./this order param.txt data.txt interpCoeff(0)"<<endl;
		return -1;
	}//endif

	int order=atoi(argv[1]);
	string paramfile=string(argv[2]);
	string datafile=string(argv[3]);
	double interpCoeff=atof(argv[4]);

	assert(order>=0 && order<=1);

	if(order==1){

		PatternMarkovModel model;
		model.ReadFile(paramfile);
		model.LinearInterpolate(interpCoeff);
		model.ReadData(datafile);
		d[0]=model.GetLP();
cout<<"CE,Perp:\t"<<-d[0]/model.nNote/log(2)<<"\t"<<exp(-d[0]/model.nNote)<<endl;

	}else if(order==0){

		PatternMarkovModel_0th model;
		model.ReadFile(paramfile);
		model.ReadData(datafile);
		d[0]=model.GetLP();
cout<<"CE,Perp:\t"<<-d[0]/model.nNote/log(2)<<"\t"<<exp(-d[0]/model.nNote)<<endl;

	}//endif


	return 0;
}//end main
