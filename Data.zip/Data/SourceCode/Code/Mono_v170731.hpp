#ifndef Mono_HPP
#define Mono_HPP

#include<iostream>
#include<string>
#include<sstream>
#include<cmath>
#include<vector>
#include<fstream>
#include<cassert>
#include"Fmt1x_v170108_2.hpp"
#include"BasicPitchCalculation_v170101.hpp"
#include"PianoRoll_v170503.hpp"
#include"Dionysos_v190521.hpp"
using namespace std;

string SitchToABCSitch(string sitch){
	if(sitch=="rest"){return "z";}
	int oct=atoi(sitch.substr(sitch.size()-1,1).c_str());
	string sitchclass=sitch.substr(0,sitch.size()-1);
	string diatonic=sitchclass.substr(0,1);
	string acc=sitchclass.substr(1);
//cout<<sitch<<"\t"<<oct<<"\t"<<sitchclass<<"\t"<<diatonic<<"\t"<<acc<<endl;
	stringstream ss;
	ss.str("");
	if(acc=="##"){ss<<"^^";
	}else if(acc=="#"){ss<<"^";
	}else if(acc=="b"){ss<<"_";
	}else if(acc=="bb"){ss<<"__";
	}//endif
	if(oct<=4){
		ss<<diatonic;
		for(int i=3;i>=oct;i-=1){ss<<",";}
	}else{
		transform(diatonic.begin(), diatonic.end(), diatonic.begin(), ::tolower); 
		ss<<diatonic;
		for(int i=6;i<=oct;i+=1){ss<<"'";}
	}//endif
	return ss.str();
}//end SitchToABCSitch

string ToABCNote(string sitch,int nv){
	stringstream ss; ss.str();
	if(nv==5){
		ss<<SitchToABCSitch(sitch)<<2<<"-";
		ss<<SitchToABCSitch(sitch)<<3;
	}else if(nv==9){
		ss<<SitchToABCSitch(sitch)<<1<<"-";
		ss<<SitchToABCSitch(sitch)<<8;
	}else if(nv==10){
		ss<<SitchToABCSitch(sitch)<<2<<"-";
		ss<<SitchToABCSitch(sitch)<<8;
	}else if(nv==11){
		ss<<SitchToABCSitch(sitch)<<3<<"-";
		ss<<SitchToABCSitch(sitch)<<8;
	}else if(nv==13){
		ss<<SitchToABCSitch(sitch)<<1<<"-";
		ss<<SitchToABCSitch(sitch)<<12;
	}else if(nv==15){
		ss<<SitchToABCSitch(sitch)<<3<<"-";
		ss<<SitchToABCSitch(sitch)<<12;
	}else{
		ss<<SitchToABCSitch(sitch)<<nv;
	}//endif
	return ss.str();
}//end ToABCNote

class MonoNote{
public:
	string sitch;
	int notevalue;
	int beatpos;

	int pitch;
	int pitchID;
};//

class MonoBar{
public:
	int ID;
	int length;
	bool tied;
	vector<MonoNote> notes;
	int stime;

	vector<int> GetPitchClassRep(){
		vector<int> vi(length);
		for(int n=0;n<notes.size();n+=1){
			if(n==0){
				if(notes[n].beatpos>0){
					for(int b=0;b<notes[n].beatpos;b+=1){
						vi[b]=notes[n].pitch%12;
					}//endfor b
				}//endif
				continue;
			}else if(n==notes.size()-1){
				for(int b=notes[n].beatpos;b<length;b+=1){
					vi[b]=notes[n].pitch%12;
				}//endfor b
			}//endif
			for(int b=notes[n-1].beatpos;b<notes[n].beatpos;b+=1){
				vi[b]=notes[n-1].pitch%12;
			}//endfor b
		}//endfor n
		return vi;
	}//end GetPitchRep
};//

inline int MonoBarHammDist(MonoBar bar1,MonoBar bar2,int offset=0){
	int dist;
	vector<int> pcRep1,pcRep2;
	pcRep1=bar1.GetPitchClassRep();
	pcRep2=bar2.GetPitchClassRep();
	assert(pcRep1.size()==pcRep2.size());
	for(int b=0;b<pcRep2.size();b+=1){
		pcRep2[b]=(pcRep2[b]+offset+1200)%12;
	}//endfor b
	dist=0;
	for(int b=0;b<pcRep2.size();b+=1){
		if(pcRep1[b]!=pcRep2[b]){dist+=1;}
	}//endfor b
	return dist;
}//end MonoBarHammDist

inline int MonoBarTrSymHammDist(MonoBar bar1,MonoBar bar2){
	int mindist=MonoBarHammDist(bar1,bar2,0);
	for(int k=1;k<12;k+=1){
		int dist=MonoBarHammDist(bar1,bar2,k);
		if(dist<mindist){mindist=dist;}
	}//endfor k
	return mindist;
}//end MonoBarTrSymHammDist

inline int MonoBarCommonality(MonoBar bar1,MonoBar bar2,int offset=0){
	int comm=0;
	for(int n=0;n<bar1.notes.size();n+=1){
		if(bar1.tied && n==0){continue;}
		for(int np=0;np<bar2.notes.size();np+=1){
			if(bar2.tied && np==0){continue;}
			if(bar1.notes[n].beatpos==bar2.notes[np].beatpos){
				if(bar1.notes[n].pitch%12==(bar2.notes[np].pitch+offset+1200)%12){
					comm+=1;
				}//endif
			}//endif
		}//endfor np
	}//endfor n
	return comm;
}//end MonoBarHammDist

inline int MonoBarTrSymCommonality(MonoBar bar1,MonoBar bar2){
	int maxcomm=MonoBarCommonality(bar1,bar2,0);
	for(int k=1;k<12;k+=1){
		int comm=MonoBarCommonality(bar1,bar2,k);
		if(comm>maxcomm){maxcomm=comm;}
	}//endfor k
	return maxcomm;
}//end MonoBarTrSymHammDist

class Mono{
public:
	int TPQN;
	vector<MonoBar> bars;

	void SetBarStime(){
		int curStime=0;
		for(int i=0;i<bars.size();i+=1){
			bars[i].stime=curStime;
			curStime+=bars[i].length;
		}//endfor i
	}//end SetBarStime

	void SetNoteValues(){
		for(int m=0;m<bars.size();m+=1){
			for(int n=0;n<bars[m].notes.size();n+=1){
				if(n==bars[m].notes.size()-1){
					bars[m].notes[n].notevalue=bars[m].length-bars[m].notes[n].beatpos;
				}else{
					bars[m].notes[n].notevalue=bars[m].notes[n+1].beatpos-bars[m].notes[n].beatpos;
				}//endif
			}//endfor n
		}//endfor m
	}//end SetNoteValues

	void SetBarID(){
		for(int n=0;n<bars.size();n+=1){
			bars[n].ID=n+1;
		}//endfor n
	}//end SetBarID

	void SetNoteStimes(){
		for(int n=0;n<bars.size();n+=1){
			for(int i=0;i<bars[n].notes.size();i+=1){
				if(i==0){
					bars[n].notes[i].beatpos=0;
				}else{
					bars[n].notes[i].beatpos=bars[n].notes[i-1].beatpos+bars[n].notes[i-1].notevalue;
				}//endif
			}//endfor i
		}//endfor n
	}//end SetNoteStimes

	void ReadFile(string filename){
		bars.clear();
		vector<int> v(100);
		vector<double> d(100);
		vector<string> s(100);
		MonoBar bar;
		MonoNote note;
		note.pitchID=-1;
		ifstream ifs(filename.c_str());
		while(ifs>>s[0]){
			if(s[0]=="//TPQN:"){
				ifs>>TPQN;
				getline(ifs,s[99]);
				continue;
			}else if(s[0][0]=='/' || s[0][0]=='#'){
				getline(ifs,s[99]);
				continue;
			}//endif
			bar.ID=atoi(s[0].c_str());
			ifs>>bar.length>>bar.tied>>v[1];
			bar.notes.clear();
			for(int i=0;i<v[1];i+=1){
//				ifs>>note.sitch>>note.notevalue;
				ifs>>note.beatpos>>note.sitch;
				note.pitch=SitchToPitch(note.sitch);
				bar.notes.push_back(note);
			}//endfor i
			bars.push_back(bar);
			getline(ifs,s[99]);
		}//endwhile
		ifs.close();
		SetBarStime();
	}//end ReadFile

	void WriteFile(string filename){
		ofstream ofs(filename.c_str());
		ofs<<"//TPQN: "<<TPQN<<"\n";
		for(int i=0;i<bars.size();i+=1){
			ofs<<bars[i].ID<<"\t"<<bars[i].length<<"\t"<<bars[i].tied<<"\t"<<bars[i].notes.size()<<"\t";
			for(int j=0;j<bars[i].notes.size();j+=1){
				ofs<<bars[i].notes[j].beatpos<<"\t"<<bars[i].notes[j].sitch<<"\t";
			}//endfor j
			ofs<<"\n";
		}//endfor i
		ofs.close();
	}//end WriteFile

	void ReadFmt1xFile(string filename){
		bars.clear();
		Fmt1x fmt1x;
		fmt1x.ReadFile(filename);
		TPQN=fmt1x.TPQN;

		string curBarNum="-";
		MonoBar bar;
		MonoNote curNote;

		bar.tied=false;
		for(int i=0;i<fmt1x.evts.size();i+=1){
			if(fmt1x.evts[i].eventtype=="attributes"){continue;}
			if(fmt1x.evts[i].voice!=1){continue;}

			if(curBarNum!=fmt1x.evts[i].barnum){//New bar entered

				if(curBarNum!="-"){
					bars.push_back(bar);
				}//endif
				bar.notes.clear();
				bar.tied=false;
				bar.stime=fmt1x.evts[i].stime;
				curBarNum=fmt1x.evts[i].barnum;
				if(fmt1x.evts[i].tieinfo>=2){
					bar.tied=true;
				}//endif

				if(fmt1x.evts[i].eventtype=="rest"){
					curNote.sitch="rest";
				}else{
					curNote.sitch=fmt1x.evts[i].sitches[0];
				}//endif
				curNote.notevalue=fmt1x.evts[i].dur;
				bar.notes.push_back(curNote);

				continue;
			}//endif

			if((fmt1x.evts[i].eventtype=="rest"&&fmt1x.evts[i-1].eventtype=="rest") || fmt1x.evts[i].tieinfo>=2){
				bar.notes[bar.notes.size()-1].notevalue+=fmt1x.evts[i].dur;
			}else{
				curNote.sitch=fmt1x.evts[i].sitches[fmt1x.evts[i].numNotes-1];
				curNote.notevalue=fmt1x.evts[i].dur;
				bar.notes.push_back(curNote);
			}//endif

		}//endfor i

		bars.push_back(bar);

		/// Set bar length
		for(int n=0;n<bars.size();n+=1){
			bars[n].length=0;
			bool isWholeRest=true;
			for(int i=0;i<bars[n].notes.size();i+=1){
				bars[n].length+=bars[n].notes[i].notevalue;
				if(bars[n].notes[i].sitch!="rest"){
					isWholeRest=false;
				}//endif
			}//endfor i
			if(isWholeRest){
				bars[n].notes.clear();
			}//endif
		}//endfor n

		SetBarStime();
		SetBarID();
		SetNoteStimes();

	}//end ReadFmt1xFile

	void ConnectShortRestToNote(){
		/// Unless a rest spans a whole bar, erase it and lengthen the previous note's note value by its note value

		///Erase rests that are not at the beginning of a bar
		for(int m=0;m<bars.size();m+=1){
			for(int n=bars[m].notes.size()-1;n>=1;n-=1){
				if(bars[m].notes[n].sitch!="rest"){continue;}
				bars[m].notes.erase(bars[m].notes.begin()+n);
			}//endfor n
		}//endfor m

		///Convert rests at the beginning of a bar into suspensions
		for(int m=1;m<bars.size();m+=1){
			if(bars[m].notes.size()==0){continue;}
			if(bars[m].notes[0].sitch!="rest"){continue;}
			if(bars[m-1].notes.size()==0){continue;}
			bars[m].notes[0].sitch=bars[m-1].notes[bars[m-1].notes.size()-1].sitch;
			bars[m].tied=true;
		}//endfor m

		SetNoteValues();

	}//end ConnectShortRestToNote

	void ChangeTPQN(int newTPQN){
//		cout<<"WARNING: ChangeTPQN erases all bars and notes that are not integral in the new TPQN"<<endl;

		for(int m=bars.size()-1;m>=0;m-=1){
			if((bars[m].length*newTPQN)%TPQN!=0){bars.erase(bars.begin()+m);}
		}//endfor m

		for(int m=0;m<bars.size();m+=1){
			for(int n=bars[m].notes.size()-1;n>=0;n-=1){
				if((bars[m].notes[n].beatpos*newTPQN)%TPQN!=0){bars[m].notes.erase(bars[m].notes.begin()+n);}
			}//endfor n
		}//endfor m

		for(int m=0;m<bars.size();m+=1){
			bars[m].length=(bars[m].length*newTPQN)/TPQN;
			bool isWholeRest=true;
			for(int n=0;n<bars[m].notes.size();n+=1){
				bars[m].notes[n].beatpos=(bars[m].notes[n].beatpos*newTPQN)/TPQN;
				if(bars[m].notes[n].sitch!="rest"){isWholeRest=false;}
			}//endfor n
			if(isWholeRest){bars[m].notes.clear();}
		}//endfor m

		SetBarStime();
		SetNoteValues();
		TPQN=newTPQN;

	}//end ChangeTPQN

	void EraseWholeRests(){
		for(int m=bars.size()-1;m>=0;m-=1){
			if(bars[m].notes.size()==0){bars.erase(bars.begin()+m);}
		}//endfor m
	}//end EraseWholeRests

	void WriteABC(string filename){
		ofstream ofs(filename.c_str());
ofs<<"\
M: 4/4\n\
L: 1/64\n\
K: C\n\
| ";

	string preSitch="rest";
	int nv;
	for(int m=0;m<bars.size();m+=1){
		for(int n=0;n<bars[m].notes.size();n+=1){
			if(n==0){
				if(bars[m].tied && bars[m].notes[n].beatpos==0){
					nv=bars[m].length;
					if(n<bars[m].notes.size()-1){nv=bars[m].notes[n+1].beatpos;}
					nv*=16/TPQN;
ofs<<ToABCNote(preSitch,nv);
				}else if(bars[m].notes[n].beatpos>0){
					nv=bars[m].notes[n].beatpos;
					nv*=16/TPQN;
ofs<<ToABCNote(preSitch,nv);
					nv=bars[m].length-bars[m].notes[n].beatpos;
					if(n<bars[m].notes.size()-1){nv=bars[m].notes[n+1].beatpos-bars[m].notes[n].beatpos;}
					nv*=16/TPQN;
					preSitch=bars[m].notes[n].sitch;
ofs<<ToABCNote(preSitch,nv);
				}else{
					nv=bars[m].length;
					if(n<bars[m].notes.size()-1){nv=bars[m].notes[n+1].beatpos;}
					nv*=16/TPQN;
					preSitch=bars[m].notes[n].sitch;
ofs<<ToABCNote(preSitch,nv);
				}//endif

			}else{//n>0

				nv=bars[m].length-bars[m].notes[n].beatpos;
				if(n<bars[m].notes.size()-1){nv=bars[m].notes[n+1].beatpos-bars[m].notes[n].beatpos;}
				nv*=16/TPQN;
				preSitch=bars[m].notes[n].sitch;
ofs<<ToABCNote(preSitch,nv);

			}//endif

			if(n==bars[m].notes.size()-1){
				if(m<bars.size()-1){
					if(bars[m+1].tied){
ofs<<"-";
					}else if(bars[m+1].notes.size()>0){
						if(bars[m+1].notes[0].beatpos>0){
ofs<<"-";
						}//endif
					}//endif
				}//endif
			}//endif

ofs<<" ";

		}//endfor n
ofs<<"| ";
	}//endfor m
ofs<<"\n";

		ofs.close();
	}//end WriteABC

	PianoRoll ToPianoRoll(double secPerQN){
		PianoRoll pr;
		PianoRollEvt evt;
		evt.ID="0";
		evt.onvel=80;
		evt.offvel=80;
		evt.channel=0;
		evt.pitch=-1;
		bool afterRest=false;
		for(int m=0;m<bars.size();m+=1){
			for(int n=0;n<bars[m].notes.size();n+=1){
				if(bars[m].notes[n].sitch=="rest"){
					evt.offtime=(bars[m].stime+bars[m].notes[n].beatpos)*secPerQN/double(TPQN)-0.01;
					afterRest=true;
					continue;
				}//endif
				if(bars[m].tied && bars[m].notes[n].beatpos==0){continue;}
				if(!afterRest){
					evt.offtime=(bars[m].stime+bars[m].notes[n].beatpos)*secPerQN/double(TPQN)-0.01;
				}//endif
				if(evt.pitch>0){pr.evts.push_back(evt);}
				afterRest=false;
				evt.pitch=bars[m].notes[n].pitch;
				evt.sitch=bars[m].notes[n].sitch;
				evt.ontime=(bars[m].stime+bars[m].notes[n].beatpos)*secPerQN/double(TPQN);
			}//endfor n
		}//endfor m
		evt.offtime=evt.ontime+secPerQN;
		pr.evts.push_back(evt);

		for(int m=0;m<bars.size();m+=1){
			evt.ontime=bars[m].stime*secPerQN/double(TPQN);
			evt.offtime=evt.ontime+0.1;
			evt.pitch=36;//bass drum
			evt.sitch=PitchToSitch(evt.pitch);
			evt.onvel=60;
			evt.offvel=80;
			evt.channel=9;
			pr.evts.push_back(evt);
			evt.ontime=bars[m].stime*secPerQN/double(TPQN);
			evt.offtime=evt.ontime+0.1;
			evt.pitch=46;//open hihat
			evt.sitch=PitchToSitch(evt.pitch);
			evt.onvel=70;
			evt.offvel=80;
			evt.channel=9;
			pr.evts.push_back(evt);

			for(int t=bars[m].stime+TPQN;t<=bars[m].stime+3*TPQN;t+=TPQN){
				evt.ontime=t*secPerQN/double(TPQN);
				evt.offtime=evt.ontime+0.1;
				evt.pitch=38;//snare drum
				evt.sitch=PitchToSitch(evt.pitch);
				evt.onvel=70;
				evt.offvel=80;
				evt.channel=9;
				pr.evts.push_back(evt);
			}//endfor t
		}//endfor m

		return pr;
	}//end ToPianoRoll

	void WriteMIDI(string filename,double secPerQN){
		PianoRoll pr;
		pr=ToPianoRoll(secPerQN);
		for(int i=0;i<pr.evts.size();i+=1){
			if(pr.evts[i].offtime-pr.evts[i].ontime>2){pr.evts[i].offtime=pr.evts[i].ontime+2;}
		}//endfor i
		pr.programChangeData.assign(16,0);//trumpets
		pr.WriteMIDIFile(filename);
	}//end WriteMIDI

	void WriteQuantizedMIDI(string filename,double secPerQN){
		Midi midi;
		midi.programChangeData.assign(16,0);
		midi.TPQN=TPQN;

		MidiMessage midiMes;
		int curPitch=-1;
		for(int m=0;m<bars.size();m+=1){
			for(int n=0;n<bars[m].notes.size();n+=1){
				if(bars[m].notes[n].sitch=="rest"){
					if(curPitch>0){
						//note-off
						midiMes.tick=bars[m].stime+bars[m].notes[n].beatpos;
						midiMes.mes.assign(3,0);
						midiMes.mes[0]=128+0; midiMes.mes[1]=curPitch; midiMes.mes[2]=80;
						midi.content.push_back(midiMes);
					}//endif
					curPitch=-1;
					continue;
				}//endif
				if(bars[m].tied && bars[m].notes[n].beatpos==0){continue;}

				if(curPitch>0){
					//note-off
					midiMes.tick=bars[m].stime+bars[m].notes[n].beatpos;
					midiMes.mes.assign(3,0);
					midiMes.mes[0]=128+0; midiMes.mes[1]=curPitch; midiMes.mes[2]=80;
					midi.content.push_back(midiMes);
				}//endif
				//note-on
				midiMes.tick=bars[m].stime+bars[m].notes[n].beatpos;
				midiMes.mes.assign(3,0);
				midiMes.mes[0]=144+0; midiMes.mes[1]=bars[m].notes[n].pitch; midiMes.mes[2]=80;
				midi.content.push_back(midiMes);
				curPitch=bars[m].notes[n].pitch;
			}//endfor n
		}//endfor m
		if(curPitch>0){
			//note-off
			midiMes.tick+=TPQN;
			midiMes.mes.assign(3,0);
			midiMes.mes[0]=128+0; midiMes.mes[1]=curPitch; midiMes.mes[2]=80;
			midi.content.push_back(midiMes);
		}//endif


		for(int m=0;m<bars.size();m+=1){
			//bass drum
			//note-on
			midiMes.tick=bars[m].stime;
			midiMes.mes.assign(3,0);
			midiMes.mes[0]=144+9; midiMes.mes[1]=36; midiMes.mes[2]=60;
			midi.content.push_back(midiMes);
			//note-off
			midiMes.tick=bars[m].stime+1;
			midiMes.mes.assign(3,0);
			midiMes.mes[0]=128+9; midiMes.mes[1]=36; midiMes.mes[2]=80;
			midi.content.push_back(midiMes);

			//open hihat
			//note-on
			midiMes.tick=bars[m].stime;
			midiMes.mes.assign(3,0);
			midiMes.mes[0]=144+9; midiMes.mes[1]=46; midiMes.mes[2]=70;
			midi.content.push_back(midiMes);
			//note-off
			midiMes.tick=bars[m].stime+1;
			midiMes.mes.assign(3,0);
			midiMes.mes[0]=128+9; midiMes.mes[1]=46; midiMes.mes[2]=80;
			midi.content.push_back(midiMes);

			for(int t=bars[m].stime+TPQN;t<=bars[m].stime+3*TPQN;t+=TPQN){
				//snare drum
				//note-on
				midiMes.tick=t;
				midiMes.mes.assign(3,0);
				midiMes.mes[0]=144+9; midiMes.mes[1]=38; midiMes.mes[2]=70;
				midi.content.push_back(midiMes);
				//note-off
				midiMes.tick=t+1;
				midiMes.mes.assign(3,0);
				midiMes.mes[0]=128+9; midiMes.mes[1]=38; midiMes.mes[2]=80;
				midi.content.push_back(midiMes);
			}//endfor t
		}//endfor m

		midi.WriteQuantizedFile(filename,TPQN,int(60/secPerQN),4,4);
	}//end WriteQuantizedMIDI

	void FromDio(Dionysos dio){
		bars.clear();
		TPQN=12;
		MonoBar bar;
		bar.length=4*TPQN;
		bar.tied=false;
		if(dio.evts.size()==0){return;}
		MonoNote note;
		note.pitch=dio.evts[0].pitch;
		note.sitch=PitchToSitch(note.pitch);
		note.beatpos=dio.evts[0].onBeat*3;
		bar.notes.push_back(note);

		int curPitch=note.pitch;

		for(int i=1;i<dio.evts.size();i+=1){
			if(dio.evts[i].onBar!=dio.evts[i-1].onBar){
				bars.push_back(bar);
				bar.notes.clear();
				bar.tied=false;
				for(int j=dio.evts[i-1].onBar+1;j<dio.evts[i].onBar;j+=1){
					note.pitch=curPitch;
					note.sitch=PitchToSitch(note.pitch);
					note.beatpos=0;
					if(curPitch>=0){bar.tied=true;
					}else{bar.tied=false;
					}//endif
					bar.notes.push_back(note);
					bars.push_back(bar);
					bar.notes.clear();
					bar.tied=false;
				}//endfor j
			}//endif
			curPitch=dio.evts[i].pitch;
			note.pitch=curPitch;
			note.sitch=PitchToSitch(note.pitch);
			note.beatpos=dio.evts[i].onBeat*3;
			if(bar.notes.size()==0 && curPitch>=0 && note.beatpos>0){bar.tied=true;}//endif
			bar.notes.push_back(note);
		}//endfor i
		bars.push_back(bar);

		SetBarStime();
		SetNoteValues();
		SetBarID();

	}//end FromDio

};//endclass Mono


inline void WriteMIDIFor3Monos(Mono mono1,Mono mono2,Mono mono3,string filename,double secPerQN){
	assert(mono1.bars.size()==mono2.bars.size());
	assert(mono1.bars.size()==mono3.bars.size());
		PianoRoll pr,pr1,pr2,pr3;
		pr1=mono1.ToPianoRoll(secPerQN);
		pr2=mono2.ToPianoRoll(secPerQN);
		pr3=mono3.ToPianoRoll(secPerQN);
		pr=pr1;
		for(int n=0;n<pr2.evts.size();n+=1){
			if(pr2.evts[n].channel!=0){continue;}
			pr2.evts[n].channel=3;
			pr.evts.push_back(pr2.evts[n]);
		}//endfor n
		for(int n=0;n<pr3.evts.size();n+=1){
			if(pr3.evts[n].channel!=0){continue;}
			pr3.evts[n].channel=6;
			pr.evts.push_back(pr3.evts[n]);
		}//endfor n
		pr.programChangeData.assign(16,56);//trumpets
		pr.WriteMIDIFile(filename);
}//end WriteMIDIFor3Monos



class MonoRhythmBar{
public:
	int ID;
	int length;
	vector<int> onsetVector;//size=length
	vector<int> notevalues;
	int stime;
};//endclass MonoRhythmBar

class MonoRhythm{
public:
	int TPQN;
	vector<MonoRhythmBar> bars;

	void WriteFile(string filename){
		ofstream ofs(filename.c_str());
		ofs<<"//TPQN: "<<TPQN<<"\n";
		for(int i=0;i<bars.size();i+=1){
			ofs<<bars[i].ID<<"\t"<<bars[i].length<<"\t";
			for(int j=0;j<bars[i].onsetVector.size();j+=1){
				ofs<<bars[i].onsetVector[j]<<" ";
			}//endfor j
			ofs<<"\n";
		}//endfor i
		ofs.close();
	}//end WriteFile

	void ReadFile(string filename){
		bars.clear();
		vector<int> v(100);
		vector<double> d(100);
		vector<string> s(100);
		MonoRhythmBar bar;
		ifstream ifs(filename.c_str());
		while(ifs>>s[0]){
			if(s[0]=="//TPQN:"){
				ifs>>TPQN;
				getline(ifs,s[99]);
				continue;
			}else if(s[0][0]=='/' || s[0][0]=='#'){
				getline(ifs,s[99]);
				continue;
			}//endif
			bar.ID=atoi(s[0].c_str());
			ifs>>bar.length;
			bar.onsetVector.resize(bar.length);
			for(int i=0;i<bar.length;i+=1){
				ifs>>bar.onsetVector[i];
			}//endfor i
			bars.push_back(bar);
			getline(ifs,s[99]);
		}//endwhile
		ifs.close();
	}//end ReadFile

	void ConvertFromMono(Mono mono){
		TPQN=mono.TPQN;
		bars.resize(mono.bars.size());
		for(int m=0;m<bars.size();m+=1){
			bars[m].ID=mono.bars[m].ID;
			bars[m].length=mono.bars[m].length;
			bars[m].onsetVector.assign(bars[m].length,0);
			for(int n=0;n<mono.bars[m].notes.size();n+=1){
				if(mono.bars[m].notes[n].sitch=="rest"){continue;}
				bars[m].onsetVector[mono.bars[m].notes[n].beatpos]=1;
			}//endfor n
			if(mono.bars[m].tied){bars[m].onsetVector[0]=0;}
			bars[m].stime=mono.bars[m].stime;
		}//endfor m
	}//end ConvertFromMono

	void SetNoteValues(){
		vector<int> lastNotePos;//m,n
		lastNotePos.assign(2,-1);
		for(int m=0;m<bars.size();m+=1){
			bars[m].notevalues.clear();
			vector<int> stimes;
			for(int b=0;b<bars[m].length;b+=1){
				if(bars[m].onsetVector[b]!=0){stimes.push_back(b);}
			}//endfor b
			if(stimes.size()==0){
				if(lastNotePos[0]!=-1){bars[lastNotePos[0]].notevalues[lastNotePos[1]]+=bars[m].length;}
			}else{
				if(stimes[0]>0){//tied note
					if(lastNotePos[0]!=-1){bars[lastNotePos[0]].notevalues[lastNotePos[1]]+=stimes[0];}
				}//endif
				for(int i=0;i<stimes.size();i+=1){
					if(i==stimes.size()-1){
						bars[m].notevalues.push_back(bars[m].length-stimes[i]);
					}else{
						bars[m].notevalues.push_back(stimes[i+1]-stimes[i]);
					}//endif
				}//endfor i
				lastNotePos[0]=m;
				lastNotePos[1]=stimes.size()-1;
			}//endif
		}//endfor m
	}//end SetNoteValues

	void KeepOnlyConstantBarLength(int length_){
		for(int m=bars.size()-1;m>=0;m-=1){
			if(bars[m].length!=length_){bars.erase(bars.begin()+m);}
		}//endfor m
	}//end KeepOnlyConstantBarLength

	void DivideBars(){
		vector<MonoRhythmBar> old_bars;
		MonoRhythmBar bar;
		old_bars=bars;
		bars.clear();
		for(int m=0;m<old_bars.size();m+=1){
			assert(old_bars[m].length%2==0);
			bar.ID=old_bars[m].ID;
			bar.length=old_bars[m].length/2;
			bar.onsetVector.assign(bar.length,0);
			for(int b=0;b<bar.length;b+=1){
				bar.onsetVector[b]=old_bars[m].onsetVector[b];
			}//endfor b
			bars.push_back(bar);

			bar.onsetVector.assign(bar.length,0);
			for(int b=0;b<bar.length;b+=1){
				bar.onsetVector[b]=old_bars[m].onsetVector[b+bar.length];
			}//endfor b
			bars.push_back(bar);
		}//endfor m
	}//end DivideBars

	void EraseWholeRests(){
		int nOnsets=0;
		for(int m=bars.size()-1;m>=0;m-=1){
			nOnsets=0;
			for(int b=0;b<bars[m].onsetVector.size();b+=1){
				nOnsets+=bars[m].onsetVector[b];
			}//endfor b
			if(nOnsets==0){bars.erase(bars.begin()+m);}
		}//endfor m
	}//end EraseWholeRests

	void CutBarsWithTooLongNotes(){
		int preBarLastNoteBeatpos=0;
		int curBarFirstNoteBeatpos=0;
		for(int m=1;m<bars.size();m+=1){
			preBarLastNoteBeatpos=-1;
			for(int b=bars[m-1].length-1;b>=0;b-=1){
				if(bars[m-1].onsetVector[b]!=0){
					preBarLastNoteBeatpos=b;
					break;
				}//endif
			}//endfor b
			curBarFirstNoteBeatpos=bars[m].length-1;
			for(int b=0;b<bars[m].length;b+=1){
				if(bars[m].onsetVector[b]!=0){
					curBarFirstNoteBeatpos=b;
					break;
				}//endif
			}//endfor b
			if(curBarFirstNoteBeatpos>preBarLastNoteBeatpos){bars[m].onsetVector[0]=1;}
		}//endfor m
	}//end CutBarsWithTooLongNotes

};//endclass MonoRhythm

#endif // Mono_HPP
