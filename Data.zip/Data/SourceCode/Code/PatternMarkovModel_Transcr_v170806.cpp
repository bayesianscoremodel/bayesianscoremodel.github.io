#include<fstream>
#include<iostream>
#include<cmath>
#include<string>
#include<sstream>
#include<vector>
#include<algorithm>
#include"stdio.h"
#include"stdlib.h"
#include"PatternMarkovModel_v170803.hpp"
using namespace std;

int main(int argc, char** argv){
	vector<int> v(100);
	vector<double> d(100);
	vector<string> s(100);
	stringstream ss;
	clock_t start, end;
	start = clock();

	if(argc!=7){
		cout<<"Error in usage: $./this order param.txt perfmdata.txt out_transcr.txt sig_t(-1) linearInterpolateCoeff(0)"<<endl;
		return -1;
	}//endif

	int order=atoi(argv[1]);
	string paramfile=string(argv[2]);
	string perfmfile=string(argv[3]);
	string transcrfile=string(argv[4]);
	double sig_t=atof(argv[5]);
	double linearInterpolateCoeff=atof(argv[6]);

	assert(order>=0 && order<=1);

cout<<"#Output from NoteMarkovModel_Transcr_v170804"<<endl;
cout<<"#order: "<<order<<" paramfile: "<<paramfile<<" perfmfile: "<<perfmfile<<" transcrfile: "<<transcrfile<<" sig_t: "<<sig_t<<" linearInterpolateCoeff: "<<linearInterpolateCoeff<<endl;

	if(order==1){

		PatternMarkovModel model;
		model.ReadFile(paramfile);
		model.LinearInterpolate(linearInterpolateCoeff);
		model.ReadPerfmData(perfmfile);
		if(sig_t>0){model.sig_t=sig_t;}
		model.Transcribe();
		model.WritePerfmData(transcrfile);
// cout<<model.sig_t<<"\t"<<model.secPerTick<<endl;

	}else if(order==0){

		PatternMarkovModel_0th model;
		model.ReadFile(paramfile);
		model.ReadPerfmData(perfmfile);
		if(sig_t>0){model.sig_t=sig_t;}
		model.Transcribe();
		model.WritePerfmData(transcrfile);
// cout<<model.sig_t<<"\t"<<model.secPerTick<<endl;

	}//endif



//	end = clock(); cout<<"Elapsed time : "<<((double)(end - start) / CLOCKS_PER_SEC)<<" sec"<<endl; start=end;
	return 0;
}//end main
