#ifndef NoteMarkovModel_HPP
#define NoteMarkovModel_HPP

#include<iostream>
#include<iomanip>
#include<fstream>
#include<string>
#include<sstream>
#include<vector>
#include<stdio.h>
#include<stdlib.h>
#include<cfloat>
#include<cmath>
#include<cassert>
#include<algorithm>
#include<boost/math/distributions.hpp> 
#include<boost/random.hpp>
#include"BasicCalculation_v170122.hpp"
#include"Mono_v170731.hpp"

#define EPS (0.1)
#define PRINTON false

using namespace std;


class NoteMarkovModel_0th{
public:

	int nBeat;//Beat resolution
	/// Identify nvID=0,...,nBeat-1 as nv=1,...,nBeat
	Prob<int> uniProb;

	vector<double> uniDirParam;

	vector<vector<vector<int> > > beatPosData;//piece,bar,note
	vector<vector<int> > data;//piece,note. Described with nvID!!
	int nPiece;
	int nBar;
	int nNote;

	vector<vector<int> > stimes;//Score data: [piece,note] score times
	vector<vector<double> > ontimes;//Performance data: [piece,note] onset times (sec)
	double TPQN;
	double bpm;//[QN/min] (ref:144)
	double sig_t;//[sec] (ref=0.02)
	double secPerTick;//=secPerQN/TPQN

	string paramFolder;

	NoteMarkovModel_0th(){
		paramFolder="./param/";
	}//end NoteMarkovModel_0th
	~NoteMarkovModel_0th(){
	}//end ~NoteMarkovModel_0th

	void RandomInit(int nBeat_){
		nBeat=nBeat_;
		uniProb.Resize(nBeat);
		uniProb.Randomize();
		uniDirParam.assign(nBeat,1);
	}//end RandomInit

	void WriteFile(string filename){
		ofstream ofs(filename.c_str());
		ofs<<"//BeatResolution: "<<nBeat<<"\n";

		ofs<<"### Unigram Prob\n";
		for(int b=0;b<nBeat;b+=1){
ofs<<uniProb.P[b]<<"\t";
		}//endfor b
ofs<<"\n";

		ofs.close();
	}//end WriteFile

	void ReadFile(string filename){
		vector<int> v(100);
		vector<double> d(100);
		vector<string> s(100);
		stringstream ss;

		ifstream ifs(filename.c_str());
		ifs>>s[1]>>nBeat;
		getline(ifs,s[99]);

		RandomInit(nBeat);

		getline(ifs,s[99]);//### Unigram Prob
		for(int b=0;b<nBeat;b+=1){
			ifs>>uniProb.P[b];
		}//endfor b
		getline(ifs,s[99]);
		uniProb.Normalize();

		ifs.close();
	}//end ReadFile

	void SetParamFolder(string folder){
		paramFolder=folder+"/";
		stringstream ss;
		ss.str(""); ss<<"mkdir "<<paramFolder;
		system(ss.str().c_str());
	}//end 

	void ReadData(string filename,int pieceID=-1,double dataCutFac=-1,int mode=0){
		vector<int> v(100);
		vector<double> d(100);
		vector<string> s(100);
		stringstream ss;

		beatPosData.clear();
		data.clear();

		vector<int> vi;
		vector<int> notes;
		vector<vector<int> > piece;
		vi.resize(nBeat);
		ifstream ifs(filename.c_str());
		getline(ifs,s[99]);//TPQN
		while(ifs>>s[1]){
			if(s[1][0]=='/'){
				if(piece.size()!=0){
					beatPosData.push_back(piece);
				}//endif
				piece.clear();
				getline(ifs,s[99]);
				continue;
			}//endif

			ifs>>v[1];
			if(v[1]!=nBeat){
				getline(ifs,s[99]);
				continue;
			}//endif
			for(int b=0;b<nBeat;b+=1){
				ifs>>vi[b];
			}//endfor b
			notes.clear();
			for(int b=0;b<nBeat;b+=1){
				if(vi[b]!=0){notes.push_back(b);}
			}//endfor b
			assert(notes.size()>0);
			piece.push_back(notes);
			getline(ifs,s[99]);
		}//endwhile
		if(piece.size()!=0){
			beatPosData.push_back(piece);
		}//endif
		ifs.close();

		data.resize(beatPosData.size());
		for(int l=0;l<beatPosData.size();l+=1){
			for(int m=0;m<beatPosData[l].size();m+=1){
				if(m>0){
					data[l].push_back(beatPosData[l][m][0]-beatPosData[l][m-1][beatPosData[l][m-1].size()-1]+nBeat-1);
				}//endif
				for(int n=1;n<beatPosData[l][m].size();n+=1){
					data[l].push_back(beatPosData[l][m][n]-beatPosData[l][m][n-1]-1);
				}//endfor n
			}//endfor m
		}//endfor l

		SelectPiece(pieceID);
		CutData(dataCutFac,mode);

		nPiece=data.size();
		nBar=0;
		nNote=0;
		for(int l=0;l<nPiece;l+=1){
			nBar+=beatPosData[l].size();
			nNote+=data[l].size();
		}//endfor l
cout<<"#nPiece,nBar,nNote:\t"<<nPiece<<"\t"<<nBar<<"\t"<<nNote<<endl;
	}//end ReadData

	void SelectPiece(int pieceID){
		if(pieceID<0){return;}
		assert(pieceID>=0 && pieceID<data.size());
		for(int l=data.size()-1;l>pieceID;l-=1){
			data.erase(data.begin()+l);
			beatPosData.erase(beatPosData.begin()+l);
		}//endfor l
		for(int l=pieceID-1;l>=0;l-=1){
			data.erase(data.begin()+l);
			beatPosData.erase(beatPosData.begin()+l);
		}//endfor l

		nPiece=data.size();
		nBar=0;
		nNote=0;
		for(int l=0;l<nPiece;l+=1){
			nBar+=beatPosData[l].size();
			nNote+=data[l].size();
		}//endfor l
	}//end SelectPiece

	void CutData(double dataCutFactor,int mode=0){
		if(dataCutFactor<0){return;}
		//mode = 0(keep first), 1(keep the rest)
		int cutPos;
		for(int l=0;l<beatPosData.size();l+=1){
			cutPos=int(beatPosData[l].size()*dataCutFactor);
			if(mode==0){
				//Keep m=0,...,cutPos-1
				for(int m=beatPosData[l].size()-1;m>=cutPos;m-=1){
					beatPosData[l].erase(beatPosData[l].begin()+m);
				}//endfor m
			}else{
				//Keep m=cutPos,...,=data[l].size()-1
				for(int m=cutPos-1;m>=0;m-=1){
					beatPosData[l].erase(beatPosData[l].begin()+m);
				}//endfor m
			}//endif
		}//endfor l

		data.clear();
		data.resize(beatPosData.size());
		for(int l=0;l<beatPosData.size();l+=1){
			for(int m=0;m<beatPosData[l].size();m+=1){
				if(m>0){
					data[l].push_back(beatPosData[l][m][0]-beatPosData[l][m-1][beatPosData[l][m-1].size()-1]+nBeat-1);
				}//endif
				for(int n=1;n<beatPosData[l][m].size();n+=1){
					data[l].push_back(beatPosData[l][m][n]-beatPosData[l][m][n-1]-1);
				}//endfor n
			}//endfor m
		}//endfor l

		nPiece=data.size();
		nBar=0;
		nNote=0;
		for(int l=0;l<nPiece;l+=1){
			nBar+=beatPosData[l].size();
			nNote+=data[l].size();
		}//endfor l
	}//end CutData

	void WritePerfmData(string filename){
		ofstream ofs(filename.c_str());
		ofs<<"//BeatResolution: "<<nBeat<<"\n";
		ofs<<"//TPQN: "<<TPQN<<"\n";
		ofs<<"//BPM: "<<bpm<<"\n";
		ofs<<"//sig_t: "<<sig_t<<"\n";

		for(int l=0;l<stimes.size();l+=1){
			ofs<<"### "<<l<<"\t"<<stimes[l].size()<<"\n";
			for(int n=0;n<stimes[l].size();n+=1){
ofs<<stimes[l][n]<<"\t"<<ontimes[l][n]<<"\n";
			}//endfor n
		}//endfor l

		ofs.close();
	}//end WritePerfmData

	void ReadPerfmData(string filename){
		vector<int> v(100);
		vector<double> d(100);
		vector<string> s(100);
		stringstream ss;

		ifstream ifs(filename.c_str());
		getline(ifs,s[99]);//nBeat
		ifs>>s[1]>>TPQN;
		getline(ifs,s[99]);
		ifs>>s[1]>>bpm;
		getline(ifs,s[99]);
		ifs>>s[1]>>sig_t;
		getline(ifs,s[99]);

		vector<int> vi;
		vector<double> vd;
		while(ifs>>s[0]){
			if(s[0]=="###"){
				vi.clear();
				vd.clear();
				ifs>>v[11]>>v[12];
				for(int n=0;n<v[12];n+=1){
					ifs>>v[1]>>d[2];
					vi.push_back(v[1]);
					vd.push_back(d[2]);
				}//endfor n
				stimes.push_back(vi);
				ontimes.push_back(vd);
			}//endif
			getline(ifs,s[99]);
		}//endwhile
		ifs.close();

		secPerTick=(60./bpm)/TPQN;
	}//end ReadPerfmData

	void LearnAdditiveSmoothing(double fac=0.1){
		uniProb.P.assign(nBeat,fac);
		for(int l=0;l<data.size();l+=1){
			for(int n=0;n<data[l].size();n+=1){
				uniProb.P[data[l][n]]+=1;
			}//endfor n
		}//endfor l
		uniProb.Normalize();
	}//end LearnAdditiveSmoothing

	void SetDirParam(double alpha){
		for(int b=0;b<nBeat;b+=1){
			uniDirParam[b]=alpha*uniProb.P[b];
		}//endfor b
	}//end SetDirParam

	void MAP(double fac=0.1){
		/// MAP estimation for the parameters
		/// Should be used after setting uniDirParam
		for(int b=0;b<nBeat;b+=1){
			uniProb.P[b]=uniDirParam[b]-1;
		}//endfor b
		for(int l=0;l<data.size();l+=1){
			for(int n=0;n<data[l].size();n+=1){
				uniProb.P[data[l][n]]+=1;
			}//endfor n
		}//endfor l
		for(int b=0;b<nBeat;b+=1){
			if(uniProb.P[b]<0){uniProb.P[b]=fac;}
		}//endfor b
		uniProb.Normalize();
	}//end MAP

	double GetLP(){
		double LP=0;
		for(int l=0;l<data.size();l+=1){
			for(int n=0;n<data[l].size();n+=1){
				LP+=uniProb.LP[data[l][n]];
			}//endfor n
		}//endfor l
		return LP;
	}//end GetLP

	double OutLP(int nvID,double dur){
		return -0.5*pow((dur-(nvID+1)*secPerTick)/sig_t,2.);
	}//end OutLP

	void Transcribe(){
		for(int l=0;l<ontimes.size();l+=1){
//cout<<"Transcribe -- "<<(l+1)<<"/"<<ontimes.size()<<endl;

			vector<int> optNVID(ontimes[l].size()-1);

			int amax;
			double maxLP;
			double logP;
			double dur;
			for(int n=1;n<ontimes[l].size();n+=1){
				dur=ontimes[l][n]-ontimes[l][n-1];
				amax=0;
				maxLP=uniProb.LP[0]+OutLP(0,dur);
				for(int b=1;b<nBeat;b+=1){
					logP=uniProb.LP[b]+OutLP(b,dur);
					if(logP>maxLP){
						maxLP=logP;
						amax=b;
					}//endif
				}//endfor b
				optNVID[n-1]=amax;
			}//endfor n

			for(int n=1;n<ontimes[l].size();n+=1){
				stimes[l][n]=stimes[l][n-1]+optNVID[n-1]+1;
			}//endfor n
		}//endfor l
	}//end Transcribe


	void BayesTranscribe(int nIter=10, int seed=2){
		/// Should be used after setting Dirichlet parameters
		boost::mt19937 gen;
		gen.seed(seed);

		Prob<int> genUniProb(uniProb);

		for(int l=0;l<ontimes.size();l+=1){
if(PRINTON){cout<<"BayesTranscribe -- "<<(l+1)<<"/"<<ontimes.size()<<endl;}

			uniProb=genUniProb;
			Prob<int> maxUniProb(uniProb);
			double evidLP;
			double maxEvidLP;
			int maxIter;
			double dur;

			///Gibbs sampling
			for(int iter=0;iter<nIter;iter+=1){

				///Sample scores by forward-filtering backward sampling
				vector<int> sampledNVIDs(ontimes[l].size()-1);
				Prob<int> prob(uniProb);

				evidLP=0;
				double evidLPPart;
				for(int n=0;n<ontimes[l].size()-1;n+=1){
					dur=ontimes[l][n+1]-ontimes[l][n];
					evidLPPart=-DBL_MAX;
					for(int b=0;b<nBeat;b+=1){
						prob.LP[b]=uniProb.LP[b]+OutLP(b,dur);
						evidLPPart=LogAdd(evidLPPart,prob.LP[b]);
					}//endfor b
					evidLP+=evidLPPart;
					prob.LogNormalize();
					sampledNVIDs[n]=SampleDistr(prob.P);
				}//endfor n

				if(iter==0){
					maxEvidLP=evidLP;
					maxUniProb=uniProb;
					maxIter=iter;
				}else if(evidLP>maxEvidLP){
					maxEvidLP=evidLP;
					maxUniProb=uniProb;
					maxIter=iter;
				}//endif
if(PRINTON){cout<<"Iteration: "<<iter<<"\t-NORM(evidLP,maxEvidLP): "<<-evidLP/double(ontimes[l].size()-1)<<"\t"<<-maxEvidLP/double(ontimes[l].size()-1)<<"\t"<<((evidLP==maxEvidLP)? "******":"")<<endl;}

				///Sample parameters
				uniProb.P=uniDirParam;
				for(int n=0;n<ontimes[l].size()-1;n+=1){
					uniProb.P[sampledNVIDs[n]]+=1;
				}//endfor n

				for(int b=0;b<nBeat;b+=1){
					boost::gamma_distribution<> dst( uniProb.P[b], 1. );
					boost::variate_generator<boost::mt19937&, boost::gamma_distribution<> > gamma_rand( gen, dst );
					uniProb.P[b]=gamma_rand();
				}//endfor b
				uniProb.Normalize();

			}//endfor iter

			///Set optimal parameter
			uniProb=maxUniProb;

			///Final transcription
			vector<int> optNVID(ontimes[l].size()-1);

			int amax;
			double maxLP;
			double logP;
			for(int n=1;n<ontimes[l].size();n+=1){
				dur=ontimes[l][n]-ontimes[l][n-1];
				amax=0;
				maxLP=uniProb.LP[0]+OutLP(0,dur);
				for(int b=1;b<nBeat;b+=1){
					logP=uniProb.LP[b]+OutLP(b,dur);
					if(logP>maxLP){
						maxLP=logP;
						amax=b;
					}//endif
				}//endfor b
				optNVID[n-1]=amax;
			}//endfor n

			for(int n=1;n<ontimes[l].size();n+=1){
				stimes[l][n]=stimes[l][n-1]+optNVID[n-1]+1;
			}//endfor n

			///Write piece-specific parameter file
			stringstream ss;
			ss.str(""); ss<<paramFolder<<"param_noteMM0B_"<<l<<".txt";
			WriteFile(ss.str());

		}//endfor l
	}//end BayesTranscribe


};//endclass NoteMarkovModel_0th




class NoteMarkovModel : public NoteMarkovModel_0th{
public:
// 	int nBeat;//Beat resolution
// 	/// Identify nvID=0,...,nBeat-1 as nv=1,...,nBeat
// 	Prob<int> uniProb;
	Prob<int> iniProb;
	vector<Prob<int> > trProb;//(nBeat x nBeat)

	vector<double> iniDirParam;
	vector<vector<double> > trDirParam;

	NoteMarkovModel(){
		paramFolder="./param/";
	}//end NoteMarkovModel
	~NoteMarkovModel(){
	}//end ~NoteMarkovModel

	void RandomInit(int nBeat_){
		nBeat=nBeat_;
		uniProb.Resize(nBeat);
		uniProb.Randomize();
		uniDirParam.assign(nBeat,1);
		iniProb.Resize(nBeat);
		iniProb.Randomize();
		iniDirParam.assign(nBeat,1);
		trProb.resize(nBeat);
		trDirParam.resize(nBeat);
		for(int b=0;b<nBeat;b+=1){
			trProb[b].Resize(nBeat);
			trProb[b].Randomize();
			trDirParam[b].assign(nBeat,1);
		}//endfor b
	}//end RandomInit

	void WriteFile(string filename){
		ofstream ofs(filename.c_str());
		ofs<<"//BeatResolution: "<<nBeat<<"\n";

		ofs<<"### Unigram Prob\n";
		for(int b=0;b<nBeat;b+=1){
ofs<<uniProb.P[b]<<"\t";
		}//endfor b
ofs<<"\n";

		ofs<<"### Init Prob\n";
		for(int b=0;b<nBeat;b+=1){
ofs<<iniProb.P[b]<<"\t";
		}//endfor b
ofs<<"\n";

		ofs<<"### Transition Prob\n";
		for(int b=0;b<nBeat;b+=1){
			for(int b_=0;b_<nBeat;b_+=1){
ofs<<trProb[b].P[b_]<<"\t";
			}//endfor b_
ofs<<"\n";
		}//endfor b

		ofs.close();
	}//end WriteFile

	void ReadFile(string filename){
		vector<int> v(100);
		vector<double> d(100);
		vector<string> s(100);
		stringstream ss;

		ifstream ifs(filename.c_str());
		ifs>>s[1]>>nBeat;
		getline(ifs,s[99]);

		RandomInit(nBeat);

		getline(ifs,s[99]);//### Unigram Prob
		for(int b=0;b<nBeat;b+=1){
			ifs>>uniProb.P[b];
		}//endfor b
		getline(ifs,s[99]);
		uniProb.Normalize();

		getline(ifs,s[99]);//### Init Prob
		for(int b=0;b<nBeat;b+=1){
			ifs>>iniProb.P[b];
		}//endfor b
		getline(ifs,s[99]);
		iniProb.Normalize();

		getline(ifs,s[99]);//### Transition Prob
		for(int b=0;b<nBeat;b+=1){
			for(int b_=0;b_<nBeat;b_+=1){
				ifs>>trProb[b].P[b_];
			}//endfor b_
			getline(ifs,s[99]);
			trProb[b].Normalize();
		}//endfor b

		ifs.close();
	}//end ReadFile

	void LearnAdditiveSmoothing(double fac=0.1){
		uniProb.P.assign(nBeat,fac);
		for(int l=0;l<data.size();l+=1){
			for(int n=0;n<data[l].size();n+=1){
				uniProb.P[data[l][n]]+=1;
			}//endfor n
		}//endfor l
		uniProb.Normalize();

		iniProb.P.assign(nBeat,fac);
		trProb.resize(nBeat);
		for(int b=0;b<nBeat;b+=1){
			trProb[b].P.assign(nBeat,fac);
		}//endfor b

		for(int l=0;l<data.size();l+=1){
			iniProb.P[data[l][0]]+=1;
			for(int n=1;n<data[l].size();n+=1){
				trProb[data[l][n-1]].P[data[l][n]]+=1;
			}//endfor n
		}//endfor l

		iniProb.Normalize();
		for(int b=0;b<nBeat;b+=1){
			trProb[b].Normalize();
		}//endfor b
	}//end LearnAdditiveSmoothing

	void SetDirParam(double alpha){
		for(int b=0;b<nBeat;b+=1){
			iniDirParam[b]=alpha*iniProb.P[b];
			for(int bp=0;bp<nBeat;bp+=1){
				trDirParam[b][bp]=alpha*trProb[b].P[bp];
			}//endfor bp
		}//endfor b
	}//end SetDirParam

	void MAP(double fac=0.1){
		/// MAP estimation for the parameters
		/// Should be used after setting uniDirParam
		for(int b=0;b<nBeat;b+=1){
			iniProb.P[b]=iniDirParam[b]-1;
			for(int bp=0;bp<nBeat;bp+=1){
				trProb[b].P[bp]=trDirParam[b][bp]-1;
			}//endfor bp
		}//endfor b

		for(int l=0;l<data.size();l+=1){
			iniProb.P[data[l][0]]+=1;
			for(int n=1;n<data[l].size();n+=1){
				trProb[data[l][n-1]].P[data[l][n]]+=1;
			}//endfor n
		}//endfor l

		for(int b=0;b<nBeat;b+=1){
			if(iniProb.P[b]<0){iniProb.P[b]=fac;}
			for(int bp=0;bp<nBeat;bp+=1){
				if(trProb[b].P[bp]<0){trProb[b].P[bp]=fac;}
			}//endfor bp
		}//endfor b

		iniProb.Normalize();
		for(int b=0;b<nBeat;b+=1){
			trProb[b].Normalize();
		}//endfor b
	}//end MAP

	double GetLP(){
		double LP=0;
		for(int l=0;l<data.size();l+=1){
			LP+=iniProb.LP[data[l][0]];
			for(int n=1;n<data[l].size();n+=1){
				LP+=trProb[data[l][n-1]].LP[data[l][n]];
			}//endfor n
		}//endfor l
		return LP;
	}//end GetLP


	void Transcribe(){
		for(int l=0;l<ontimes.size();l+=1){
//cout<<"Transcribe -- "<<(l+1)<<"/"<<ontimes.size()<<endl;

			///Viterbi
			vector<int> optNVID(ontimes[l].size()-1);

			vector<double> LP(nBeat);
			vector<vector<int> > amax;
			amax.resize(ontimes[l].size()-1);
			for(int n=0;n<ontimes[l].size()-1;n+=1){amax[n].resize(nBeat);}

			/// ///Initialization
			double dur;
			dur=ontimes[l][1]-ontimes[l][0];
			for(int b=0;b<nBeat;b+=1){
				LP[b]=iniProb.LP[b]+OutLP(b,dur);
			}//endfor b

			/// ///Update
			double logP;
			for(int n=2;n<ontimes[l].size();n+=1){
				vector<double> preLP(LP);
				dur=ontimes[l][n]-ontimes[l][n-1];
				for(int b=0;b<nBeat;b+=1){
					LP[b]=preLP[0]+trProb[0].LP[b]+OutLP(b,dur);
					amax[n-1][b]=0;
					for(int bp=1;bp<nBeat;bp+=1){
						logP=preLP[bp]+trProb[bp].LP[b]+OutLP(b,dur);
						if(logP>LP[b]){
							LP[b]=logP;
							amax[n-1][b]=bp;
						}//endif
					}//endfor bp
				}//endfor b
			}//endfor n

			/// ///Backtracking and set stimes
			optNVID[optNVID.size()-1]=0;
			for(int b=1;b<nBeat;b+=1){
				if(LP[b]>LP[optNVID[optNVID.size()-1]]){
					optNVID[optNVID.size()-1]=b;
				}//endif
			}//endfor b
			for(int n=optNVID.size()-2;n>=0;n-=1){
				optNVID[n]=amax[n+1][optNVID[n+1]];
			}//endfor n

			for(int n=1;n<ontimes[l].size();n+=1){
				stimes[l][n]=stimes[l][n-1]+optNVID[n-1]+1;
			}//endfor n
		}//endfor l
	}//end Transcribe

	void BayesTranscribe(int nIter=10, int seed=2){
		/// Should be used after setting Dirichlet parameters
		boost::mt19937 gen;
		gen.seed(seed);
		Prob<int> genIniProb(iniProb);
		vector<Prob<int> > genTrProb(trProb);//(nBeat x nBeat)

		for(int l=0;l<ontimes.size();l+=1){
if(PRINTON){cout<<"BayesTranscribe -- "<<(l+1)<<"/"<<ontimes.size()<<endl;}

			iniProb=genIniProb;
			trProb=genTrProb;
			Prob<int> maxIniProb(iniProb);
			vector<Prob<int> > maxTrProb(trProb);//(nBeat x nBeat)
			double evidLP;
			double maxEvidLP;
			int maxIter;
			double dur;

			///Gibbs sampling
			for(int iter=0;iter<nIter;iter+=1){

				///Sample scores by forward-filtering backward sampling
				vector<int> sampledNVIDs(ontimes[l].size()-1);
				vector<vector<double> > forwardVar;// ontimes[l].size()-1 x nBeat
				forwardVar.resize(ontimes[l].size()-1);
				for(int n=0;n<ontimes[l].size()-1;n+=1){forwardVar[n].assign(nBeat,-DBL_MAX);}


				/// //Forward
				dur=ontimes[l][1]-ontimes[l][0];
				for(int b=0;b<nBeat;b+=1){
					forwardVar[0][b]=iniProb.LP[b]+OutLP(b,dur);
				}//endfor b
				for(int n=1;n<ontimes[l].size()-1;n+=1){
					dur=ontimes[l][n+1]-ontimes[l][n];
					for(int b=0;b<nBeat;b+=1){
						for(int bp=0;bp<nBeat;bp+=1){
							forwardVar[n][b]=LogAdd(forwardVar[n][b],forwardVar[n-1][bp]+trProb[bp].LP[b]+OutLP(b,dur));
						}//endfor bp
					}//endfor b
				}//endfor n
				evidLP=-DBL_MAX;
				for(int b=0;b<nBeat;b+=1){
					evidLP=LogAdd(evidLP,forwardVar[ontimes[l].size()-2][b]);
				}//endfor b

				if(iter==0){
					maxEvidLP=evidLP;
					maxIniProb=iniProb;
					maxTrProb=trProb;
					maxIter=iter;
				}else if(evidLP>maxEvidLP){
					maxEvidLP=evidLP;
					maxIniProb=iniProb;
					maxTrProb=trProb;
					maxIter=iter;
				}//endif
if(PRINTON){cout<<"Iteration: "<<iter<<"\t-NORM(evidLP,maxEvidLP): "<<-evidLP/double(ontimes[l].size())<<"\t"<<-maxEvidLP/double(ontimes[l].size())<<"\t"<<((evidLP==maxEvidLP)? "******":"")<<endl;}

				/// //Backward sampling
				Prob<int> prob;
				prob.LP=forwardVar[ontimes[l].size()-2];
				prob.LogNormalize();
				sampledNVIDs[ontimes[l].size()-2]=SampleDistr(prob.P);

				for(int n=ontimes[l].size()-3;n>=0;n-=1){
					for(int b=0;b<nBeat;b+=1){
						prob.LP[b]=forwardVar[n][b]+trProb[b].LP[sampledNVIDs[n+1]];
					}//endfor b
					prob.LogNormalize();
					sampledNVIDs[n]=SampleDistr(prob.P);
				}//endfor n

				///Sample parameters
				iniProb.P=iniDirParam;
				iniProb.P[sampledNVIDs[0]]+=1;
				for(int b=0;b<nBeat;b+=1){
					boost::gamma_distribution<> dst( iniProb.P[b], 1. );
					boost::variate_generator<boost::mt19937&, boost::gamma_distribution<> > gamma_rand( gen, dst );
					iniProb.P[b]=gamma_rand();
				}//endfor b
				iniProb.Normalize();

				for(int b=0;b<nBeat;b+=1){
					trProb[b].P=trDirParam[b];
				}//endfor b
				for(int n=1;n<ontimes[l].size()-1;n+=1){
					trProb[sampledNVIDs[n-1]].P[sampledNVIDs[n]]+=1;
				}//endfor n
				for(int b=0;b<nBeat;b+=1){
					for(int bp=0;bp<nBeat;bp+=1){
						boost::gamma_distribution<> dst( trProb[b].P[bp], 1. );
						boost::variate_generator<boost::mt19937&, boost::gamma_distribution<> > gamma_rand( gen, dst );
						trProb[b].P[bp]=gamma_rand();
					}//endfor bp
					trProb[b].Normalize();
				}//endfor b

			}//endfor iter

			///Set optimal parameter
			iniProb=maxIniProb;
			trProb=maxTrProb;

			///Viterbi
			vector<int> optNVID(ontimes[l].size()-1);

			vector<double> LP(nBeat);
			vector<vector<int> > amax;
			amax.resize(ontimes[l].size()-1);
			for(int n=0;n<ontimes[l].size()-1;n+=1){amax[n].resize(nBeat);}

			/// ///Initialization
			dur=ontimes[l][1]-ontimes[l][0];
			for(int b=0;b<nBeat;b+=1){
				LP[b]=iniProb.LP[b]+OutLP(b,dur);
			}//endfor b

			/// ///Update
			double logP;
			for(int n=2;n<ontimes[l].size();n+=1){
				vector<double> preLP(LP);
				dur=ontimes[l][n]-ontimes[l][n-1];
				for(int b=0;b<nBeat;b+=1){
					LP[b]=preLP[0]+trProb[0].LP[b]+OutLP(b,dur);
					amax[n-1][b]=0;
					for(int bp=1;bp<nBeat;bp+=1){
						logP=preLP[bp]+trProb[bp].LP[b]+OutLP(b,dur);
						if(logP>LP[b]){
							LP[b]=logP;
							amax[n-1][b]=bp;
						}//endif
					}//endfor bp
				}//endfor b
			}//endfor n

			/// ///Backtracking and set stimes
			optNVID[optNVID.size()-1]=0;
			for(int b=1;b<nBeat;b+=1){
				if(LP[b]>LP[optNVID[optNVID.size()-1]]){
					optNVID[optNVID.size()-1]=b;
				}//endif
			}//endfor b
			for(int n=optNVID.size()-2;n>=0;n-=1){
				optNVID[n]=amax[n+1][optNVID[n+1]];
			}//endfor n

			for(int n=1;n<ontimes[l].size();n+=1){
				stimes[l][n]=stimes[l][n-1]+optNVID[n-1]+1;
			}//endfor n

			///Write piece-specific parameter file
			stringstream ss;
			ss.str(""); ss<<paramFolder<<"param_noteMM1B_"<<l<<".txt";
			WriteFile(ss.str());

		}//endfor l
	}//end BayesTranscribe



};//endclass NoteMarkovModel









class NoteMarkovModel_2nd : public NoteMarkovModel{
public:

// 	int nBeat;//Beat resolution
// 	/// Identify nvID=0,...,nBeat-1 as nv=1,...,nBeat
// 	Prob<int> uniProb;
	vector<Prob<int> > tr2Prob;//(nBeat x nBeat)
	Prob<int> iniProb;
	vector<Prob<int> > ini2Prob;//(nBeat x nBeat)
	vector<vector<Prob<int> > > trProb;//(nBeat x nBeat x nBeat)

	vector<double> iniDirParam;
	vector<vector<double> > ini2DirParam;//(nBeat x nBeat)
	vector<vector<vector<double> > > trDirParam;//(nBeat x nBeat x nBeat)

	NoteMarkovModel_2nd(){
		paramFolder="./param/";
	}//end NoteMarkovModel_2nd
	~NoteMarkovModel_2nd(){
	}//end ~NoteMarkovModel_2nd

	void RandomInit(int nBeat_){
		nBeat=nBeat_;
		uniProb.Resize(nBeat);
		uniProb.Randomize();
		tr2Prob.resize(nBeat);
		for(int b=0;b<nBeat;b+=1){
			tr2Prob[b].Resize(nBeat);
			tr2Prob[b].Randomize();
		}//endfor b

		iniProb.Resize(nBeat);
		iniProb.Randomize();
		iniDirParam.assign(nBeat,1);
		ini2Prob.resize(nBeat);
		ini2DirParam.resize(nBeat);
		trProb.resize(nBeat);
		trDirParam.resize(nBeat);
		for(int b=0;b<nBeat;b+=1){
			ini2Prob[b].Resize(nBeat);
			ini2Prob[b].Randomize();
			ini2DirParam[b].assign(nBeat,1);
			trProb[b].resize(nBeat);
			trDirParam[b].resize(nBeat);
			for(int bp=0;bp<nBeat;bp+=1){
				trProb[b][bp].Resize(nBeat);
				trProb[b][bp].Randomize();
				trDirParam[b][bp].assign(nBeat,1);
			}//endfor bp
		}//endfor b
	}//end RandomInit

	void WriteFile(string filename){
		ofstream ofs(filename.c_str());
		ofs<<"//BeatResolution: "<<nBeat<<"\n";

		ofs<<"### Unigram Prob\n";
		for(int b=0;b<nBeat;b+=1){
ofs<<uniProb.P[b]<<"\t";
		}//endfor b
ofs<<"\n";

		ofs<<"### Init Prob\n";
		for(int b=0;b<nBeat;b+=1){
ofs<<iniProb.P[b]<<"\t";
		}//endfor b
ofs<<"\n";

		ofs<<"### 1st Transition Prob\n";
		for(int b=0;b<nBeat;b+=1){
			for(int b_=0;b_<nBeat;b_+=1){
ofs<<tr2Prob[b].P[b_]<<"\t";
			}//endfor b_
ofs<<"\n";
		}//endfor b

		ofs<<"### 2nd Ini Prob\n";
		for(int b=0;b<nBeat;b+=1){
			for(int b_=0;b_<nBeat;b_+=1){
ofs<<ini2Prob[b].P[b_]<<"\t";
			}//endfor b_
ofs<<"\n";
		}//endfor b

		ofs<<"### 2nd Transition Prob\n";
		for(int b=0;b<nBeat;b+=1){
			for(int bp=0;bp<nBeat;bp+=1){
				for(int bpp=0;bpp<nBeat;bpp+=1){
ofs<<trProb[b][bp].P[bpp]<<"\t";
				}//endfor bpp
ofs<<"\n";
			}//endfor bp
		}//endfor b

		ofs.close();
	}//end WriteFile

	void ReadFile(string filename){
		vector<int> v(100);
		vector<double> d(100);
		vector<string> s(100);
		stringstream ss;

		ifstream ifs(filename.c_str());
		ifs>>s[1]>>nBeat;
		getline(ifs,s[99]);

		RandomInit(nBeat);

		getline(ifs,s[99]);//### Unigram Prob
		for(int b=0;b<nBeat;b+=1){
			ifs>>uniProb.P[b];
		}//endfor b
		getline(ifs,s[99]);
		uniProb.Normalize();

		getline(ifs,s[99]);//### Init Prob
		for(int b=0;b<nBeat;b+=1){
			ifs>>iniProb.P[b];
		}//endfor b
		getline(ifs,s[99]);
		iniProb.Normalize();

		getline(ifs,s[99]);//### 1st Transition Prob
		for(int b=0;b<nBeat;b+=1){
			for(int b_=0;b_<nBeat;b_+=1){
				ifs>>tr2Prob[b].P[b_];
			}//endfor b_
			getline(ifs,s[99]);
			tr2Prob[b].Normalize();
		}//endfor b

		getline(ifs,s[99]);//### ### 2nd Ini Prob
		for(int b=0;b<nBeat;b+=1){
			for(int bp=0;bp<nBeat;bp+=1){
				ifs>>ini2Prob[b].P[bp];
			}//endfor bp
			getline(ifs,s[99]);
			ini2Prob[b].Normalize();
		}//endfor b

		getline(ifs,s[99]);//### 2nd Transition Prob
		for(int b=0;b<nBeat;b+=1){
			for(int bp=0;bp<nBeat;bp+=1){
				for(int bpp=0;bpp<nBeat;bpp+=1){
					ifs>>trProb[b][bp].P[bpp];
				}//endfor bpp
				getline(ifs,s[99]);
				trProb[b][bp].Normalize();
			}//endfor bp
		}//endfor b

		ifs.close();
	}//end ReadFile

	void LinearInterpolate(double coeff=0.1){
		vector<vector<Prob<int> > > trProbRaw;//(nBeat x nBeat x nBeat)
		trProbRaw=trProb;
		for(int b=0;b<nBeat;b+=1){
			for(int bp=0;bp<nBeat;bp+=1){
				for(int bpp=0;bpp<nBeat;bpp+=1){
					trProb[b][bp].P[bpp]=(1-coeff)*trProbRaw[b][bp].P[bpp]+coeff*tr2Prob[bp].P[bpp];
				}//endfor bpp
				trProb[b][bp].Normalize();
			}//endfor bp
		}//endfor b
	}//end LinearInterpolate

	void LearnAdditiveSmoothing(double fac=0.1){
		uniProb.P.assign(nBeat,fac);
		for(int l=0;l<data.size();l+=1){
			for(int n=0;n<data[l].size();n+=1){
				uniProb.P[data[l][n]]+=1;
			}//endfor n
		}//endfor l
		uniProb.Normalize();

		tr2Prob.resize(nBeat);
		for(int b=0;b<nBeat;b+=1){
			tr2Prob[b].P.assign(nBeat,fac);
		}//endfor b
		for(int l=0;l<data.size();l+=1){
			for(int n=1;n<data[l].size();n+=1){
				tr2Prob[data[l][n-1]].P[data[l][n]]+=1;
			}//endfor n
		}//endfor l
		for(int b=0;b<nBeat;b+=1){
			tr2Prob[b].Normalize();
		}//endfor b

		iniProb.P.assign(nBeat,fac);
		ini2Prob.resize(nBeat);
		trProb.resize(nBeat);
		for(int b=0;b<nBeat;b+=1){
			ini2Prob[b].P.assign(nBeat,fac);
			trProb[b].resize(nBeat);
			for(int bp=0;bp<nBeat;bp+=1){
				trProb[b][bp].P.assign(nBeat,fac);
			}//endfor bp
		}//endfor b

		for(int l=0;l<data.size();l+=1){
			if(data[l].size()<=0){continue;}
			iniProb.P[data[l][0]]+=1;
			if(data[l].size()<=1){continue;}
			ini2Prob[data[l][0]].P[data[l][1]]+=1;
			if(data[l].size()<=2){continue;}
			for(int n=2;n<data[l].size();n+=1){
				trProb[data[l][n-2]][data[l][n-1]].P[data[l][n]]+=1;
			}//endfor n
		}//endfor l

		iniProb.Normalize();
		for(int b=0;b<nBeat;b+=1){
			ini2Prob[b].Normalize();
			for(int bp=0;bp<nBeat;bp+=1){
				trProb[b][bp].Normalize();
			}//endfor bp
		}//endfor b
	}//end LearnAdditiveSmoothing

	void SetDirParam(double alpha){
		for(int b=0;b<nBeat;b+=1){
			iniDirParam[b]=alpha*iniProb.P[b];
			for(int bp=0;bp<nBeat;bp+=1){
				ini2DirParam[b][bp]=alpha*ini2Prob[b].P[bp];
				for(int bpp=0;bpp<nBeat;bpp+=1){
					trDirParam[b][bp][bpp]=alpha*trProb[b][bp].P[bpp];
				}//endfor bpp
			}//endfor bp
		}//endfor b
	}//end SetDirParam

	double GetLP(){
		double LP=0;
		for(int l=0;l<data.size();l+=1){
			if(data[l].size()<=0){continue;}
			LP+=iniProb.LP[data[l][0]];
			if(data[l].size()<=1){continue;}
			LP+=ini2Prob[data[l][0]].LP[data[l][1]];
			if(data[l].size()<=2){continue;}
			for(int n=2;n<data[l].size();n+=1){
				LP+=trProb[data[l][n-2]][data[l][n-1]].LP[data[l][n]];
			}//endfor n
		}//endfor l
		return LP;
	}//end GetLP

	void Transcribe(){
		for(int l=0;l<ontimes.size();l+=1){
//cout<<"Transcribe -- "<<(l+1)<<"/"<<ontimes.size()<<endl;

			///Viterbi
			vector<int> optNVID(ontimes[l].size()-1);

			vector<vector<double> > LP;//nBeat x nBeat
			vector<vector<vector<int> > > amax;//ontimes[l].size()-1 x nBeat x nBeat
			LP.resize(nBeat);
			for(int b=0;b<nBeat;b+=1){LP[b].resize(nBeat);}
			amax.resize(ontimes[l].size()-1);
			for(int n=0;n<ontimes[l].size()-1;n+=1){
				amax[n].resize(nBeat);
				for(int b=0;b<nBeat;b+=1){amax[n][b].resize(nBeat);}
			}//endfor n

			/// ///Initialization
			double dur;
			dur=ontimes[l][1]-ontimes[l][0];
			double dur2;
			dur2=ontimes[l][2]-ontimes[l][1];
			for(int bp=0;bp<nBeat;bp+=1){
				for(int b=0;b<nBeat;b+=1){
					LP[bp][b]=iniProb.LP[bp]+OutLP(bp,dur)+ini2Prob[bp].LP[b]+OutLP(b,dur2);
				}//endfor b
			}//endfor bp

			/// ///Update
			double logP;
			for(int n=3;n<ontimes[l].size();n+=1){
				vector<vector<double> > preLP(LP);
				dur=ontimes[l][n]-ontimes[l][n-1];
				for(int b=0;b<nBeat;b+=1)for(int bp=0;bp<nBeat;bp+=1){
					LP[bp][b]=preLP[0][bp]+trProb[0][bp].LP[b]+OutLP(b,dur);
					amax[n-1][bp][b]=0;
					for(int bpp=1;bpp<nBeat;bpp+=1){
						logP=preLP[bpp][bp]+trProb[bpp][bp].LP[b]+OutLP(b,dur);
						if(logP>LP[bp][b]){
							LP[bp][b]=logP;
							amax[n-1][bp][b]=bpp;
						}//endif
					}//endfor bpp
				}//endfor b,bp
			}//endfor n

			/// ///Backtracking and set stimes
			optNVID[optNVID.size()-1]=0;
			optNVID[optNVID.size()-2]=0;
			for(int b=0;b<nBeat;b+=1)for(int bp=0;bp<nBeat;bp+=1){
				if(LP[bp][b]>LP[optNVID[optNVID.size()-2]][optNVID[optNVID.size()-1]]){
					optNVID[optNVID.size()-2]=bp;
					optNVID[optNVID.size()-1]=b;
				}//endif
			}//endfor b,bp
			for(int n=optNVID.size()-3;n>=0;n-=1){
				optNVID[n]=amax[n+2][optNVID[n+1]][optNVID[n+2]];
			}//endfor n

			for(int n=1;n<ontimes[l].size();n+=1){
				stimes[l][n]=stimes[l][n-1]+optNVID[n-1]+1;
			}//endfor n
		}//endfor l
	}//end Transcribe


	void BayesTranscribe(int nIter=10, int seed=2){
		/// Should be used after setting Dirichlet parameters
		boost::mt19937 gen;
		gen.seed(seed);

		Prob<int> genIniProb(iniProb);
		vector<Prob<int> > genIni2Prob(ini2Prob);//(nBeat x nBeat)
		vector<vector<Prob<int> > > genTrProb(trProb);//(nBeat x nBeat x nBeat)

		for(int l=0;l<ontimes.size();l+=1){
if(PRINTON){cout<<"BayesTranscribe -- "<<(l+1)<<"/"<<ontimes.size()<<endl;}
			assert(ontimes[l].size()>2);

			iniProb=genIniProb;
			ini2Prob=genIni2Prob;
			trProb=genTrProb;
			Prob<int> maxIniProb(iniProb);
			vector<Prob<int> > maxIni2Prob(ini2Prob);//(nBeat x nBeat)
			vector<vector<Prob<int> > > maxTrProb(trProb);//(nBeat x nBeat x nBeat)
			double evidLP;
			double maxEvidLP;
			int maxIter;
			double dur;

			///Gibbs sampling
			for(int iter=0;iter<nIter;iter+=1){

				///Sample scores by forward-filtering backward sampling
				vector<int> sampledNVIDs(ontimes[l].size()-1);
				vector<vector<vector<double> > > forwardVar;// ontimes[l].size()-1 x nBeat
				forwardVar.resize(ontimes[l].size()-1);

				/// //Forward
				for(int n=0;n<ontimes[l].size()-1;n+=1){
					forwardVar[n].resize(nBeat);
					for(int b=0;b<nBeat;b+=1){forwardVar[n][b].assign(nBeat,-DBL_MAX);}

					if(n==0){
						continue;
					}else if(n==1){
						dur=ontimes[l][n+1]-ontimes[l][n];
						for(int bp=0;bp<nBeat;bp+=1){for(int b=0;b<nBeat;b+=1){
							forwardVar[1][bp][b]=iniProb.LP[bp]+ini2Prob[bp].LP[b]+OutLP(b,dur);
						}}//endfor b,bp
						continue;
					}//endif

					dur=ontimes[l][n+1]-ontimes[l][n];

					for(int bp=0;bp<nBeat;bp+=1){for(int b=0;b<nBeat;b+=1){
						for(int bpp=0;bpp<nBeat;bpp+=1){
							forwardVar[n][bp][b]=LogAdd(forwardVar[n][bp][b],forwardVar[n-1][bpp][bp]+trProb[bpp][bp].LP[b]+OutLP(b,dur));
						}//endfor bpp
					}}//endfor b,bp

				}//endfor n

				evidLP=-DBL_MAX;
				for(int bp=0;bp<nBeat;bp+=1){for(int b=0;b<nBeat;b+=1){
					evidLP=LogAdd(evidLP,forwardVar[ontimes[l].size()-2][bp][b]);
				}}//endfor b,bp

				if(iter==0){
					maxEvidLP=evidLP;
					maxIniProb=iniProb;
					maxIni2Prob=ini2Prob;
					maxTrProb=trProb;
					maxIter=iter;
				}else if(evidLP>maxEvidLP){
					maxEvidLP=evidLP;
					maxIniProb=iniProb;
					maxIni2Prob=ini2Prob;
					maxTrProb=trProb;
					maxIter=iter;
				}//endif
if(PRINTON){cout<<"Iteration: "<<iter<<"\t-NORM(evidLP,maxEvidLP): "<<-evidLP/double(ontimes[l].size())<<"\t"<<-maxEvidLP/double(ontimes[l].size())<<"\t"<<((evidLP==maxEvidLP)? "******":"")<<endl;}

				/// //Backward sampling
				Prob<int> prob;
				prob.Resize(nBeat);
				for(int b=0;b<nBeat;b+=1){
					prob.LP[b]=-DBL_MAX;
					for(int bp=0;bp<nBeat;bp+=1){
						prob.LP[b]=LogAdd(prob.LP[b],forwardVar[ontimes[l].size()-2][bp][b]);
					}//endfor bp
				}//endfor b
				prob.LogNormalize();
				sampledNVIDs[ontimes[l].size()-2]=SampleDistr(prob.P);

				for(int b=0;b<nBeat;b+=1){
					prob.LP[b]=forwardVar[ontimes[l].size()-2][b][sampledNVIDs[ontimes[l].size()-2]];
				}//endfor b
				prob.LogNormalize();
				sampledNVIDs[ontimes[l].size()-3]=SampleDistr(prob.P);

				for(int n=ontimes[l].size()-4;n>=0;n-=1){
					for(int b=0;b<nBeat;b+=1){
						prob.LP[b]=forwardVar[n+1][b][sampledNVIDs[n+1]]+trProb[b][sampledNVIDs[n+1]].LP[sampledNVIDs[n+2]];
					}//endfor b
					prob.LogNormalize();
					sampledNVIDs[n]=SampleDistr(prob.P);
				}//endfor n

				///Sample parameters
				iniProb.P=iniDirParam;
				iniProb.P[sampledNVIDs[0]]+=1;
				for(int b=0;b<nBeat;b+=1){
					boost::gamma_distribution<> dst( iniProb.P[b], 1. );
					boost::variate_generator<boost::mt19937&, boost::gamma_distribution<> > gamma_rand( gen, dst );
					iniProb.P[b]=gamma_rand();
				}//endfor b
				iniProb.Normalize();

				for(int b=0;b<nBeat;b+=1){
					ini2Prob[b].P=ini2DirParam[b];
				}//endfor b
				ini2Prob[sampledNVIDs[0]].P[sampledNVIDs[1]]+=1;
				for(int b=0;b<nBeat;b+=1){
					for(int bp=0;bp<nBeat;bp+=1){
						boost::gamma_distribution<> dst( ini2Prob[b].P[bp], 1. );
						boost::variate_generator<boost::mt19937&, boost::gamma_distribution<> > gamma_rand( gen, dst );
						ini2Prob[b].P[bp]=gamma_rand();
					}//endfor bp
					ini2Prob[b].Normalize();
				}//endfor b

				for(int bp=0;bp<nBeat;bp+=1){for(int b=0;b<nBeat;b+=1){
					trProb[bp][b].P=trDirParam[bp][b];
				}}//endfor b,bp
				for(int n=2;n<ontimes[l].size()-1;n+=1){
					trProb[sampledNVIDs[n-2]][sampledNVIDs[n-1]].P[sampledNVIDs[n]]+=1;
				}//endfor n
				for(int bp=0;bp<nBeat;bp+=1){for(int b=0;b<nBeat;b+=1){
					for(int bpp=0;bpp<nBeat;bpp+=1){
						boost::gamma_distribution<> dst( trProb[bp][b].P[bpp], 1. );
						boost::variate_generator<boost::mt19937&, boost::gamma_distribution<> > gamma_rand( gen, dst );
						trProb[bp][b].P[bpp]=gamma_rand();
					}//endfor bpp
					trProb[bp][b].Normalize();
				}}//endfor b,bp

			}//endfor iter

			///Set optimal parameter
			iniProb=maxIniProb;
			ini2Prob=maxIni2Prob;
			trProb=maxTrProb;

			///Viterbi
			vector<int> optNVID(ontimes[l].size()-1);

			vector<vector<double> > LP;//nBeat x nBeat
			vector<vector<vector<int> > > amax;//ontimes[l].size()-1 x nBeat x nBeat
			LP.resize(nBeat);
			for(int b=0;b<nBeat;b+=1){LP[b].resize(nBeat);}
			amax.resize(ontimes[l].size()-1);
			for(int n=0;n<ontimes[l].size()-1;n+=1){
				amax[n].resize(nBeat);
				for(int b=0;b<nBeat;b+=1){amax[n][b].resize(nBeat);}
			}//endfor n

			/// ///Initialization
			dur=ontimes[l][1]-ontimes[l][0];
			double dur2=ontimes[l][2]-ontimes[l][1];
			for(int bp=0;bp<nBeat;bp+=1){
				for(int b=0;b<nBeat;b+=1){
					LP[bp][b]=iniProb.LP[bp]+OutLP(bp,dur)+ini2Prob[bp].LP[b]+OutLP(b,dur2);
				}//endfor b
			}//endfor bp

			/// ///Update
			double logP;
			for(int n=3;n<ontimes[l].size();n+=1){
				vector<vector<double> > preLP(LP);
				dur=ontimes[l][n]-ontimes[l][n-1];
				for(int b=0;b<nBeat;b+=1)for(int bp=0;bp<nBeat;bp+=1){
					LP[bp][b]=preLP[0][bp]+trProb[0][bp].LP[b]+OutLP(b,dur);
					amax[n-1][bp][b]=0;
					for(int bpp=1;bpp<nBeat;bpp+=1){
						logP=preLP[bpp][bp]+trProb[bpp][bp].LP[b]+OutLP(b,dur);
						if(logP>LP[bp][b]){
							LP[bp][b]=logP;
							amax[n-1][bp][b]=bpp;
						}//endif
					}//endfor bpp
				}//endfor b,bp
			}//endfor n

			/// ///Backtracking and set stimes
			optNVID[optNVID.size()-1]=0;
			optNVID[optNVID.size()-2]=0;
			for(int b=0;b<nBeat;b+=1)for(int bp=0;bp<nBeat;bp+=1){
				if(LP[bp][b]>LP[optNVID[optNVID.size()-2]][optNVID[optNVID.size()-1]]){
					optNVID[optNVID.size()-2]=bp;
					optNVID[optNVID.size()-1]=b;
				}//endif
			}//endfor b,bp
			for(int n=optNVID.size()-3;n>=0;n-=1){
				optNVID[n]=amax[n+2][optNVID[n+1]][optNVID[n+2]];
			}//endfor n

			for(int n=1;n<ontimes[l].size();n+=1){
				stimes[l][n]=stimes[l][n-1]+optNVID[n-1]+1;
			}//endfor n

			///Write piece-specific parameter file
			stringstream ss;
			ss.str(""); ss<<paramFolder<<"param_noteMM2B_"<<l<<".txt";
			WriteFile(ss.str());

		}//endfor l
	}//end BayesTranscribe



};//endclass NoteMarkovModel_2nd




#endif // NoteMarkovModel_HPP
