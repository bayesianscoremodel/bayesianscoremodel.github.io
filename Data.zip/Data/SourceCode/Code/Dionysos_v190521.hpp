#ifndef Dionysos_HPP
#define Dionysos_HPP

#include<iostream>
#include<fstream>
#include<string>
#include<sstream>
#include<vector>
#include<stdio.h>
#include<cmath>
#include<cassert>

using namespace std;

class DionysosEvt{
public:
	int ID;
	int onBar;
	int onBeat;
	int onTime;
	int offBar;
	int offBeat;
	int offTime;
	int dur;
	int pitch;//-1 = rest
};//endclass DionysosEvt

class Dionysos{
public:
	vector<DionysosEvt> evts;
	string meter;
	int TPQN;

	Dionysos(){
		meter="4/4";
		TPQN=4;
	}//end Dionysos
	~Dionysos(){
	}//end ~Dionysos

	void ReadFile(string filename){
		evts.clear();
		vector<int> v(100);
		vector<double> d(100);
		vector<string> s(100);
		stringstream ss;

		DionysosEvt evt;
		ifstream ifs(filename.c_str());
		if(!ifs.is_open()){cout<<"File not found: "<<filename<<endl; assert(false);}
		while(ifs>>s[0]){
			if(s[0][0]=='/' || s[0][0]=='#'){
				if(s[0]=="#meter:"){
					ifs>>meter;
				}else{
				}//endif
				getline(ifs,s[99]);
				continue;
			}//endif
			evt.ID=atoi(s[0].c_str());
			ifs>>evt.onBar>>evt.onBeat>>evt.onTime;
			ifs>>evt.offBar>>evt.offBeat>>evt.offTime;
			ifs>>evt.dur>>evt.pitch;
			getline(ifs,s[99]);
			evts.push_back(evt);
		}//endwhile
		ifs.close();
	}//end ReadFile

};//endclass Dionysos

#endif // Dionysos_HPP
