#include<fstream>
#include<iostream>
#include<cmath>
#include<string>
#include<sstream>
#include<vector>
#include<algorithm>
#include"stdio.h"
#include"stdlib.h"
#include"NoteMarkovModel_v170803.hpp"
using namespace std;

int main(int argc, char** argv){
	vector<int> v(100);
	vector<double> d(100);
	vector<string> s(100);
	stringstream ss;
	clock_t start, end;
	start = clock();

	if(argc!=6){
		cout<<"Error in usage: $./this order beatResolution data.txt out_param.txt smoothConst(0.1)"<<endl;
		return -1;
	}//endif

	int order=atoi(argv[1]);
	int nBeat=atoi(argv[2]);
	string datafile=string(argv[3]);
	string paramfile=string(argv[4]);
	double smoothConst=atof(argv[5]);

	assert(order>=0 && order<=2);

	if(order==1){

		NoteMarkovModel noteMM;
		noteMM.RandomInit(nBeat);
		noteMM.ReadData(datafile);
		noteMM.LearnAdditiveSmoothing(smoothConst);
		noteMM.WriteFile(paramfile);

	}else if(order==0){

		NoteMarkovModel_0th noteMM0;
		noteMM0.RandomInit(nBeat);
		noteMM0.ReadData(datafile);
		noteMM0.LearnAdditiveSmoothing(smoothConst);
		noteMM0.WriteFile(paramfile);

	}else if(order==2){

		NoteMarkovModel_2nd noteMM2;
		noteMM2.RandomInit(nBeat);
		noteMM2.ReadData(datafile);
		noteMM2.LearnAdditiveSmoothing(smoothConst);
		noteMM2.WriteFile(paramfile);

	}//endif


	return 0;
}//end main
