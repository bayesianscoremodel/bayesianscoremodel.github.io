#! /bin/bash


Programs/NoteMarkovModel_Learn 0 8 Data/Pop_train_rhythm.txt param_noteMM0.txt 0.1
Programs/NoteMarkovModel_Learn 1 8 Data/Pop_train_rhythm.txt param_noteMM1.txt 0.1
Programs/NoteMarkovModel_Learn 2 8 Data/Pop_train_rhythm.txt param_noteMM2.txt 0.1

Programs/MetricalMarkovModel_Learn 0 8 Data/Pop_train_rhythm.txt param_metMM0.txt 0.1
Programs/MetricalMarkovModel_Learn 1 8 Data/Pop_train_rhythm.txt param_metMM1.txt 0.1
Programs/MetricalMarkovModel_Learn 2 8 Data/Pop_train_rhythm.txt param_metMM2.txt 0.1

Programs/PatternMarkovModel_Learn 0 Param/patterns_TPQN4_halfbar_Pop.txt Data/Pop_train_rhythm.txt param_patMM0.txt 0.1
Programs/PatternMarkovModel_Learn 1 Param/patterns_TPQN4_halfbar_Pop.txt Data/Pop_train_rhythm.txt param_patMM1.txt 0.1
