*** Data for Music transcription based on Bayesian piece-specific score models capturing repetitions ***

The data and source code are provided under the MIT licence. Please see SourceCode/LICENCE.txt

We would like to ask every user to explicitly cite the following paper upon the use of data and/or source code.

Eita Nakamura, Kazuyoshi Yoshii
Music transcription based on Bayesian piece-specific score models capturing repetitions
[arXiv:1908.06969]

*** Contents ***

In the folders Fig3, Fig4, Fig5, Fig7, and Fig9, raw data used to plot the figures are contained.

The folder 'SourceCode' contains musical score data and performance data, source code for the studied models, and model parameters.

The musical score data encoded as binary vectors are given in SourceCode/Data/.
Pop_train_rhythm.txt is the training data.
Pop_test_rhythm.txt is the test data.
The list of musical pieces are given in list_Pop_train.txt and list_Pop_test.txt.

The real and synthetic performance data used for evaluation are given in SourceCode/Data/.
perfm_real_BPM105.txt is the real performance data.
perfm_synth_BPM144_sigt0.04_seed5.txt is the synthetic performance data.

The source code used in the study are in SourceCode/Code/.

To compile the programs, you need to install Boost C++ Library. Verstion 1.63.0 was used during the study, which can be downloaded from the following link.
https://www.boost.org/users/history/version_1_63_0.html

You need to specify the path to the boost library in compile.sh:
BoostLibrary="-I/.....DependingOnYourEnvironment....../boost_1_63_0"

To compile the programs (written in C++), run
./compile.sh

In ParameterLearning.sh, example commands for learning model parameters are given.

In CalculateCrossEntropy.sh, example commands for calculating the cross entropies are given.

In Transcription.sh, example commands for running the transcription algorithms are given.

To see the option parameters for each program, run a program without any arguments, for example,

./Program/NoteMarkovModel_Transcr

The necessary option parameters are then displayed.

The model parameters for the basic note value MMs, metrical MMs, and note pattern MMs learned from the training data are given in the folder SourceCode/Param/.

*** Contact ***

For any inquiries please contact Eita Nakamura eita.nakamura[at]i.kyoto-u.ac[dot]jp

